const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");
const serverTimestamp = () => new Date(Date.now() - 5000);

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const TEACHER_A = "teacher_a_uid";
const TEACHER_B = "teacher_b_uid";
const STUDENT_1 = "student_1_uid";
const STUDENT_2 = "student_2_uid";
const PASS_1 = "STU101";
const PASS_2 = "STU102";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

async function seedTeacherAndStudents() {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    const now = new Date();
    await db.collection("student_passes").doc(PASS_1).set({
      passId: PASS_1,
      studentCode: PASS_1,
      password: "Pass@1",
      teacherUid: TEACHER_A,
      studentDocId: PASS_1,
      studentName: "أحمد علي",
      groupName: "ثالثة ثانوي أ",
      studentAuthUid: "",
      createdAt: now,
      updatedAt: now,
    });
    await db.collection("student_passes").doc(PASS_2).set({
      passId: PASS_2,
      studentCode: PASS_2,
      password: "Pass@2",
      teacherUid: TEACHER_A,
      studentDocId: PASS_2,
      studentName: "سارة محمد",
      groupName: "ثالثة ثانوي أ",
      studentAuthUid: STUDENT_2,
      createdAt: now,
      updatedAt: now,
    });
    await db.collection("classrooms").doc(TEACHER_A).set({
      teacherUid: TEACHER_A,
      teacherName: "أستاذ حصة",
      createdAt: now,
      updatedAt: now,
    });
    await db
      .collection("classrooms")
      .doc(TEACHER_A)
      .collection("members")
      .doc(STUDENT_1)
      .set({
        memberUid: STUDENT_1,
        teacherUid: TEACHER_A,
        studentCode: PASS_1,
        passId: PASS_1,
        studentDocId: PASS_1,
        createdAt: now,
        updatedAt: now,
      });
    await db
      .collection("classrooms")
      .doc(TEACHER_A)
      .collection("members")
      .doc(STUDENT_2)
      .set({
        memberUid: STUDENT_2,
        teacherUid: TEACHER_A,
        studentCode: PASS_2,
        passId: PASS_2,
        studentDocId: PASS_2,
        createdAt: now,
        updatedAt: now,
      });
    await db
      .collection("classrooms")
      .doc(TEACHER_A)
      .collection("students")
      .doc(PASS_1)
      .set({
        ownerUid: TEACHER_A,
        studentAuthUid: STUDENT_1,
        code: PASS_1,
        password: "Pass@1",
        name: "أحمد علي",
        groupName: "ثالثة ثانوي أ",
        parentPhone: "01011111111",
        monthlyFee: 300,
        createdAt: now,
        updatedAt: now,
      });
    await db
      .collection("classrooms")
      .doc(TEACHER_A)
      .collection("students")
      .doc(PASS_2)
      .set({
        ownerUid: TEACHER_A,
        studentAuthUid: STUDENT_2,
        code: PASS_2,
        password: "Pass@2",
        name: "سارة محمد",
        groupName: "ثالثة ثانوي أ",
        parentPhone: "01022222222",
        monthlyFee: 300,
        createdAt: now,
        updatedAt: now,
      });
    await db
      .collection("classrooms")
      .doc(TEACHER_A)
      .collection("exams")
      .doc("EXAM_1")
      .set({
        ownerUid: TEACHER_A,
        memberUids: [STUDENT_1],
        title: "اختبار الجبر",
        groupName: "ثالثة ثانوي أ",
        durationMinutes: 30,
        totalMarks: 20,
        questions: [{ id: 1, questionText: "2+2?", options: ["3", "4"], correctOptionIndex: 1, points: 20 }],
        isActive: true,
        createdAt: now,
        updatedAt: now,
      });
  });
}

test("Unauthenticated: denied all reads and writes", async () => {
  await seedTeacherAndStudents();
  const unauth = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauth.collection("student_passes").doc(PASS_1).get());
  await assertFails(unauth.collection("student_passes").get());
  await assertFails(unauth.collection("classrooms").doc(TEACHER_A).collection("students").get());
  await assertFails(unauth.collection("classrooms").doc(TEACHER_A).collection("exams").doc("EXAM_1").get());
});

test("student_passes: list is blocked, single get allowed, ghost fields and tampering blocked", async () => {
  await seedTeacherAndStudents();
  const s1 = testEnv.authenticatedContext(STUDENT_1).firestore();
  const teacherB = testEnv.authenticatedContext(TEACHER_B).firestore();

  await assertFails(s1.collection("student_passes").get());
  await assertSucceeds(s1.collection("student_passes").doc(PASS_1).get());

  // Student 1 can bind studentAuthUid only
  await assertSucceeds(
    s1.collection("student_passes").doc(PASS_1).update({
      studentAuthUid: STUDENT_1,
      updatedAt: serverTimestamp(),
    })
  );

  // Student 1 CANNOT change password on student_pass
  await assertFails(
    s1.collection("student_passes").doc(PASS_1).update({
      password: "hacked",
      updatedAt: serverTimestamp(),
    })
  );

  // Another teacher CANNOT delete or modify teacher A's student_pass
  await assertFails(teacherB.collection("student_passes").doc(PASS_1).delete());
});

test("Teacher CRUD & ghost field rejection on students and exams", async () => {
  const teacherA = testEnv.authenticatedContext(TEACHER_A).firestore();

  // Valid create
  await assertSucceeds(
    teacherA.collection("student_passes").doc("STU99").set({
      passId: "STU99",
      studentCode: "STU99",
      password: "Ab1!x",
      teacherUid: TEACHER_A,
      studentDocId: "STU99",
      studentName: "طالب جديد",
      groupName: "أولى ثانوي",
      studentAuthUid: "",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );

  await assertSucceeds(
    teacherA.collection("classrooms").doc(TEACHER_A).collection("students").doc("STU99").set({
      ownerUid: TEACHER_A,
      studentAuthUid: "",
      code: "STU99",
      password: "Ab1!x",
      name: "طالب جديد",
      groupName: "أولى ثانوي",
      scheduleTime: "السبت 4 م",
      parentPhone: "01099999999",
      monthlyFee: 250,
      localCreatedAt: 1000,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );

  // Ghost field isAdmin rejected
  await assertFails(
    teacherA.collection("classrooms").doc(TEACHER_A).collection("students").doc("STU100").set({
      ownerUid: TEACHER_A,
      code: "STU100",
      password: "Ab1!x",
      name: "غريب",
      groupName: "أولى ثانوي",
      isAdmin: true,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );

  // Teacher B cannot write into Teacher A's classroom
  const teacherB = testEnv.authenticatedContext(TEACHER_B).firestore();
  await assertFails(
    teacherB.collection("classrooms").doc(TEACHER_A).collection("students").doc("STU99").delete()
  );
  await assertFails(
    teacherB.collection("classrooms").doc(TEACHER_A).collection("exams").get()
  );
});

test("Enrolled student isolation: cannot read other student's PII or unfiltered collection", async () => {
  await seedTeacherAndStudents();
  const s1 = testEnv.authenticatedContext(STUDENT_1).firestore();
  const teacherA = testEnv.authenticatedContext(TEACHER_A).firestore();

  // Student 1 cannot list entire students collection
  await assertFails(s1.collection("classrooms").doc(TEACHER_A).collection("students").get());
  // Student 1 CAN list filtered by studentAuthUid == STUDENT_1
  await assertSucceeds(
    s1.collection("classrooms").doc(TEACHER_A).collection("students").where("studentAuthUid", "==", STUDENT_1).get()
  );
  // Student 1 CAN get own doc, CANNOT get Student 2's doc (PII)
  await assertSucceeds(s1.collection("classrooms").doc(TEACHER_A).collection("students").doc(PASS_1).get());
  await assertFails(s1.collection("classrooms").doc(TEACHER_A).collection("students").doc(PASS_2).get());

  // Teacher A CAN list all students
  await assertSucceeds(teacherA.collection("classrooms").doc(TEACHER_A).collection("students").get());
});

test("Enrollment gate: unverified user cannot join classroom without valid student_pass", async () => {
  await seedTeacherAndStudents();
  const stranger = testEnv.authenticatedContext("stranger_uid").firestore();

  await assertFails(
    stranger.collection("classrooms").doc(TEACHER_A).collection("members").doc("stranger_uid").set({
      memberUid: "stranger_uid",
      teacherUid: TEACHER_A,
      studentCode: "FAKE1",
      passId: "FAKE1",
      studentDocId: "FAKE1",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );

  // Cannot enroll with mismatched studentCode
  await assertFails(
    stranger.collection("classrooms").doc(TEACHER_A).collection("members").doc("stranger_uid").set({
      memberUid: "stranger_uid",
      teacherUid: TEACHER_A,
      studentCode: "WRONG_CODE",
      passId: PASS_1,
      studentDocId: PASS_1,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );
});

test("Student Phone B can submit own exam & ask question, but cannot spoof another studentCode", async () => {
  await seedTeacherAndStudents();
  const s1 = testEnv.authenticatedContext(STUDENT_1).firestore();

  // Student 1 submits own exam
  await assertSucceeds(
    s1.collection("classrooms").doc(TEACHER_A).collection("exam_submissions").doc("SUB_EXAM_1_STU101").set({
      ownerUid: TEACHER_A,
      studentAuthUid: STUDENT_1,
      examCloudId: "EXAM_1",
      studentCode: PASS_1,
      score: 18,
      maxScore: 20,
      answers: { "1": 1 },
      submittedAtMs: 123456,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );

  // Student 1 CANNOT submit an exam pretending to be Student 2
  await assertFails(
    s1.collection("classrooms").doc(TEACHER_A).collection("exam_submissions").doc("SUB_EXAM_1_STU102").set({
      ownerUid: TEACHER_A,
      studentAuthUid: STUDENT_1,
      examCloudId: "EXAM_1",
      studentCode: PASS_2,
      score: 20,
      maxScore: 20,
      answers: { "1": 1 },
      submittedAtMs: 123456,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );

  // Student 1 can query shared exams using array-contains memberUids
  await assertSucceeds(
    s1.collection("classrooms").doc(TEACHER_A).collection("exams").where("memberUids", "array-contains", STUDENT_1).get()
  );

  // Student 1 can ask a question
  await assertSucceeds(
    s1.collection("classrooms").doc(TEACHER_A).collection("student_questions").doc("QA_STU101_100").set({
      ownerUid: TEACHER_A,
      memberUids: [STUDENT_1],
      studentAuthUid: STUDENT_1,
      studentName: "أحمد علي",
      studentCode: PASS_1,
      groupName: "ثالثة ثانوي أ",
      subject: "جبر",
      questionText: "ممكن شرح السؤال الأول؟",
      isAnswered: false,
      isPinned: false,
      isPublicToGroup: true,
      createdDate: "2026-11-15",
      localCreatedAt: 100,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );
});
