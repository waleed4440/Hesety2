package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppDatabase
import com.example.data.Student
import com.example.ui.TeacherViewModel
import com.example.ui.UserRole
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `verify app name resource`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("حصتي", appName)
  }

  @Test
  fun `verify teacher credentials`() {
    val context = ApplicationProvider.getApplicationContext<android.app.Application>()
    val viewModel = TeacherViewModel(context)

    // Invalid credentials
    val badLogin = viewModel.loginTeacher("wrong", "badpass")
    assertFalse(badLogin)
    assertEquals(UserRole.NONE, viewModel.currentUserRole.value)

    // Valid required credentials
    val goodLogin = viewModel.loginTeacher("admin123", "adminusername12345")
    assertTrue(goodLogin)
    assertEquals(UserRole.TEACHER, viewModel.currentUserRole.value)
  }

  @Test
  fun `verify student database insertion and verification`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<android.app.Application>()
    val db = AppDatabase.getDatabase(context)
    val dao = db.appDao()

    val testStudent = Student(
      code = "TEST999",
      password = "abc",
      name = "طالب اختبار",
      groupName = "مجموعة تجريبية",
      scheduleTime = "السبت 4 م",
      parentPhone = "01000000000",
      monthlyFee = 200.0
    )

    dao.insertStudent(testStudent)
    val fetched = dao.getStudentByCode("TEST999")
    assertNotNull(fetched)
    assertEquals("طالب اختبار", fetched?.name)
    assertEquals("abc", fetched?.password)
  }

  @Test
  fun `verify session persistence`() {
    val context = ApplicationProvider.getApplicationContext<android.app.Application>()
    val sessionManager = com.example.data.SessionManager(context)

    sessionManager.saveTeacherSession()
    assertEquals(com.example.data.SessionManager.ROLE_TEACHER, sessionManager.getSavedRole())

    sessionManager.clearSession()
    assertEquals(com.example.data.SessionManager.ROLE_NONE, sessionManager.getSavedRole())
  }

  @Test
  @Config(sdk = [34], shadows = [ShadowPdfDocument::class])
  fun `verify pdf report export for student performance and attendance history`() {
    val student = Student(
      id = 10L,
      code = "ST100",
      password = "pass",
      name = "يوسف علي",
      groupName = "ثالثة ثانوي أ",
      scheduleTime = "السبت والثلاثاء 5 م",
      parentPhone = "01012345678",
      monthlyFee = 300.0
    )
    val attendances = (1..35).map { day ->
      com.example.data.AttendanceRecord(
        id = day.toLong(),
        studentId = 10L,
        date = "2026-10-%02d".format(day.coerceAtMost(31)),
        status = if (day % 5 == 0) com.example.data.AttendanceRecord.STATUS_ABSENT else com.example.data.AttendanceRecord.STATUS_PRESENT,
        notes = if (day % 5 == 0) "غياب بعذر" else "حضور منتظم"
      )
    }
    val homework = listOf(
      com.example.data.HomeworkRecord(
        id = 1L,
        studentId = 10L,
        date = "2026-10-01",
        status = com.example.data.HomeworkRecord.STATUS_COMPLETED,
        score = "10/10",
        notes = "ممتاز"
      )
    )
    val exams = listOf(
      com.example.data.Exam(
        id = 1L,
        title = "اختبار الشهر الأول",
        groupName = "ثالثة ثانوي أ",
        durationMinutes = 30,
        totalMarks = 20,
        questionsJson = "[]"
      )
    )
    val submissions = listOf(
      com.example.data.ExamSubmission(
        id = 1L,
        examId = 1L,
        studentId = 10L,
        score = 18,
        maxScore = 20
      )
    )
    val payments = listOf(
      com.example.data.PaymentRecord(
        id = 1L,
        studentId = 10L,
        monthYear = "2026-10",
        amount = 300.0,
        isPaid = true,
        paymentDate = "2026-10-05"
      )
    )
    val notes = listOf(
      com.example.data.ParentNote(
        id = 1L,
        studentId = 10L,
        title = "متابعة",
        content = "مستوى ممتاز وتفاعل رائع في الحصة.",
        date = "2026-10-15"
      )
    )

    val studentOut = java.io.ByteArrayOutputStream()
    com.example.util.PdfReportExporter.exportStudentReportPdf(
      outputStream = studentOut,
      student = student,
      attendances = attendances,
      homework = homework,
      submissions = submissions,
      exams = exams,
      payments = payments,
      notes = notes
    )
    val studentPdfBytes = studentOut.toByteArray()
    assertTrue("Student PDF should not be empty", studentPdfBytes.isNotEmpty())
    val studentPdfHeader = String(studentPdfBytes.copyOfRange(0, minOf(5, studentPdfBytes.size)))
    assertEquals("%PDF-", studentPdfHeader)

    val groupOut = java.io.ByteArrayOutputStream()
    com.example.util.PdfReportExporter.exportGroupReportPdf(
      outputStream = groupOut,
      groupName = "ثالثة ثانوي أ",
      students = listOf(student),
      allAttendances = attendances,
      allHomework = homework,
      allSubmissions = submissions,
      allExams = exams,
      allPayments = payments,
      allNotes = notes
    )
    val groupPdfBytes = groupOut.toByteArray()
    assertTrue("Group PDF should not be empty", groupPdfBytes.isNotEmpty())
    val groupPdfHeader = String(groupPdfBytes.copyOfRange(0, minOf(5, groupPdfBytes.size)))
    assertEquals("%PDF-", groupPdfHeader)
  }

  @Test
  fun `verify qr code generation parsing and qr attendance`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<android.app.Application>()
    val dao = AppDatabase.getDatabase(context).appDao()
    val viewModel = TeacherViewModel(context)

    val student = Student(
      code = "QR777",
      password = "123",
      name = "زياد محمود",
      groupName = "ثانية ثانوي أ",
      scheduleTime = "الاثنين 4 م",
      parentPhone = "01099887766",
      monthlyFee = 250.0
    )
    val studentId = dao.insertStudent(student)
    val savedStudent = student.copy(id = studentId)

    val qrContent = com.example.util.QrCodeHelper.generateStudentQrContent(savedStudent)
    assertEquals("HESSATY_STU:QR777", qrContent)
    assertEquals("QR777", com.example.util.QrCodeHelper.parseStudentCodeFromQr(qrContent))
    assertEquals("QR777", com.example.util.QrCodeHelper.parseStudentCodeFromQr(" qr777 "))

    val qrBitmap = com.example.util.QrCodeHelper.generateQrBitmap(qrContent, 200)
    assertNotNull(qrBitmap)
    assertEquals(200, qrBitmap?.width)

    var matched: Student? = null
    viewModel.markAttendanceByQrCode(qrContent, markHomeworkToo = true) { result ->
      matched = result
    }
    repeat(10) {
      kotlinx.coroutines.delay(50)
      org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
    }
    assertNotNull(matched)
    assertEquals("QR777", matched?.code)
  }

  @Test
  fun `verify absentee batch marking and weekly class schedule persistence`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<android.app.Application>()
    val dao = AppDatabase.getDatabase(context).appDao()
    val viewModel = TeacherViewModel(context)

    val s1 = Student(code = "ABS01", password = "1", name = "سيف الدين", groupName = "مجموعة 1", scheduleTime = "السبت", parentPhone = "01111111111")
    val s2 = Student(code = "ABS02", password = "1", name = "آدم طارق", groupName = "مجموعة 1", scheduleTime = "السبت", parentPhone = "01222222222")
    val id1 = dao.insertStudent(s1)
    val id2 = dao.insertStudent(s2)

    viewModel.toggleAttendance(id1, com.example.data.AttendanceRecord.STATUS_PRESENT)
    repeat(6) {
      kotlinx.coroutines.delay(40)
      org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
    }
    viewModel.markUnmarkedAsAbsent(listOf(s1.copy(id = id1), s2.copy(id = id2)))
    repeat(6) {
      kotlinx.coroutines.delay(40)
      org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
    }

    viewModel.saveClassSchedule(
      dayOfWeek = 1,
      groupName = "مجموعة 1",
      subject = "رياضيات",
      startTime = "05:00 م",
      endTime = "06:30 م",
      location = "سنتر النور"
    )
    repeat(6) {
      kotlinx.coroutines.delay(40)
      org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
    }
    val schedules = dao.getAllSchedules().first()
    assertTrue(schedules.any { it.groupName == "مجموعة 1" && it.subject == "رياضيات" })
  }

  @Test
  fun `verify upgraded exam encoding with images and question bank persistence`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<android.app.Application>()
    val dao = AppDatabase.getDatabase(context).appDao()

    val questions = listOf(
      com.example.data.ExamQuestion(
        id = 1,
        questionText = "ما ناتج ٢ + ٣؟",
        options = listOf("4", "5", "6", "7"),
        correctOptionIndex = 1,
        points = 10,
        explanation = "٢ + ٣ = ٥",
        imageUri = "/data/user/0/com.example/files/exam_images/sample.jpg"
      )
    )
    val json = com.example.data.Exam.encodeQuestions(questions)
    val exam = com.example.data.Exam(
      title = "اختبار مطور",
      groupName = "الكل",
      durationMinutes = 20,
      totalMarks = 10,
      questionsJson = json,
      isActive = true,
      shuffleQuestions = true,
      showResultImmediately = false,
      description = "تعليمات الاختبار"
    )
    val decoded = exam.parseQuestions()
    assertEquals(1, decoded.size)
    assertEquals("/data/user/0/com.example/files/exam_images/sample.jpg", decoded[0].imageUri)
    assertTrue(exam.shuffleQuestions)
    assertFalse(exam.showResultImmediately)

    val bankId = dao.insertBankQuestion(
      com.example.data.QuestionBankItem(
        subject = "جبر",
        questionText = "سؤال بنك",
        optionsJson = com.example.data.QuestionBankItem.encodeOptions(listOf("أ", "ب", "ج", "د")),
        correctOptionIndex = 2,
        points = 5
      )
    )
    assertTrue(bankId > 0)
  }

  @Test
  fun `verify account switching between saved teacher and student accounts`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<android.app.Application>()
    val sessionManager = com.example.data.SessionManager(context)
    sessionManager.clearAllData()

    val dao = AppDatabase.getDatabase(context).appDao()
    dao.insertStudent(
      Student(
        code = "SW100",
        password = "pass1",
        name = "ياسين علاء",
        groupName = "ثانية ثانوي ب",
        scheduleTime = "الأحد 5 م",
        parentPhone = "01055555555"
      )
    )

    val viewModel = TeacherViewModel(context)

    // Login as teacher -> automatically saved for switching
    assertTrue(viewModel.loginTeacher("admin123", "adminusername12345"))
    assertEquals(1, viewModel.savedAccounts.value.size)

    // Switch via existing student credentials -> now both accounts are saved
    var switchOk = false
    viewModel.switchWithCredentials(false, "SW100", "pass1") { ok, _ -> switchOk = ok }
    repeat(8) {
      kotlinx.coroutines.delay(40)
      org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
    }
    assertTrue(switchOk)
    assertEquals(UserRole.STUDENT, viewModel.currentUserRole.value)
    assertEquals("ياسين علاء", viewModel.currentStudent.value?.name)
    assertEquals(2, viewModel.savedAccounts.value.size)

    // 1-tap switch back to teacher account
    val teacherAcc = viewModel.savedAccounts.value.first { it.role == com.example.data.SessionManager.ROLE_TEACHER }
    viewModel.switchToSavedAccount(teacherAcc)
    assertEquals(UserRole.TEACHER, viewModel.currentUserRole.value)
  }

  @Test
  fun `verify multi-type questions deadline expiration and short answer normalization`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<android.app.Application>()
    val dao = AppDatabase.getDatabase(context).appDao()

    val q1 = com.example.data.ExamQuestion(
      id = 1,
      questionText = "تقع القاهرة في مصر",
      options = listOf("صح", "خطأ"),
      correctOptionIndex = 0,
      points = 5,
      questionType = com.example.data.ExamQuestion.TYPE_TRUE_FALSE
    )
    val q2 = com.example.data.ExamQuestion(
      id = 2,
      questionText = "ما عاصمة مصر؟",
      options = emptyList(),
      correctOptionIndex = 0,
      points = 10,
      questionType = com.example.data.ExamQuestion.TYPE_SHORT_ANSWER,
      correctTextAnswer = "القاهرة"
    )
    val exam = com.example.data.Exam(
      title = "اختبار شامل مطور",
      groupName = "أولى ثانوي أ",
      durationMinutes = 30,
      totalMarks = 15,
      questionsJson = com.example.data.Exam.encodeQuestions(listOf(q1, q2)),
      deadlineDate = "2026-10-15",
      allowRetake = true
    )

    val id = dao.insertExam(exam)
    val stored = dao.getExamById(id)
    assertNotNull(stored)
    assertEquals(true, stored?.allowRetake)
    assertEquals("2026-10-15", stored?.deadlineDate)
    assertTrue(stored!!.isExpired("2026-10-16"))
    assertFalse(stored.isExpired("2026-10-15"))

    val parsed = stored.parseQuestions()
    assertEquals(2, parsed.size)
    assertEquals(com.example.data.ExamQuestion.TYPE_TRUE_FALSE, parsed[0].questionType)
    assertEquals(com.example.data.ExamQuestion.TYPE_SHORT_ANSWER, parsed[1].questionType)
    assertEquals("القاهرة", parsed[1].correctTextAnswer)

    // Verify Arabic normalization for short answer grading
    assertEquals(
      com.example.data.ExamQuestion.normalizeShortAnswer("  القاهره "),
      com.example.data.ExamQuestion.normalizeShortAnswer(parsed[1].correctTextAnswer)
    )
  }

  @Test
  fun `verify educational resource attachment path and external url persistence`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<android.app.Application>()
    val dao = AppDatabase.getDatabase(context).appDao()

    val resource = com.example.data.EducationalResource(
      title = "مذكرة التفاضل",
      subject = "رياضيات",
      groupName = "ثالثة ثانوي أ",
      description = "ملف PDF مع رابط شرح",
      fileType = "PDF",
      resourceContent = "قواعد الاشتقاق الأساسية",
      localFilePath = "/data/user/0/com.example/files/resources/calc.pdf",
      externalUrl = "https://youtube.com/watch?v=test123",
      addedDate = "2026-11-12"
    )
    dao.insertResource(resource)
    val list = dao.getAllResources().first()
    val saved = list.firstOrNull { it.title == "مذكرة التفاضل" }
    assertNotNull(saved)
    assertEquals("ثالثة ثانوي أ", saved?.groupName)
    assertEquals("/data/user/0/com.example/files/resources/calc.pdf", saved?.localFilePath)
    assertEquals("https://youtube.com/watch?v=test123", saved?.externalUrl)
  }

  @Test
  fun `verify generated student password has length 5 with English letters digits and symbols`() {
    val symbols = "@#$%&*!?"
    val generatedSet = mutableSetOf<String>()
    repeat(30) {
      val pass = Student.generateStrongPassword()
      assertEquals("Password length must be 5", 5, pass.length)
      assertTrue("Password must contain English letters: $pass", pass.any { it in 'a'..'z' || it in 'A'..'Z' })
      assertTrue("Password must contain digits: $pass", pass.any { it in '0'..'9' })
      assertTrue("Password must contain symbols: $pass", pass.any { it in symbols })
      generatedSet.add(pass)
    }
    assertTrue("Generated passwords should vary randomly", generatedSet.size > 5)
  }

  @Test
  fun `verify parent notes support both written and voice notes`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<android.app.Application>()
    val dao = AppDatabase.getDatabase(context).appDao()
    val viewModel = TeacherViewModel(context)

    val stId = dao.insertStudent(
      Student(
        code = "VN100",
        password = Student.generateStrongPassword(),
        name = "عمر حسام",
        groupName = "ثانية ثانوي أ",
        scheduleTime = "الاثنين 5 م",
        parentPhone = "01022223333"
      )
    )

    // Written + Voice note
    viewModel.addParentNote(
      studentId = stId,
      title = "تقييم أسبوعي",
      content = "مستوى ممتاز في الهندسة",
      audioFilePath = "/data/user/0/com.example/files/voice_notes/note_1.m4a",
      audioDurationSeconds = 18
    )
    // Voice-only note
    viewModel.addParentNote(
      studentId = stId,
      title = "",
      content = "",
      audioFilePath = "/data/user/0/com.example/files/voice_notes/note_2.m4a",
      audioDurationSeconds = 12
    )

    repeat(10) {
      kotlinx.coroutines.delay(50)
      org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
    }

    val notes = dao.getNotesForStudent(stId).first()
    assertEquals(2, notes.size)
    val voiceOnly = notes.first { it.content.isBlank() }
    assertTrue(voiceOnly.hasAudio())
    assertEquals(12, voiceOnly.audioDurationSeconds)
    assertTrue(voiceOnly.displaySummary().contains("12"))

    val mixed = notes.first { it.content.isNotBlank() }
    assertTrue(mixed.hasAudio())
    assertTrue(mixed.displaySummary().contains("مستوى ممتاز في الهندسة"))
    assertTrue(mixed.displaySummary().contains("18"))
  }

  @Test
  fun `verify ask the teacher qa corner persistence answering and pinning`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<android.app.Application>()
    val dao = AppDatabase.getDatabase(context).appDao()
    val viewModel = TeacherViewModel(context)

    val student = Student(
      code = "QA101",
      password = Student.generateStrongPassword(),
      name = "مريم أحمد",
      groupName = "ثالثة ثانوي أ",
      scheduleTime = "السبت 6 م",
      parentPhone = "01044445555"
    )
    val stId = dao.insertStudent(student)
    val savedStudent = student.copy(id = stId)

    viewModel.askTeacherQuestion(
      student = savedStudent,
      subject = "تفاضل",
      questionText = "كيف نشتق الدالة الضمنية؟",
      isPublicToGroup = true
    )
    repeat(10) {
      kotlinx.coroutines.delay(50)
      org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
    }

    var questions = dao.getAllQuestions().first()
    val created = questions.firstOrNull { it.studentCode == "QA101" }
    assertNotNull(created)
    assertFalse(created!!.isAnswered)
    assertFalse(created.isPinned)

    viewModel.answerStudentQuestion(
      question = created,
      answerText = "نشتق الطرفين بالنسبة إلى س مع تطبيق قاعدة السلسلة عند ص.",
      answerAudioPath = "/data/user/0/com.example/files/voice_notes/qa_ans_1.m4a",
      answerAudioDuration = 24
    )
    repeat(10) {
      kotlinx.coroutines.delay(50)
      org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
    }
    val answered = dao.getAllQuestions().first().first { it.id == created.id }
    viewModel.togglePinQuestion(answered)
    repeat(10) {
      kotlinx.coroutines.delay(50)
      org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
    }

    questions = dao.getAllQuestions().first()
    val updated = questions.first { it.id == created.id }
    assertTrue(updated.isAnswered)
    assertTrue(updated.isPinned)
    assertEquals(24, updated.answerAudioDuration)
    assertTrue(updated.answerText.contains("قاعدة السلسلة"))
  }

  @Test
  fun `verify SafeTextToolbar ignores detached view, empty rect, and redundant hide calls`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val detachedView = android.view.View(context)
    var showCalls = 0
    var hideCalls = 0
    var fakeStatus = androidx.compose.ui.platform.TextToolbarStatus.Hidden

    val fakeDelegate = object : androidx.compose.ui.platform.TextToolbar {
      override val status: androidx.compose.ui.platform.TextToolbarStatus
        get() = fakeStatus

      override fun showMenu(
        rect: androidx.compose.ui.geometry.Rect,
        onCopyRequested: (() -> Unit)?,
        onPasteRequested: (() -> Unit)?,
        onCutRequested: (() -> Unit)?,
        onSelectAllRequested: (() -> Unit)?
      ) {
        showCalls++
        fakeStatus = androidx.compose.ui.platform.TextToolbarStatus.Shown
      }

      override fun hide() {
        hideCalls++
        fakeStatus = androidx.compose.ui.platform.TextToolbarStatus.Hidden
      }
    }

    val safeToolbar = com.example.ui.components.SafeTextToolbar(fakeDelegate, detachedView)

    // Detached view must never invoke delegate.showMenu or delegate.hide
    safeToolbar.showMenu(androidx.compose.ui.geometry.Rect(0f, 0f, 100f, 50f), null, null, null, null)
    assertEquals(0, showCalls)

    // Even if delegate became Shown externally, hide() must not touch a detached view or repeat when Hidden
    fakeStatus = androidx.compose.ui.platform.TextToolbarStatus.Shown
    safeToolbar.hide()
    assertEquals(0, hideCalls)

    // Attached view + unlaid-out / zero-sized view must be ignored
    val attachedView = object : android.view.View(context) {
      override fun isAttachedToWindow(): Boolean = true
      override fun getWindowToken(): android.os.IBinder = android.os.Binder()
    }
    val attachedSafeToolbar = com.example.ui.components.SafeTextToolbar(fakeDelegate, attachedView)
    fakeStatus = androidx.compose.ui.platform.TextToolbarStatus.Hidden

    attachedSafeToolbar.showMenu(androidx.compose.ui.geometry.Rect(0f, 0f, 100f, 50f), null, null, null, null)
    assertEquals(0, showCalls)

    // Lay out attached view with valid bounds; empty rect must still be ignored
    attachedView.layout(0, 0, 1080, 1920)
    attachedSafeToolbar.showMenu(androidx.compose.ui.geometry.Rect.Zero, null, null, null, null)
    assertEquals(0, showCalls)

    // Attached + laid-out view + valid rect invokes showMenu once, and repeated hide() only fires once
    attachedSafeToolbar.showMenu(androidx.compose.ui.geometry.Rect(0f, 0f, 100f, 50f), null, null, null, null)
    assertEquals(1, showCalls)
    attachedSafeToolbar.hide()
    attachedSafeToolbar.hide()
    assertEquals(1, hideCalls)
  }

  @Test
  fun `verify MainActivity configures adjustResize softInputMode`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val component = android.content.ComponentName(context, MainActivity::class.java)
    val info = context.packageManager.getActivityInfo(component, 0)
    val adjust = info.softInputMode and android.view.WindowManager.LayoutParams.SOFT_INPUT_MASK_ADJUST
    assertEquals(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE, adjust)
  }

  @Test
  fun `verify app version name is 5_5`() {
    assertEquals("5.5", BuildConfig.VERSION_NAME)
  }

  @Test
  fun `verify deleting student removes attendance homework payment and all related statistics`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<android.app.Application>()
    val dao = AppDatabase.getDatabase(context).appDao()
    val viewModel = TeacherViewModel(context)

    val st = Student(
      code = "DEL55",
      password = Student.generateStrongPassword(),
      name = "طالب محذوف",
      groupName = "ثالثة ثانوي أ",
      scheduleTime = "السبت 4 م",
      parentPhone = "01077778888",
      monthlyFee = 300.0
    )
    val studentId = dao.insertStudent(st)
    val savedStudent = st.copy(id = studentId)

    // Record attendance, homework, payment (twice to verify deduplication), note, exam submission, and question
    viewModel.toggleAttendance(studentId, com.example.data.AttendanceRecord.STATUS_PRESENT)
    viewModel.toggleHomework(studentId, com.example.data.HomeworkRecord.STATUS_COMPLETED)
    viewModel.togglePayment(studentId, "نوفمبر 2026", true, 300.0)
    viewModel.togglePayment(studentId, "نوفمبر 2026", true, 300.0)
    viewModel.addParentNote(studentId, "ملاحظة", "ممتاز")
    viewModel.askTeacherQuestion(savedStudent, "فيزياء", "سؤال تجريبي")
    val examId = dao.insertExam(
      com.example.data.Exam(title = "اختبار سريع", groupName = "ثالثة ثانوي أ")
    )
    dao.upsertSubmission(
      com.example.data.ExamSubmission(
        examId = examId,
        studentId = studentId,
        score = 18,
        maxScore = 20
      )
    )

    repeat(10) {
      kotlinx.coroutines.delay(50)
      org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
    }

    assertTrue(dao.getAllAttendances().first().any { it.studentId == studentId })
    assertTrue(dao.getAllHomework().first().any { it.studentId == studentId })
    assertEquals(1, dao.getAllPayments().first().count { it.studentId == studentId })
    assertTrue(dao.getAllSubmissions().first().any { it.studentId == studentId })
    assertTrue(dao.getAllNotes().first().any { it.studentId == studentId })
    assertTrue(dao.getAllQuestions().first().any { it.studentId == studentId })

    // Delete student via ViewModel
    viewModel.deleteStudent(savedStudent)
    repeat(10) {
      kotlinx.coroutines.delay(50)
      org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
    }

    assertFalse(dao.getAllStudents().first().any { it.id == studentId })
    assertFalse(dao.getAllAttendances().first().any { it.studentId == studentId })
    assertFalse(dao.getAllHomework().first().any { it.studentId == studentId })
    assertFalse(dao.getAllPayments().first().any { it.studentId == studentId })
    assertFalse(dao.getAllSubmissions().first().any { it.studentId == studentId })
    assertFalse(dao.getAllNotes().first().any { it.studentId == studentId })
    assertFalse(dao.getAllQuestions().first().any { it.studentId == studentId })
  }

  @Test
  fun `verify deleteOrphanedStudentRecords purges legacy orphaned stats`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<android.app.Application>()
    val dao = AppDatabase.getDatabase(context).appDao()
    val missingStudentId = 99999L

    dao.upsertAttendance(
      com.example.data.AttendanceRecord(
        studentId = missingStudentId,
        date = "2026-11-13",
        status = com.example.data.AttendanceRecord.STATUS_PRESENT
      )
    )
    dao.upsertHomework(
      com.example.data.HomeworkRecord(
        studentId = missingStudentId,
        date = "2026-11-13",
        status = com.example.data.HomeworkRecord.STATUS_COMPLETED
      )
    )
    dao.replacePayment(
      com.example.data.PaymentRecord(
        studentId = missingStudentId,
        monthYear = "نوفمبر 2026",
        amount = 250.0,
        isPaid = true
      )
    )

    assertTrue(dao.getAllAttendances().first().any { it.studentId == missingStudentId })
    assertTrue(dao.getAllHomework().first().any { it.studentId == missingStudentId })
    assertTrue(dao.getAllPayments().first().any { it.studentId == missingStudentId })

    dao.deleteOrphanedStudentRecords()

    assertFalse(dao.getAllAttendances().first().any { it.studentId == missingStudentId })
    assertFalse(dao.getAllHomework().first().any { it.studentId == missingStudentId })
    assertFalse(dao.getAllPayments().first().any { it.studentId == missingStudentId })
  }

  @Test
  fun `verify calm announcement palette guarantees strong contrast in light and dark modes`() {
    val combinations = listOf(
      com.example.ui.theme.calmAnnouncementPalette(isUrgent = false, isDarkTheme = false),
      com.example.ui.theme.calmAnnouncementPalette(isUrgent = true, isDarkTheme = false),
      com.example.ui.theme.calmAnnouncementPalette(isUrgent = false, isDarkTheme = true),
      com.example.ui.theme.calmAnnouncementPalette(isUrgent = true, isDarkTheme = true)
    )
    combinations.forEach { palette ->
      val bgArgb = androidx.core.graphics.ColorUtils.setAlphaComponent(
        android.graphics.Color.rgb(
          (palette.container.red * 255f).toInt(),
          (palette.container.green * 255f).toInt(),
          (palette.container.blue * 255f).toInt()
        ),
        255
      )
      val bodyArgb = android.graphics.Color.rgb(
        (palette.body.red * 255f).toInt(),
        (palette.body.green * 255f).toInt(),
        (palette.body.blue * 255f).toInt()
      )
      val titleArgb = android.graphics.Color.rgb(
        (palette.title.red * 255f).toInt(),
        (palette.title.green * 255f).toInt(),
        (palette.title.blue * 255f).toInt()
      )
      val bodyContrast = androidx.core.graphics.ColorUtils.calculateContrast(bodyArgb, bgArgb)
      val titleContrast = androidx.core.graphics.ColorUtils.calculateContrast(titleArgb, bgArgb)
      assertTrue("Body text contrast must exceed 7.0 (was $bodyContrast)", bodyContrast >= 7.0)
      assertTrue("Title text contrast must exceed 4.5 (was $titleContrast)", titleContrast >= 4.5)
    }
  }

  @Test
  fun `verify immediate local persistence via TeacherViewModel without pending sync ops`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<android.app.Application>()
    val dao = AppDatabase.getDatabase(context).appDao()
    val viewModel = TeacherViewModel(context)

    viewModel.saveStudent(
      code = "LOC101",
      password = "p1",
      name = "يوسف محلي",
      groupName = "ثالثة ثانوي أ",
      scheduleTime = "السبت 4 م",
      parentPhone = "01012345678",
      monthlyFee = 250.0
    )
    viewModel.saveClassSchedule(
      dayOfWeek = 1,
      groupName = "ثالثة ثانوي أ",
      subject = "رياضيات",
      startTime = "4:00 م",
      endTime = "5:30 م",
      location = "قاعة 1"
    )
    viewModel.addEducationalResource(
      title = "مذكرة التفاضل",
      subject = "رياضيات",
      groupName = "ثالثة ثانوي أ",
      description = "ملف مراجعة فوري",
      fileType = "PDF",
      content = "ملخص القوانين"
    )
    viewModel.postAnnouncement(
      title = "تنبيه هام",
      content = "موعد المراجعة غداً",
      groupName = "ثالثة ثانوي أ",
      isUrgent = true
    )

    repeat(12) {
      kotlinx.coroutines.delay(40)
      org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
    }

    assertNotNull(dao.getStudentByCode("LOC101"))
    assertTrue(dao.getAllSchedules().first().any { it.groupName == "ثالثة ثانوي أ" && it.subject == "رياضيات" })
    assertTrue(dao.getAllResources().first().any { it.title == "مذكرة التفاضل" })
    assertTrue(dao.getAllAnnouncements().first().any { it.title == "تنبيه هام" })
    assertTrue(dao.getPendingSyncOps().isEmpty())
  }

  @Test
  fun `verify exam analytics, edit, duplicate, and shuffleOptions preserve canonical index`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<android.app.Application>()
    val dao = AppDatabase.getDatabase(context).appDao()
    val viewModel = TeacherViewModel(context)

    val q1 = com.example.data.ExamQuestion(
      id = 1,
      questionText = "ما هو الرمز الكيميائي للماء؟",
      options = listOf("CO2", "H2O", "O2", "NaCl"),
      correctOptionIndex = 1,
      points = 10,
      difficulty = com.example.data.ExamQuestion.DIFFICULTY_EASY,
      topic = "الكيمياء الأساسية"
    )
    val q2 = com.example.data.ExamQuestion(
      id = 2,
      questionText = "تقع الإسكندرية على البحر الأحمر",
      options = listOf("صح", "خطأ"),
      correctOptionIndex = 1,
      points = 10,
      questionType = com.example.data.ExamQuestion.TYPE_TRUE_FALSE,
      difficulty = com.example.data.ExamQuestion.DIFFICULTY_HARD
    )

    // shuffledForDisplay keeps original canonical index associated with option text
    val shuffled = q1.shuffledForDisplay()
    assertEquals(4, shuffled.size)
    assertEquals("H2O", shuffled.first { it.first == 1 }.second)

    viewModel.saveExam(
      title = "اختبار العلوم المتطور",
      groupName = "ثانية ثانوي أ",
      durationMinutes = 30,
      totalMarks = 20,
      questions = listOf(q1, q2),
      shuffleQuestions = true,
      shuffleOptions = true,
      subject = "علوم",
      passingPercentage = 60,
      saveToBank = false
    )
    repeat(10) {
      kotlinx.coroutines.delay(40)
      org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
    }

    val created = dao.getAllExams().first().first { it.title == "اختبار العلوم المتطور" }
    assertEquals("علوم", created.subject)
    assertEquals(60, created.passingPercentage)
    assertTrue(created.shuffleOptions)

    // Edit existing exam
    viewModel.saveExam(
      id = created.id,
      title = "اختبار العلوم المتطور - محدث",
      groupName = "ثانية ثانوي أ",
      durationMinutes = 35,
      totalMarks = 20,
      questions = listOf(q1, q2),
      shuffleOptions = true,
      subject = "كيمياء",
      passingPercentage = 75,
      saveToBank = false
    )
    viewModel.duplicateExam(created.copy(title = "اختبار العلوم المتطور - محدث"))
    repeat(10) {
      kotlinx.coroutines.delay(40)
      org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
    }

    val allExams = dao.getAllExams().first()
    val updated = allExams.first { it.id == created.id }
    assertEquals("اختبار العلوم المتطور - محدث", updated.title)
    assertEquals(75, updated.passingPercentage)
    assertEquals("كيمياء", updated.subject)
    assertTrue(allExams.any { it.title == "اختبار العلوم المتطور - محدث (نسخة)" })

    // Verify ExamMistakeAnalyzer analytics
    val subPass = com.example.data.ExamSubmission(
      examId = updated.id,
      studentId = 1L,
      score = 20,
      maxScore = 20,
      answersJson = """{"1":1,"2":1}"""
    )
    val subFail = com.example.data.ExamSubmission(
      examId = updated.id,
      studentId = 2L,
      score = 10,
      maxScore = 20,
      answersJson = """{"1":1,"2":0}"""
    )
    val summary = com.example.util.ExamMistakeAnalyzer.computeExamAnalytics(updated, listOf(subPass, subFail))
    assertEquals(2, summary.totalSubmissions)
    assertEquals(1, summary.passedCount)
    assertEquals(50, summary.passRatePercent)
    assertEquals(75, summary.averagePercentage)
    assertEquals(2, summary.hardestQuestions.first().question.id)
    assertEquals(50, summary.hardestQuestions.first().errorRatePercent)
  }

  @Test
  fun `verify automatic mistake bank capture, retake increment, practice mastery, remedial exam, and student delete cascade`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<android.app.Application>()
    val dao = AppDatabase.getDatabase(context).appDao()
    val viewModel = TeacherViewModel(context)

    val st = Student(
      code = "MSK10",
      password = "p1",
      name = "كريم طارق",
      groupName = "ثالثة ثانوي أ",
      scheduleTime = "السبت 3 م",
      parentPhone = "01088889999"
    )
    val stId = dao.insertStudent(st)
    val savedStudent = st.copy(id = stId)

    val qMcq = com.example.data.ExamQuestion(
      id = 1,
      questionText = "كم عدد أضلاع المثلث؟",
      options = listOf("3", "4", "5", "6"),
      correctOptionIndex = 0,
      points = 5,
      explanation = "المثلث له 3 أضلاع"
    )
    val qShort = com.example.data.ExamQuestion(
      id = 2,
      questionText = "ما هي وحدة قياس القوة؟",
      options = emptyList(),
      correctOptionIndex = 0,
      points = 5,
      questionType = com.example.data.ExamQuestion.TYPE_SHORT_ANSWER,
      correctTextAnswer = "النيوتن",
      explanation = "تقاس القوة بوحدة النيوتن"
    )
    val examId = dao.insertExam(
      com.example.data.Exam(
        title = "اختبار تجريبي للأخطاء",
        groupName = "ثالثة ثانوي أ",
        subject = "فيزياء وهندسة",
        totalMarks = 10,
        passingPercentage = 50,
        questionsJson = com.example.data.Exam.encodeQuestions(listOf(qMcq, qShort))
      )
    )

    // Student gets q1 right (idx 0) and q2 wrong ("الجول")
    viewModel.submitStudentExam(
      examId = examId,
      studentId = stId,
      score = 5,
      maxScore = 10,
      answersJson = """{"1":0,"text_2":"الجول"}"""
    )
    repeat(12) {
      kotlinx.coroutines.delay(40)
      org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
    }

    var mistakes = dao.getMistakesForStudent(stId).first()
    assertEquals(1, mistakes.size)
    assertEquals("ما هي وحدة قياس القوة؟", mistakes[0].questionText)
    assertEquals("الجول", mistakes[0].studentAnswer)
    assertEquals("النيوتن", mistakes[0].correctAnswer)
    assertEquals(1, mistakes[0].mistakeCount)
    assertFalse(mistakes[0].isMastered)

    // Retaking and getting same question wrong again increments mistakeCount without duplicating rows
    viewModel.submitStudentExam(
      examId = examId,
      studentId = stId,
      score = 5,
      maxScore = 10,
      answersJson = """{"1":0,"text_2":"الواط"}"""
    )
    repeat(12) {
      kotlinx.coroutines.delay(40)
      org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
    }
    mistakes = dao.getMistakesForStudent(stId).first()
    assertEquals(1, mistakes.size)
    assertEquals(2, mistakes[0].mistakeCount)
    assertEquals("الواط", mistakes[0].studentAnswer)

    // Practicing mistake correctly marks it mastered
    viewModel.recordMistakePracticeAttempt(mistakes[0], isCorrect = true)
    repeat(8) {
      kotlinx.coroutines.delay(40)
      org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
    }
    val afterPractice = dao.getMistakesForStudent(stId).first().first()
    assertTrue(afterPractice.isMastered)
    assertEquals(1, afterPractice.practiceAttempts)

    // Creating remedial exam from mistakes produces active shuffled exam
    viewModel.createRemedialExamFromMistakes(
      title = "امتحان علاجي تجريبي",
      groupName = "ثالثة ثانوي أ",
      durationMinutes = 15,
      mistakes = listOf(afterPractice)
    )
    repeat(8) {
      kotlinx.coroutines.delay(40)
      org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
    }
    val remedial = dao.getAllExams().first().firstOrNull { it.title == "امتحان علاجي تجريبي" }
    assertNotNull(remedial)
    assertEquals(1, remedial!!.parseQuestions().size)
    assertTrue(remedial.shuffleOptions)

    // Deleting student cascades and removes their mistakes
    viewModel.deleteStudent(savedStudent)
    repeat(10) {
      kotlinx.coroutines.delay(40)
      org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
    }
    assertTrue(dao.getMistakesForStudent(stId).first().isEmpty())
  }

  @Test
  fun `verify quick parent communication phone normalization, whatsapp uri, and real snapshot templates`() {
    assertEquals("201012345678", com.example.util.ParentCommunicationHelper.normalizeWhatsAppPhone("010-1234-5678"))
    assertEquals("201012345678", com.example.util.ParentCommunicationHelper.normalizeWhatsAppPhone("+20 101 234 5678"))
    assertEquals("201012345678", com.example.util.ParentCommunicationHelper.normalizeWhatsAppPhone("00201012345678"))
    assertEquals(null, com.example.util.ParentCommunicationHelper.normalizeWhatsAppPhone("010"))

    assertEquals("01012345678", com.example.util.ParentCommunicationHelper.normalizeDialPhone("010-1234-5678"))
    assertEquals("+201012345678", com.example.util.ParentCommunicationHelper.normalizeDialPhone("+20 101 234 5678"))
    assertEquals(null, com.example.util.ParentCommunicationHelper.normalizeDialPhone("123"))

    val student = Student(
      id = 77L,
      code = "PAR77",
      password = "p1",
      name = "عمر حسام",
      groupName = "ثالثة ثانوي أ",
      scheduleTime = "السبت 4 م",
      parentPhone = "01012345678",
      monthlyFee = 300.0
    )
    val snapshot = com.example.util.ParentCommunicationHelper.buildSnapshot(
      student = student,
      allAttendances = listOf(
        com.example.data.AttendanceRecord(studentId = 77L, date = "2026-11-14", status = com.example.data.AttendanceRecord.STATUS_ABSENT),
        com.example.data.AttendanceRecord(studentId = 77L, date = "2026-11-12", status = com.example.data.AttendanceRecord.STATUS_PRESENT)
      ),
      allHomework = listOf(
        com.example.data.HomeworkRecord(studentId = 77L, date = "2026-11-14", status = com.example.data.HomeworkRecord.STATUS_NOT_COMPLETED)
      ),
      allPayments = emptyList(),
      allSubmissions = listOf(
        com.example.data.ExamSubmission(examId = 5L, studentId = 77L, score = 18, maxScore = 20, submittedAt = 1000L)
      ),
      allExams = listOf(
        com.example.data.Exam(id = 5L, title = "اختبار الجبر", groupName = "ثالثة ثانوي أ")
      ),
      allNotes = listOf(
        com.example.data.ParentNote(studentId = 77L, title = "متابعة", content = "يحتاج مراجعة درس المصفوفات", date = "2026-11-14")
      ),
      sessionDate = "2026-11-14"
    )

    assertEquals("غائب", snapshot.attendanceStatus)
    assertEquals("50%", snapshot.attendanceRatePercent)
    assertEquals("لم يسلّم الواجب", snapshot.homeworkStatus)
    assertEquals("18/20", snapshot.latestExamScore)
    assertEquals("اختبار الجبر", snapshot.latestExamTitle)
    assertFalse(snapshot.isPaid)

    val reportMsg = com.example.util.ParentCommunicationHelper.buildTemplateMessage(
      com.example.util.ParentMessageTemplate.FULL_REPORT,
      snapshot
    )
    assertTrue(reportMsg.contains("عمر حسام"))
    assertTrue(reportMsg.contains("18/20"))
    assertTrue(reportMsg.contains("مستحق السداد (300 ج.م)"))
    assertTrue(reportMsg.contains("يحتاج مراجعة درس المصفوفات"))

    val waUri = com.example.util.ParentCommunicationHelper.buildWhatsAppUri(student.parentPhone, reportMsg)
    assertNotNull(waUri)
    assertTrue(waUri.toString().startsWith("https://wa.me/201012345678?text="))
  }

}
