package com.example

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.pdf.PdfDocument
import org.robolectric.annotation.Implementation
import org.robolectric.annotation.Implements
import org.robolectric.util.ReflectionHelpers
import java.io.OutputStream
import java.nio.charset.StandardCharsets

@Implements(PdfDocument::class)
class ShadowPdfDocument {
    private val finishedPages = mutableListOf<PdfDocument.PageInfo>()
    private var closed = false

    @Implementation
    fun __constructor__() {
        closed = false
    }

    @Implementation
    fun startPage(pageInfo: PdfDocument.PageInfo): PdfDocument.Page {
        check(!closed) { "document is closed!" }
        val bitmap = Bitmap.createBitmap(
            pageInfo.pageWidth.coerceAtLeast(1),
            pageInfo.pageHeight.coerceAtLeast(1),
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(bitmap)
        return ReflectionHelpers.callConstructor(
            PdfDocument.Page::class.java,
            ReflectionHelpers.ClassParameter.from(Canvas::class.java, canvas),
            ReflectionHelpers.ClassParameter.from(PdfDocument.PageInfo::class.java, pageInfo)
        )
    }

    @Implementation
    fun finishPage(page: PdfDocument.Page) {
        check(!closed) { "document is closed!" }
        finishedPages.add(page.info)
    }

    @Implementation
    fun writeTo(out: OutputStream) {
        check(!closed) { "document is closed!" }
        val content = buildString {
            append("%PDF-1.4\n")
            append("% Pages=${finishedPages.size}\n")
            finishedPages.forEachIndexed { idx, info ->
                append("${idx + 1} 0 obj << /Type /Page /MediaBox [0 0 ${info.pageWidth} ${info.pageHeight}] >> endobj\n")
            }
            append("%%EOF\n")
        }
        out.write(content.toByteArray(StandardCharsets.US_ASCII))
    }

    @Implementation
    fun close() {
        closed = true
    }
}
