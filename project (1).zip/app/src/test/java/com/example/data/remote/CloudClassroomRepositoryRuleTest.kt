package com.example.data.remote

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.Announcement
import com.example.data.AttendanceRecord
import com.example.data.Exam
import com.example.data.ExamQuestion
import com.example.data.ExamSubmission
import com.example.data.Student
import com.example.data.StudentQuestion
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class CloudClassroomRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun teacherCreatesStudentAndExam_studentEnrollsFromSecondDeviceAndSubmitsExam() = runBlocking {
        val uniqueSuffix = UUID.randomUUID().toString().take(8).uppercase()
        val studentCode = "STU_$uniqueSuffix"
        val studentPass = "P@5$uniqueSuffix".take(12)

        // Phone A: Teacher signs in and registers student + attendance + exam + announcement
        val teacherUid = signInTestUser("teacher_a@test.com")
        val teacherRepo = CloudClassroomRepository(firestore, auth)
        val teacherObs = CloudClassroomObservers(firestore)

        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) { teacherRepo.ensureTeacherClassroom("أستاذ الجبر") }.isSuccess)

        val student = Student(
            code = studentCode,
            password = studentPass,
            name = "يوسف طارق",
            groupName = "ثالثة ثانوي أ",
            scheduleTime = "السبت 4 م",
            parentPhone = "01012345678",
            monthlyFee = 300.0
        )
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) { teacherRepo.upsertStudent(student) }.isSuccess)
        assertTrue(
            withTimeout(DEFAULT_TIMEOUT_MS) {
                teacherRepo.upsertAttendance(
                    studentCode,
                    AttendanceRecord(studentId = 1L, date = "2026-11-15", status = AttendanceRecord.STATUS_PRESENT, notes = "حاضر")
                )
            }.isSuccess
        )

        val exam = Exam(
            title = "اختبار السيرفر $uniqueSuffix",
            groupName = "ثالثة ثانوي أ",
            durationMinutes = 25,
            totalMarks = 10,
            questionsJson = Exam.encodeQuestions(
                listOf(
                    ExamQuestion(
                        id = 1,
                        questionText = "ما ناتج 5 + 5؟",
                        options = listOf("8", "10", "12"),
                        correctOptionIndex = 1,
                        points = 10
                    )
                )
            ),
            createdAt = System.currentTimeMillis()
        )
        val examCloudId = withTimeout(DEFAULT_TIMEOUT_MS) { teacherRepo.upsertExam(exam) }.getOrThrow()

        assertTrue(
            withTimeout(DEFAULT_TIMEOUT_MS) {
                teacherRepo.upsertAnnouncement(
                    Announcement(
                        title = "إعلان تجريبي",
                        content = "تم رفع الامتحان على السيرفر",
                        groupName = "ثالثة ثانوي أ",
                        date = "2026-11-15"
                    )
                )
            }.isSuccess
        )

        // Verify teacher's real-time stream sees the student
        val observedStudents = withTimeout(FLOW_TIMEOUT_MS) {
            teacherObs.observeTeacherStudents(teacherUid).first { list -> list.any { it.code == studentCode } }
        }
        assertTrue(observedStudents.any { it.name == "يوسف طارق" })

        // Phone B: Different user signs in as Student using ONLY studentCode + studentPass
        val studentUid = signInTestUser("student_b_$uniqueSuffix@test.com")
        val studentRepo = CloudClassroomRepository(firestore, auth)
        val studentObs = CloudClassroomObservers(firestore)

        // Wrong password must fail
        val badResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            studentRepo.enrollAndFetchStudent(studentCode, "WRONG_PASS")
        }
        assertTrue(badResult.isFailure)

        // Correct password enrolls Phone B and hydrates all data from Phone A
        val bundle = withTimeout(DEFAULT_TIMEOUT_MS) {
            studentRepo.enrollAndFetchStudent(studentCode, studentPass)
        }.getOrThrow()
        assertEquals(teacherUid, bundle.teacherUid)
        assertEquals("يوسف طارق", bundle.student.name)
        assertTrue(bundle.attendances.any { it.status == AttendanceRecord.STATUS_PRESENT })
        assertTrue(bundle.exams.any { it.docId == examCloudId })
        assertTrue(bundle.announcements.any { it.title == "إعلان تجريبي" })

        // Student Phone B submits exam & asks a question -> Teacher Phone A receives both!
        val submission = ExamSubmission(
            examId = 1L,
            studentId = 1L,
            score = 10,
            maxScore = 10,
            answersJson = """{"1":1}"""
        )
        assertTrue(
            withTimeout(DEFAULT_TIMEOUT_MS) {
                studentRepo.upsertExamSubmission(teacherUid, examCloudId, studentCode, submission)
            }.isSuccess
        )
        assertTrue(
            withTimeout(DEFAULT_TIMEOUT_MS) {
                studentRepo.upsertQuestion(
                    teacherUid,
                    StudentQuestion(
                        studentId = 1L,
                        studentName = "يوسف طارق",
                        studentCode = studentCode,
                        groupName = "ثالثة ثانوي أ",
                        subject = "رياضيات",
                        questionText = "هل المراجعة غداً؟",
                        isPublicToGroup = true,
                        createdDate = "2026-11-15"
                    )
                )
            }.isSuccess
        )

        val liveStudentAtt = withTimeout(FLOW_TIMEOUT_MS) {
            studentObs.observeStudentAttendances(teacherUid, studentUid).first { it.isNotEmpty() }
        }
        assertEquals(AttendanceRecord.STATUS_PRESENT, liveStudentAtt.first().status)

        // Switch back to Teacher Phone A: verify Teacher observes submission & question in real time
        signInTestUser("teacher_a@test.com")
        val teacherSubmissions = withTimeout(FLOW_TIMEOUT_MS) {
            teacherObs.observeTeacherSubmissions(teacherUid).first { list ->
                list.any { it.studentCode == studentCode && it.examCloudId == examCloudId }
            }
        }
        assertEquals(10, teacherSubmissions.first { it.studentCode == studentCode && it.examCloudId == examCloudId }.score)

        val teacherQuestions = withTimeout(FLOW_TIMEOUT_MS) {
            teacherObs.observeTeacherQuestions(teacherUid).first { list ->
                list.any { it.question.studentCode == studentCode }
            }
        }
        assertNotNull(teacherQuestions.firstOrNull { it.question.questionText == "هل المراجعة غداً؟" })
    }

    @Test
    fun crossUserIsolation_otherTeacherAndOtherStudentReceivePermissionDenied() = runBlocking {
        val teacherAUid = signInTestUser("teacher_iso_a@test.com")
        val repoA = CloudClassroomRepository(firestore, auth)
        val code = "ISO_${UUID.randomUUID().toString().take(6).uppercase()}"
        withTimeout(DEFAULT_TIMEOUT_MS) {
            repoA.upsertStudent(
                Student(
                    code = code,
                    password = "Pass!9",
                    name = "طالب محمي",
                    groupName = "أولى ثانوي",
                    scheduleTime = "السبت",
                    parentPhone = "01055554444"
                )
            )
        }.getOrThrow()

        // Different teacher attempts to observe Teacher A's students -> PERMISSION_DENIED
        signInTestUser("teacher_iso_b@test.com")
        val obsB = CloudClassroomObservers(firestore)
        var capturedError: Throwable? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                obsB.observeTeacherStudents(teacherAUid).first()
            }
        } catch (e: Exception) {
            capturedError = e
        }
        val firestoreEx = checkNotNull(capturedError?.unwrapFirestoreException()) {
            "Expected PERMISSION_DENIED FirebaseFirestoreException, got $capturedError"
        }
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreEx.code)
    }

    @Test
    fun unauthenticatedCaller_observeStudentsFailsWithPermissionDenied() = runBlocking {
        val teacherUid = signInTestUser("teacher_unauth@test.com")
        auth.signOut()

        val obs = CloudClassroomObservers(firestore)
        var capturedError: Throwable? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                obs.observeTeacherStudents(teacherUid).first()
            }
        } catch (e: Exception) {
            capturedError = e
        }
        val firestoreEx = checkNotNull(capturedError?.unwrapFirestoreException()) {
            "Expected nested FirebaseFirestoreException, got $capturedError"
        }
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreEx.code)
    }

    private companion object {
        const val DEFAULT_TIMEOUT_MS = 6000L
        const val FLOW_TIMEOUT_MS = 5000L
    }
}
