package com.example.data.remote

import android.content.Context
import com.example.data.Announcement
import com.example.data.AppDao
import com.example.data.AttendanceRecord
import com.example.data.ClassSchedule
import com.example.data.EducationalResource
import com.example.data.Exam
import com.example.data.ExamSubmission
import com.example.data.HomeworkRecord
import com.example.data.MistakeRecord
import com.example.data.ParentNote
import com.example.data.PaymentRecord
import com.example.data.Student
import com.example.data.StudentQuestion
import com.google.firebase.FirebaseApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class CloudSyncStatus {
    OFFLINE_LOCAL,
    CONNECTING,
    SYNCED
}

class CloudSyncBridge(
    private val context: Context,
    private val dao: AppDao
) {
    private val prefs = context.applicationContext.getSharedPreferences("cloud_sync_bridge", Context.MODE_PRIVATE)

    private val repo: CloudClassroomRepository? by lazy {
        if (FirebaseApp.getApps(context.applicationContext).isNotEmpty()) {
            CloudClassroomRepository(context.applicationContext)
        } else null
    }

    private val observers: CloudClassroomObservers? by lazy {
        repo?.let { CloudClassroomObservers(it.db) }
    }

    private val _syncStatus = MutableStateFlow(CloudSyncStatus.OFFLINE_LOCAL)
    val syncStatus: StateFlow<CloudSyncStatus> = _syncStatus.asStateFlow()

    private var syncJobs = mutableListOf<Job>()
    private var activeSyncKey: String? = null

    fun isAvailable(): Boolean = repo != null && repo?.auth?.currentUser != null

    fun isSyncing(): Boolean = activeSyncKey != null && syncJobs.any { it.isActive }

    fun currentAuthUid(): String? = try {
        repo?.auth?.currentUser?.uid
    } catch (_: Exception) {
        null
    }

    fun currentUserEmail(): String? = try {
        repo?.auth?.currentUser?.email
    } catch (_: Exception) {
        null
    }

    fun currentUserDisplayName(): String? = try {
        repo?.auth?.currentUser?.displayName
    } catch (_: Exception) {
        null
    }

    fun saveStudentTeacherUid(teacherUid: String) {
        prefs.edit().putString(KEY_STUDENT_TEACHER_UID, teacherUid).apply()
    }

    fun getStudentTeacherUid(): String? = prefs.getString(KEY_STUDENT_TEACHER_UID, null)

    fun saveExamCloudMapping(localExamId: Long, cloudExamId: String) {
        if (localExamId <= 0L || cloudExamId.isBlank()) return
        prefs.edit()
            .putString("EXAM_L2C_$localExamId", cloudExamId)
            .putLong("EXAM_C2L_$cloudExamId", localExamId)
            .apply()
    }

    fun getCloudIdForLocalExam(localExamId: Long): String? =
        if (localExamId <= 0L) null else prefs.getString("EXAM_L2C_$localExamId", null)

    fun getLocalIdForCloudExam(cloudExamId: String): Long =
        prefs.getLong("EXAM_C2L_$cloudExamId", 0L)

    fun stopAllListeners() {
        syncJobs.forEach { it.cancel() }
        syncJobs.clear()
        activeSyncKey = null
        _syncStatus.value = CloudSyncStatus.OFFLINE_LOCAL
    }

    // --- Teacher Real-Time Server Sync ---

    fun startTeacherSync(scope: CoroutineScope) {
        val cloudRepo = repo ?: return
        val obs = observers ?: return
        val teacherUid = currentAuthUid() ?: return
        val key = "TEACHER:$teacherUid"
        if (activeSyncKey == key && syncJobs.any { it.isActive }) return

        stopAllListeners()
        activeSyncKey = key
        _syncStatus.value = CloudSyncStatus.CONNECTING

        // Push existing local teacher data once, then attach real-time listeners
        val bootstrapJob = scope.launch(Dispatchers.IO) {
            cloudRepo.ensureTeacherClassroom(currentUserDisplayName() ?: "الأستاذ")
            pushAllLocalTeacherData(cloudRepo)
            _syncStatus.value = CloudSyncStatus.SYNCED
        }
        syncJobs.add(bootstrapJob)

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeMembers(teacherUid).catch { }.collect { map ->
                cloudRepo.updateCachedMembers(map)
                map.forEach { (code, memberUid) ->
                    cloudRepo.grantMemberAccessToExistingDocs(teacherUid, code, memberUid)
                }
            }
        }

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeTeacherStudents(teacherUid).catch { }.collect { remoteStudents ->
                remoteStudents.forEach { upsertLocalStudent(it) }
                _syncStatus.value = CloudSyncStatus.SYNCED
            }
        }

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeTeacherExams(teacherUid).catch { }.collect { remoteExams ->
                remoteExams.forEach { upsertLocalExam(it) }
            }
        }

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeTeacherAttendances(teacherUid).catch { }.collect { list ->
                list.forEach { (code, att) -> upsertLocalAttendance(code, att) }
            }
        }

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeTeacherHomeworks(teacherUid).catch { }.collect { list ->
                list.forEach { (code, hw) -> upsertLocalHomework(code, hw) }
            }
        }

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeTeacherPayments(teacherUid).catch { }.collect { list ->
                list.forEach { (code, pay) -> upsertLocalPayment(code, pay) }
            }
        }

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeTeacherNotes(teacherUid).catch { }.collect { list ->
                list.forEach { (code, note) -> upsertLocalNote(code, note) }
            }
        }

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeTeacherSubmissions(teacherUid).catch { }.collect { list ->
                list.forEach { upsertLocalSubmission(it) }
            }
        }

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeTeacherResources(teacherUid).catch { }.collect { list ->
                list.forEach { upsertLocalResource(it) }
            }
        }

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeTeacherSchedules(teacherUid).catch { }.collect { list ->
                list.forEach { upsertLocalSchedule(it) }
            }
        }

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeTeacherAnnouncements(teacherUid).catch { }.collect { list ->
                list.forEach { upsertLocalAnnouncement(it) }
            }
        }

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeTeacherQuestions(teacherUid).catch { }.collect { list ->
                list.forEach { upsertLocalQuestion(it) }
            }
        }

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeTeacherMistakes(teacherUid).catch { }.collect { list ->
                list.forEach { upsertLocalMistake(it) }
            }
        }
    }

    // --- Student Real-Time Server Sync (Phone B) ---

    suspend fun enrollAndHydrateStudent(code: String, password: String): Result<Student> {
        val cloudRepo = repo ?: return Result.failure(IllegalStateException("السيرفر السحابي غير مهيأ"))
        if (currentAuthUid() == null) {
            return Result.failure(IllegalStateException("يرجى تسجيل الدخول بحساب Google أولاً"))
        }
        val res = cloudRepo.enrollAndFetchStudent(code, password)
        if (res.isFailure) {
            return Result.failure(res.exceptionOrNull() ?: IllegalArgumentException("بيانات الدخول غير صحيحة"))
        }
        val bundle = res.getOrThrow()
        saveStudentTeacherUid(bundle.teacherUid)
        val localStudent = withContext(Dispatchers.IO) {
            val s = upsertLocalStudent(bundle.student)
            bundle.exams.forEach { upsertLocalExam(it) }
            bundle.attendances.forEach { upsertLocalAttendance(s.code, it) }
            bundle.homeworks.forEach { upsertLocalHomework(s.code, it) }
            bundle.payments.forEach { upsertLocalPayment(s.code, it) }
            bundle.notes.forEach { upsertLocalNote(s.code, it) }
            bundle.submissions.forEach { upsertLocalSubmission(it) }
            bundle.resources.forEach { upsertLocalResource(it) }
            bundle.schedules.forEach { upsertLocalSchedule(it) }
            bundle.announcements.forEach { upsertLocalAnnouncement(it) }
            bundle.questions.forEach { upsertLocalQuestion(it) }
            bundle.mistakes.forEach { upsertLocalMistake(it) }
            s
        }
        return Result.success(localStudent)
    }

    fun startStudentSync(scope: CoroutineScope, studentCode: String) {
        val obs = observers ?: return
        val studentUid = currentAuthUid() ?: return
        val teacherUid = getStudentTeacherUid() ?: return
        val normCode = CloudMappers.normalizeCode(studentCode)
        val key = "STUDENT:$studentUid:$normCode"
        if (activeSyncKey == key && syncJobs.any { it.isActive }) return

        stopAllListeners()
        activeSyncKey = key
        _syncStatus.value = CloudSyncStatus.CONNECTING

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeStudentProfile(teacherUid, studentUid).catch { }.collect { s ->
                if (s != null) upsertLocalStudent(s)
                _syncStatus.value = CloudSyncStatus.SYNCED
            }
        }

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeStudentAttendances(teacherUid, studentUid).catch { }.collect { list ->
                list.forEach { upsertLocalAttendance(normCode, it) }
            }
        }

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeStudentHomeworks(teacherUid, studentUid).catch { }.collect { list ->
                list.forEach { upsertLocalHomework(normCode, it) }
            }
        }

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeStudentPayments(teacherUid, studentUid).catch { }.collect { list ->
                list.forEach { upsertLocalPayment(normCode, it) }
            }
        }

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeStudentNotes(teacherUid, studentUid).catch { }.collect { list ->
                list.forEach { upsertLocalNote(normCode, it) }
            }
        }

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeStudentSubmissions(teacherUid, studentUid).catch { }.collect { list ->
                list.forEach { upsertLocalSubmission(it) }
            }
        }

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeSharedExams(teacherUid, studentUid).catch { }.collect { list ->
                list.forEach { upsertLocalExam(it) }
            }
        }

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeSharedResources(teacherUid, studentUid).catch { }.collect { list ->
                list.forEach { upsertLocalResource(it) }
            }
        }

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeSharedSchedules(teacherUid, studentUid).catch { }.collect { list ->
                list.forEach { upsertLocalSchedule(it) }
            }
        }

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeSharedAnnouncements(teacherUid, studentUid).catch { }.collect { list ->
                list.forEach { upsertLocalAnnouncement(it) }
            }
        }

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeSharedQuestions(teacherUid, studentUid).catch { }.collect { list ->
                list.forEach { upsertLocalQuestion(it) }
            }
        }

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeStudentOwnQuestions(teacherUid, studentUid).catch { }.collect { list ->
                list.forEach { upsertLocalQuestion(it) }
            }
        }

        syncJobs += scope.launch(Dispatchers.IO) {
            obs.observeStudentMistakes(teacherUid, studentUid).catch { }.collect { list ->
                list.forEach { upsertLocalMistake(it) }
            }
        }
    }

    // --- Direct Background Push Helpers (called on user actions) ---

    suspend fun pushStudent(student: Student) {
        val r = repo ?: return
        if (currentAuthUid() == null) return
        r.upsertStudent(student)
    }

    suspend fun removeStudent(studentCode: String) {
        val r = repo ?: return
        if (currentAuthUid() == null) return
        r.deleteStudent(studentCode)
    }

    suspend fun pushAttendance(studentId: Long, record: AttendanceRecord) {
        val r = repo ?: return
        if (currentAuthUid() == null) return
        val student = dao.getStudentByIdSync(studentId) ?: return
        r.upsertAttendance(student.code, record)
    }

    suspend fun pushHomework(studentId: Long, record: HomeworkRecord) {
        val r = repo ?: return
        if (currentAuthUid() == null) return
        val student = dao.getStudentByIdSync(studentId) ?: return
        r.upsertHomework(student.code, record)
    }

    suspend fun pushPayment(studentId: Long, record: PaymentRecord) {
        val r = repo ?: return
        if (currentAuthUid() == null) return
        val student = dao.getStudentByIdSync(studentId) ?: return
        r.upsertPayment(student.code, record)
    }

    suspend fun pushParentNote(studentId: Long, note: ParentNote) {
        val r = repo ?: return
        if (currentAuthUid() == null) return
        val student = dao.getStudentByIdSync(studentId) ?: return
        r.upsertParentNote(student.code, note)
    }

    suspend fun pushExam(exam: Exam, localExamId: Long) {
        val r = repo ?: return
        if (currentAuthUid() == null) return
        val existingCloudId = getCloudIdForLocalExam(localExamId)
        val res = r.upsertExam(exam.copy(id = localExamId), existingCloudId)
        res.getOrNull()?.let { saveExamCloudMapping(localExamId, it) }
    }

    suspend fun removeExam(exam: Exam) {
        val r = repo ?: return
        if (currentAuthUid() == null) return
        val cloudId = CloudMappers.examDocId(exam, getCloudIdForLocalExam(exam.id))
        r.deleteExam(cloudId)
    }

    suspend fun pushSubmission(submission: ExamSubmission, isTeacherRole: Boolean) {
        val r = repo ?: return
        val uid = currentAuthUid() ?: return
        val teacherUid = if (isTeacherRole) uid else getStudentTeacherUid() ?: uid
        val student = dao.getStudentByIdSync(submission.studentId) ?: return
        val exam = dao.getExamById(submission.examId)
        val examCloudId = getCloudIdForLocalExam(submission.examId)
            ?: exam?.let { CloudMappers.examDocId(it) }
            ?: "EXAM_${submission.examId}"
        r.upsertExamSubmission(teacherUid, examCloudId, student.code, submission)
    }

    suspend fun pushResource(resource: EducationalResource) {
        val r = repo ?: return
        if (currentAuthUid() == null) return
        r.upsertResource(resource)
    }

    suspend fun removeResource(resource: EducationalResource) {
        val r = repo ?: return
        if (currentAuthUid() == null) return
        r.deleteResource(resource)
    }

    suspend fun pushSchedule(schedule: ClassSchedule) {
        val r = repo ?: return
        if (currentAuthUid() == null) return
        r.upsertSchedule(schedule)
    }

    suspend fun removeSchedule(schedule: ClassSchedule) {
        val r = repo ?: return
        if (currentAuthUid() == null) return
        r.deleteSchedule(schedule)
    }

    suspend fun pushAnnouncement(announcement: Announcement) {
        val r = repo ?: return
        if (currentAuthUid() == null) return
        r.upsertAnnouncement(announcement)
    }

    suspend fun removeAnnouncement(announcement: Announcement) {
        val r = repo ?: return
        if (currentAuthUid() == null) return
        r.deleteAnnouncement(announcement)
    }

    suspend fun pushQuestion(question: StudentQuestion, isTeacherRole: Boolean) {
        val r = repo ?: return
        val uid = currentAuthUid() ?: return
        val teacherUid = if (isTeacherRole) uid else getStudentTeacherUid() ?: uid
        r.upsertQuestion(teacherUid, question)
    }

    suspend fun removeQuestion(question: StudentQuestion) {
        val r = repo ?: return
        if (currentAuthUid() == null) return
        r.deleteQuestion(question)
    }

    suspend fun pushMistake(mistake: MistakeRecord, isTeacherRole: Boolean) {
        val r = repo ?: return
        val uid = currentAuthUid() ?: return
        val teacherUid = if (isTeacherRole) uid else getStudentTeacherUid() ?: uid
        val exam = if (mistake.examId > 0L) dao.getExamById(mistake.examId) else null
        val examCloudId = if (mistake.examId > 0L) {
            getCloudIdForLocalExam(mistake.examId) ?: exam?.let { CloudMappers.examDocId(it) } ?: ""
        } else ""
        r.upsertMistake(teacherUid, examCloudId, mistake)
    }

    suspend fun removeMistake(mistake: MistakeRecord) {
        val r = repo ?: return
        if (currentAuthUid() == null) return
        r.deleteMistake(mistake)
    }

    // --- Initial Upload of Existing Local Teacher Data ---

    private suspend fun pushAllLocalTeacherData(cloudRepo: CloudClassroomRepository) {
        try {
            val students = dao.getAllStudentsSync()
            val studentById = students.associateBy { it.id }
            students.forEach { cloudRepo.upsertStudent(it) }

            val exams = dao.getAllExams().first()
            val examCloudMap = mutableMapOf<Long, String>()
            exams.forEach { ex ->
                val cid = cloudRepo.upsertExam(ex, getCloudIdForLocalExam(ex.id)).getOrNull()
                if (cid != null) {
                    saveExamCloudMapping(ex.id, cid)
                    examCloudMap[ex.id] = cid
                }
            }

            dao.getAllAttendances().first().forEach { att ->
                studentById[att.studentId]?.let { cloudRepo.upsertAttendance(it.code, att) }
            }
            dao.getAllHomework().first().forEach { hw ->
                studentById[hw.studentId]?.let { cloudRepo.upsertHomework(it.code, hw) }
            }
            dao.getAllPayments().first().forEach { pay ->
                studentById[pay.studentId]?.let { cloudRepo.upsertPayment(it.code, pay) }
            }
            dao.getAllNotes().first().forEach { note ->
                studentById[note.studentId]?.let { cloudRepo.upsertParentNote(it.code, note) }
            }
            dao.getAllSubmissions().first().forEach { sub ->
                val st = studentById[sub.studentId] ?: return@forEach
                val cid = examCloudMap[sub.examId] ?: return@forEach
                cloudRepo.upsertExamSubmission(cloudRepo.requireUserId(), cid, st.code, sub)
            }
            dao.getAllResources().first().forEach { cloudRepo.upsertResource(it) }
            dao.getAllSchedules().first().forEach { cloudRepo.upsertSchedule(it) }
            dao.getAllAnnouncements().first().forEach { cloudRepo.upsertAnnouncement(it) }
            dao.getAllQuestions().first().forEach { cloudRepo.upsertQuestion(cloudRepo.requireUserId(), it) }
            dao.getAllMistakes().first().forEach { m ->
                val cid = if (m.examId > 0L) examCloudMap[m.examId] ?: "" else ""
                cloudRepo.upsertMistake(cloudRepo.requireUserId(), cid, m)
            }
        } catch (_: Exception) {}
    }

    // --- Local Room Reconciliation Helpers ---

    private suspend fun upsertLocalStudent(remote: Student): Student {
        val normCode = CloudMappers.normalizeCode(remote.code)
        val existing = dao.getStudentByCode(normCode)
        return if (existing != null) {
            val merged = existing.copy(
                password = remote.password.ifBlank { existing.password },
                name = remote.name,
                groupName = remote.groupName,
                scheduleTime = remote.scheduleTime,
                parentPhone = remote.parentPhone,
                monthlyFee = remote.monthlyFee
            )
            if (merged != existing) dao.updateStudent(merged)
            merged
        } else {
            val insertedId = dao.insertStudent(remote.copy(id = 0L, code = normCode))
            remote.copy(id = insertedId, code = normCode)
        }
    }

    private suspend fun upsertLocalExam(item: CloudExamItem): Long {
        val mappedLocal = getLocalIdForCloudExam(item.docId)
        val localExams = dao.getAllExams().first()
        val existing = (if (mappedLocal > 0L) localExams.firstOrNull { it.id == mappedLocal } else null)
            ?: localExams.firstOrNull { it.createdAt == item.exam.createdAt && it.title == item.exam.title }
        return if (existing != null) {
            val merged = item.exam.copy(id = existing.id)
            if (merged != existing) dao.updateExam(merged)
            saveExamCloudMapping(existing.id, item.docId)
            existing.id
        } else {
            val newId = dao.insertExam(item.exam.copy(id = 0L))
            saveExamCloudMapping(newId, item.docId)
            newId
        }
    }

    private suspend fun upsertLocalAttendance(studentCode: String, att: AttendanceRecord) {
        val st = dao.getStudentByCode(CloudMappers.normalizeCode(studentCode)) ?: return
        val existing = dao.getStudentAttendanceForDate(st.id, att.date)
        if (existing == null || existing.status != att.status || existing.notes != att.notes) {
            dao.upsertAttendance(att.copy(id = existing?.id ?: 0L, studentId = st.id))
        }
    }

    private suspend fun upsertLocalHomework(studentCode: String, hw: HomeworkRecord) {
        val st = dao.getStudentByCode(CloudMappers.normalizeCode(studentCode)) ?: return
        val existing = dao.getStudentHomeworkForDate(st.id, hw.date)
        if (existing == null || existing.status != hw.status || existing.score != hw.score || existing.notes != hw.notes) {
            dao.upsertHomework(hw.copy(id = existing?.id ?: 0L, studentId = st.id))
        }
    }

    private suspend fun upsertLocalPayment(studentCode: String, pay: PaymentRecord) {
        val st = dao.getStudentByCode(CloudMappers.normalizeCode(studentCode)) ?: return
        val existing = dao.getPaymentsForStudent(st.id).first()
            .firstOrNull { it.monthYear == pay.monthYear }
        if (existing == null || existing.isPaid != pay.isPaid || existing.amount != pay.amount || existing.paymentDate != pay.paymentDate) {
            dao.replacePayment(pay.copy(id = existing?.id ?: 0L, studentId = st.id))
        }
    }

    private suspend fun upsertLocalNote(studentCode: String, note: ParentNote) {
        val st = dao.getStudentByCode(CloudMappers.normalizeCode(studentCode)) ?: return
        val existing = dao.getNotesForStudent(st.id).first().firstOrNull {
            it.date == note.date && it.title == note.title && it.content == note.content
        }
        if (existing == null) {
            dao.insertNote(note.copy(id = 0L, studentId = st.id))
        }
    }

    private suspend fun upsertLocalSubmission(sub: CloudSubmissionItem) {
        val st = dao.getStudentByCode(CloudMappers.normalizeCode(sub.studentCode)) ?: return
        val localExamId = getLocalIdForCloudExam(sub.examCloudId).takeIf { it > 0L }
            ?: dao.getAllExams().first().firstOrNull { CloudMappers.examDocId(it) == sub.examCloudId }?.id
            ?: return
        val existing = dao.getSubmissionsForStudent(st.id).first().firstOrNull { it.examId == localExamId }
        if (existing == null || existing.score != sub.score || existing.answersJson != sub.answersJson || existing.submittedAt != sub.submittedAtMs) {
            dao.upsertSubmission(
                ExamSubmission(
                    id = existing?.id ?: 0L,
                    examId = localExamId,
                    studentId = st.id,
                    score = sub.score,
                    maxScore = sub.maxScore,
                    answersJson = sub.answersJson,
                    submittedAt = sub.submittedAtMs
                )
            )
        }
    }

    private suspend fun upsertLocalResource(res: EducationalResource) {
        val existing = dao.getAllResources().first().firstOrNull {
            it.title == res.title && it.addedDate == res.addedDate && it.fileType == res.fileType
        }
        if (existing == null) {
            dao.insertResource(res.copy(id = 0L))
        }
    }

    private suspend fun upsertLocalSchedule(sched: ClassSchedule) {
        val existing = dao.getAllSchedules().first().firstOrNull {
            it.dayOfWeek == sched.dayOfWeek && it.groupName == sched.groupName &&
                it.startTime == sched.startTime && it.subject == sched.subject
        }
        if (existing == null) {
            dao.insertSchedule(sched.copy(id = 0L))
        }
    }

    private suspend fun upsertLocalAnnouncement(ann: Announcement) {
        val existing = dao.getAllAnnouncements().first().firstOrNull {
            it.title == ann.title && it.date == ann.date && it.groupName == ann.groupName
        }
        if (existing == null) {
            dao.insertAnnouncement(ann.copy(id = 0L))
        }
    }

    private suspend fun upsertLocalQuestion(item: CloudQuestionItem) {
        val q = item.question
        val st = dao.getStudentByCode(CloudMappers.normalizeCode(q.studentCode))
        val all = dao.getAllQuestions().first()
        val existing = all.firstOrNull {
            it.studentCode.equals(q.studentCode, ignoreCase = true) &&
                it.questionText == q.questionText &&
                it.createdDate == q.createdDate
        }
        if (existing == null) {
            dao.insertQuestion(q.copy(id = 0L, studentId = st?.id ?: 0L))
        } else if (existing.isAnswered != q.isAnswered || existing.answerText != q.answerText || existing.isPinned != q.isPinned) {
            dao.updateQuestion(
                existing.copy(
                    answerText = q.answerText,
                    isAnswered = q.isAnswered,
                    isPinned = q.isPinned,
                    answeredDate = q.answeredDate
                )
            )
        }
    }

    private suspend fun upsertLocalMistake(item: CloudMistakeItem) {
        val m = item.mistake
        val st = dao.getStudentByCode(CloudMappers.normalizeCode(m.studentCode)) ?: return
        val localExamId = if (item.examCloudId.isNotBlank()) {
            getLocalIdForCloudExam(item.examCloudId).takeIf { it > 0L }
                ?: dao.getAllExams().first().firstOrNull { CloudMappers.examDocId(it) == item.examCloudId }?.id
                ?: 0L
        } else 0L
        val existing = dao.findExistingMistake(st.id, localExamId, m.questionText)
        if (existing == null) {
            dao.insertMistake(m.copy(id = 0L, studentId = st.id, examId = localExamId))
        } else if (existing.updatedAt < m.updatedAt || existing.isMastered != m.isMastered || existing.practiceAttempts != m.practiceAttempts || existing.personalNote != m.personalNote) {
            dao.updateMistake(
                existing.copy(
                    studentAnswer = m.studentAnswer,
                    mistakeCount = m.mistakeCount,
                    practiceAttempts = m.practiceAttempts,
                    isMastered = m.isMastered,
                    personalNote = m.personalNote,
                    explanation = m.explanation,
                    lastMistakeDate = m.lastMistakeDate,
                    updatedAt = m.updatedAt
                )
            )
        }
    }

    private companion object {
        const val KEY_STUDENT_TEACHER_UID = "student_teacher_uid"
    }
}
