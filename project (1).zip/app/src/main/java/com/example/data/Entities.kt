package com.example.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import org.json.JSONArray
import org.json.JSONObject

@Entity(
    tableName = "students",
    indices = [Index(value = ["code"], unique = true)]
)
data class Student(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val code: String,
    val password: String,
    val name: String,
    val groupName: String,
    val scheduleTime: String,
    val parentPhone: String,
    val monthlyFee: Double = 250.0,
    val createdAt: Long = System.currentTimeMillis()
) {
    companion object {
        private const val UPPER_LETTERS = "ABCDEFGHJKLMNPQRSTUVWXYZ"
        private const val LOWER_LETTERS = "abcdefghijkmnopqrstuvwxyz"
        private const val DIGITS = "0123456789"
        private const val SYMBOLS = "@#$%&*!?"
        private const val ALL_CHARS = UPPER_LETTERS + LOWER_LETTERS + DIGITS + SYMBOLS

        fun generateStrongPassword(): String {
            val random = java.security.SecureRandom()
            val chars = mutableListOf(
                UPPER_LETTERS[random.nextInt(UPPER_LETTERS.length)],
                LOWER_LETTERS[random.nextInt(LOWER_LETTERS.length)],
                DIGITS[random.nextInt(DIGITS.length)],
                SYMBOLS[random.nextInt(SYMBOLS.length)],
                ALL_CHARS[random.nextInt(ALL_CHARS.length)]
            )
            for (i in chars.lastIndex downTo 1) {
                val j = random.nextInt(i + 1)
                val tmp = chars[i]
                chars[i] = chars[j]
                chars[j] = tmp
            }
            return chars.joinToString("")
        }
    }
}

@Entity(
    tableName = "attendance_records",
    indices = [Index(value = ["studentId", "date"], unique = true)]
)
data class AttendanceRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val date: String, // Format: yyyy-MM-dd
    val status: String, // PRESENT, ABSENT, EXCUSED, LATE
    val notes: String = ""
) {
    companion object {
        const val STATUS_PRESENT = "PRESENT"
        const val STATUS_ABSENT = "ABSENT"
        const val STATUS_EXCUSED = "EXCUSED"
        const val STATUS_LATE = "LATE"
    }
}

@Entity(
    tableName = "homework_records",
    indices = [Index(value = ["studentId", "date"], unique = true)]
)
data class HomeworkRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val date: String, // Format: yyyy-MM-dd
    val status: String, // COMPLETED, NOT_COMPLETED, PARTIAL
    val score: String = "10/10",
    val notes: String = ""
) {
    companion object {
        const val STATUS_COMPLETED = "COMPLETED"
        const val STATUS_NOT_COMPLETED = "NOT_COMPLETED"
        const val STATUS_PARTIAL = "PARTIAL"
    }
}

@Entity(tableName = "payment_records")
data class PaymentRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val monthYear: String, // e.g., "نوفمبر 2026"
    val amount: Double,
    val isPaid: Boolean,
    val paymentDate: String = "",
    val notes: String = ""
)

@Entity(tableName = "exams")
data class Exam(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val groupName: String = "الكل",
    val durationMinutes: Int = 30,
    val totalMarks: Int = 20,
    val questionsJson: String = "[]",
    val isActive: Boolean = true,
    val shuffleQuestions: Boolean = false,
    val showResultImmediately: Boolean = true,
    val description: String = "",
    val deadlineDate: String = "", // Optional yyyy-MM-dd
    val allowRetake: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val subject: String = "عام",
    val passingPercentage: Int = 50,
    val shuffleOptions: Boolean = false
) {
    fun isExpired(todayDate: String): Boolean {
        return deadlineDate.isNotBlank() && todayDate > deadlineDate
    }

    fun isPassing(score: Int, maxScore: Int): Boolean {
        if (maxScore <= 0) return true
        return (score * 100) / maxScore >= passingPercentage
    }

    fun parseQuestions(): List<ExamQuestion> {
        val list = mutableListOf<ExamQuestion>()
        try {
            val array = JSONArray(questionsJson)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val optionsArray = obj.optJSONArray("options")
                val options = mutableListOf<String>()
                if (optionsArray != null) {
                    for (j in 0 until optionsArray.length()) {
                        options.add(optionsArray.getString(j))
                    }
                }
                val qType = obj.optString("questionType", ExamQuestion.TYPE_MCQ)
                val normalizedOptions = when {
                    qType == ExamQuestion.TYPE_TRUE_FALSE && options.isEmpty() -> listOf("صح", "خطأ")
                    else -> options
                }
                list.add(
                    ExamQuestion(
                        id = obj.optInt("id", i + 1),
                        questionText = obj.getString("questionText"),
                        options = normalizedOptions,
                        correctOptionIndex = obj.optInt("correctOptionIndex", 0),
                        points = obj.optInt("points", 5),
                        explanation = obj.optString("explanation", ""),
                        imageUri = obj.optString("imageUri", ""),
                        questionType = qType,
                        correctTextAnswer = obj.optString("correctTextAnswer", ""),
                        difficulty = obj.optString("difficulty", ExamQuestion.DIFFICULTY_MEDIUM),
                        topic = obj.optString("topic", "")
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    companion object {
        fun encodeQuestions(questions: List<ExamQuestion>): String {
            val array = JSONArray()
            questions.forEach { q ->
                val obj = JSONObject()
                obj.put("id", q.id)
                obj.put("questionText", q.questionText)
                val opts = JSONArray()
                q.options.forEach { opts.put(it) }
                obj.put("options", opts)
                obj.put("correctOptionIndex", q.correctOptionIndex)
                obj.put("points", q.points)
                obj.put("explanation", q.explanation)
                obj.put("imageUri", q.imageUri)
                obj.put("questionType", q.questionType)
                obj.put("correctTextAnswer", q.correctTextAnswer)
                obj.put("difficulty", q.difficulty)
                obj.put("topic", q.topic)
                array.put(obj)
            }
            return array.toString()
        }
    }
}

data class ExamQuestion(
    val id: Int,
    val questionText: String,
    val options: List<String>,
    val correctOptionIndex: Int,
    val points: Int = 5,
    val explanation: String = "",
    val imageUri: String = "",
    val questionType: String = TYPE_MCQ,
    val correctTextAnswer: String = "",
    val difficulty: String = DIFFICULTY_MEDIUM,
    val topic: String = ""
) {
    fun shuffledForDisplay(): List<Pair<Int, String>> {
        val indexed = options.mapIndexed { idx, text -> idx to text }
        if (questionType != TYPE_MCQ || options.size < 2) {
            return indexed
        }
        return indexed.shuffled()
    }

    companion object {
        const val TYPE_MCQ = "MCQ"
        const val TYPE_TRUE_FALSE = "TRUE_FALSE"
        const val TYPE_SHORT_ANSWER = "SHORT_ANSWER"

        const val DIFFICULTY_EASY = "EASY"
        const val DIFFICULTY_MEDIUM = "MEDIUM"
        const val DIFFICULTY_HARD = "HARD"

        fun difficultyLabel(difficulty: String): String = when (difficulty) {
            DIFFICULTY_EASY -> "سهل"
            DIFFICULTY_HARD -> "صعب"
            else -> "متوسط"
        }

        fun normalizeShortAnswer(raw: String): String {
            return raw.trim()
                .lowercase()
                .replace("أ", "ا")
                .replace("إ", "ا")
                .replace("آ", "ا")
                .replace("ى", "ي")
                .replace("ة", "ه")
                .replace(Regex("\\s+"), " ")
        }
    }
}

@Entity(tableName = "question_bank")
data class QuestionBankItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subject: String = "عام",
    val questionText: String,
    val optionsJson: String,
    val correctOptionIndex: Int,
    val points: Int = 5,
    val explanation: String = "",
    val imageUri: String = "",
    val questionType: String = ExamQuestion.TYPE_MCQ,
    val correctTextAnswer: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val difficulty: String = ExamQuestion.DIFFICULTY_MEDIUM,
    val topic: String = ""
) {
    fun parseOptions(): List<String> {
        val list = mutableListOf<String>()
        try {
            val arr = JSONArray(optionsJson)
            for (i in 0 until arr.length()) {
                list.add(arr.getString(i))
            }
        } catch (_: Exception) {}
        return list
    }

    fun toExamQuestion(questionNumber: Int): ExamQuestion {
        val opts = when (questionType) {
            ExamQuestion.TYPE_TRUE_FALSE -> listOf("صح", "خطأ")
            ExamQuestion.TYPE_SHORT_ANSWER -> emptyList()
            else -> parseOptions().ifEmpty { listOf("أ", "ب", "ج", "د") }
        }
        return ExamQuestion(
            id = questionNumber,
            questionText = questionText,
            options = opts,
            correctOptionIndex = if (opts.isNotEmpty()) correctOptionIndex.coerceIn(0, opts.lastIndex) else 0,
            points = points,
            explanation = explanation,
            imageUri = imageUri,
            questionType = questionType,
            correctTextAnswer = correctTextAnswer,
            difficulty = difficulty,
            topic = topic
        )
    }

    companion object {
        fun encodeOptions(options: List<String>): String {
            val arr = JSONArray()
            options.forEach { arr.put(it) }
            return arr.toString()
        }
    }
}

@Entity(tableName = "class_schedules")
data class ClassSchedule(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dayOfWeek: Int, // 1 = السبت ... 7 = الجمعة
    val dayName: String,
    val groupName: String,
    val subject: String = "",
    val startTime: String,
    val endTime: String = "",
    val location: String = "",
    val notes: String = ""
) {
    companion object {
        val DAYS = listOf(
            1 to "السبت",
            2 to "الأحد",
            3 to "الاثنين",
            4 to "الثلاثاء",
            5 to "الأربعاء",
            6 to "الخميس",
            7 to "الجمعة"
        )

        fun dayNameFor(dayOfWeek: Int): String {
            return DAYS.firstOrNull { it.first == dayOfWeek }?.second ?: "السبت"
        }
    }
}

@Entity(
    tableName = "exam_submissions",
    indices = [Index(value = ["examId", "studentId"], unique = true)]
)
data class ExamSubmission(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val examId: Long,
    val studentId: Long,
    val score: Int,
    val maxScore: Int,
    val answersJson: String = "{}",
    val submittedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "parent_notes")
data class ParentNote(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val title: String,
    val content: String,
    val date: String,
    val teacherName: String = "الأستاذ",
    val audioFilePath: String = "",
    val audioDurationSeconds: Int = 0
) {
    fun hasAudio(): Boolean = audioFilePath.isNotBlank()

    fun displaySummary(): String {
        val text = content.trim()
        return when {
            text.isNotBlank() && hasAudio() -> "$text (+ ملاحظة صوتية ${audioDurationSeconds} ث)"
            text.isNotBlank() -> text
            hasAudio() -> "🎙️ ملاحظة صوتية (${audioDurationSeconds} ثانية)"
            else -> ""
        }
    }
}

@Entity(tableName = "student_questions")
data class StudentQuestion(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val studentName: String,
    val studentCode: String,
    val groupName: String,
    val subject: String = "عام",
    val questionText: String,
    val questionImagePath: String = "",
    val answerText: String = "",
    val answerAudioPath: String = "",
    val answerAudioDuration: Int = 0,
    val isAnswered: Boolean = false,
    val isPinned: Boolean = false,
    val isPublicToGroup: Boolean = true,
    val createdDate: String,
    val answeredDate: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "educational_resources")
data class EducationalResource(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val subject: String,
    val groupName: String = "الكل",
    val description: String,
    val fileType: String, // "PDF", "ملخص مراجعة", "بنك أسئلة", "فيديو شرح"
    val resourceContent: String = "",
    val localFilePath: String = "",
    val externalUrl: String = "",
    val addedDate: String
)

@Entity(tableName = "announcements")
data class Announcement(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val content: String,
    val groupName: String = "الكل",
    val date: String,
    val isUrgent: Boolean = false
)

@Entity(
    tableName = "pending_sync_ops",
    indices = [Index(value = ["syncKey"], unique = true)]
)
data class PendingSyncOp(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val syncKey: String,
    val entityType: String,
    val payloadJson: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val retryCount: Int = 0
) {
    companion object {
        const val TYPE_UPSERT_STUDENT = "UPSERT_STUDENT"
        const val TYPE_DELETE_STUDENT = "DELETE_STUDENT"
        const val TYPE_UPSERT_ATTENDANCE = "UPSERT_ATTENDANCE"
        const val TYPE_UPSERT_HOMEWORK = "UPSERT_HOMEWORK"
        const val TYPE_UPSERT_PAYMENT = "UPSERT_PAYMENT"
        const val TYPE_UPSERT_EXAM = "UPSERT_EXAM"
        const val TYPE_UPSERT_SUBMISSION = "UPSERT_SUBMISSION"
        const val TYPE_UPSERT_NOTE = "UPSERT_NOTE"
        const val TYPE_UPSERT_QUESTION = "UPSERT_QUESTION"
        const val TYPE_UPSERT_RESOURCE = "UPSERT_RESOURCE"
        const val TYPE_UPSERT_ANNOUNCEMENT = "UPSERT_ANNOUNCEMENT"
        const val TYPE_UPSERT_SCHEDULE = "UPSERT_SCHEDULE"
        const val TYPE_UPSERT_MISTAKE = "UPSERT_MISTAKE"

        fun studentKey(studentCode: String): String =
            "STUDENT:${studentCode.trim().uppercase(java.util.Locale.ENGLISH)}"

        fun attendanceKey(studentId: Long, date: String): String =
            "ATT:$studentId:$date"

        fun homeworkKey(studentId: Long, date: String): String =
            "HW:$studentId:$date"

        fun paymentKey(studentId: Long, monthYear: String): String =
            "PAY:$studentId:$monthYear"

        fun examKey(examId: Long): String = "EXAM:$examId"
        fun submissionKey(examId: Long, studentCode: String): String =
            "SUB:$examId:${studentCode.trim().uppercase(java.util.Locale.ENGLISH)}"
        fun noteKey(studentId: Long, createdAt: Long): String = "NOTE:$studentId:$createdAt"
        fun questionKey(questionId: Long): String = "QA:$questionId"
        fun resourceKey(title: String, addedDate: String): String = "RES:${title.hashCode()}:$addedDate"
        fun announcementKey(title: String, date: String): String = "ANN:${title.hashCode()}:$date"
        fun scheduleKey(scheduleId: Long): String = "SCHED:$scheduleId"
        fun mistakeKey(mistakeId: Long): String = "MISTAKE:$mistakeId"
    }
}

@Entity(
    tableName = "mistake_bank",
    indices = [Index(value = ["studentId"]), Index(value = ["examId"])]
)
data class MistakeRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val studentCode: String,
    val studentName: String,
    val examId: Long = 0,
    val examTitle: String = "مراجعة يدوية",
    val subject: String = "عام",
    val questionId: Int = 0,
    val questionText: String,
    val questionType: String = ExamQuestion.TYPE_MCQ,
    val optionsJson: String = "[]",
    val studentAnswer: String,
    val correctAnswer: String,
    val correctOptionIndex: Int = 0,
    val explanation: String = "",
    val difficulty: String = ExamQuestion.DIFFICULTY_MEDIUM,
    val personalNote: String = "",
    val mistakeCount: Int = 1,
    val practiceAttempts: Int = 0,
    val isMastered: Boolean = false,
    val lastMistakeDate: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun parseOptions(): List<String> {
        val list = mutableListOf<String>()
        try {
            val arr = JSONArray(optionsJson)
            for (i in 0 until arr.length()) {
                list.add(arr.getString(i))
            }
        } catch (_: Exception) {}
        return list
    }

    fun toExamQuestion(questionNumber: Int): ExamQuestion {
        val opts = when (questionType) {
            ExamQuestion.TYPE_TRUE_FALSE -> listOf("صح", "خطأ")
            ExamQuestion.TYPE_SHORT_ANSWER -> emptyList()
            else -> parseOptions().ifEmpty { listOf("أ", "ب", "ج", "د") }
        }
        return ExamQuestion(
            id = questionNumber,
            questionText = questionText,
            options = opts,
            correctOptionIndex = if (opts.isNotEmpty()) correctOptionIndex.coerceIn(0, opts.lastIndex) else 0,
            points = 5,
            explanation = explanation,
            questionType = questionType,
            correctTextAnswer = if (questionType == ExamQuestion.TYPE_SHORT_ANSWER) correctAnswer else "",
            difficulty = difficulty,
            topic = subject
        )
    }
}


