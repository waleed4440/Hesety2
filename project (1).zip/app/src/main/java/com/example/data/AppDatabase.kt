package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        Student::class,
        AttendanceRecord::class,
        HomeworkRecord::class,
        PaymentRecord::class,
        Exam::class,
        ExamSubmission::class,
        ParentNote::class,
        EducationalResource::class,
        Announcement::class,
        QuestionBankItem::class,
        ClassSchedule::class,
        StudentQuestion::class,
        PendingSyncOp::class,
        MistakeRecord::class
    ],
    version = 7,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `pending_sync_ops` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `syncKey` TEXT NOT NULL,
                        `entityType` TEXT NOT NULL,
                        `payloadJson` TEXT NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        `retryCount` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    "CREATE UNIQUE INDEX IF NOT EXISTS `index_pending_sync_ops_syncKey` ON `pending_sync_ops` (`syncKey`)"
                )
            }
        }

        val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `exams` ADD COLUMN `subject` TEXT NOT NULL DEFAULT 'عام'")
                db.execSQL("ALTER TABLE `exams` ADD COLUMN `passingPercentage` INTEGER NOT NULL DEFAULT 50")
                db.execSQL("ALTER TABLE `exams` ADD COLUMN `shuffleOptions` INTEGER NOT NULL DEFAULT 0")

                db.execSQL("ALTER TABLE `question_bank` ADD COLUMN `difficulty` TEXT NOT NULL DEFAULT 'MEDIUM'")
                db.execSQL("ALTER TABLE `question_bank` ADD COLUMN `topic` TEXT NOT NULL DEFAULT ''")

                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `mistake_bank` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `studentId` INTEGER NOT NULL,
                        `studentCode` TEXT NOT NULL,
                        `studentName` TEXT NOT NULL,
                        `examId` INTEGER NOT NULL,
                        `examTitle` TEXT NOT NULL,
                        `subject` TEXT NOT NULL,
                        `questionId` INTEGER NOT NULL,
                        `questionText` TEXT NOT NULL,
                        `questionType` TEXT NOT NULL,
                        `optionsJson` TEXT NOT NULL,
                        `studentAnswer` TEXT NOT NULL,
                        `correctAnswer` TEXT NOT NULL,
                        `correctOptionIndex` INTEGER NOT NULL,
                        `explanation` TEXT NOT NULL,
                        `difficulty` TEXT NOT NULL,
                        `personalNote` TEXT NOT NULL,
                        `mistakeCount` INTEGER NOT NULL,
                        `practiceAttempts` INTEGER NOT NULL,
                        `isMastered` INTEGER NOT NULL,
                        `lastMistakeDate` TEXT NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS `index_mistake_bank_studentId` ON `mistake_bank` (`studentId`)"
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS `index_mistake_bank_examId` ON `mistake_bank` (`examId`)"
                )
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "teacher_assistant_database"
                )
                    .addMigrations(MIGRATION_5_6, MIGRATION_6_7)
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
