package com.example.data.remote

import android.content.Context
import com.example.R
import com.example.data.Announcement
import com.example.data.AttendanceRecord
import com.example.data.ClassSchedule
import com.example.data.EducationalResource
import com.example.data.Exam
import com.example.data.ExamSubmission
import com.example.data.HomeworkRecord
import com.example.data.MistakeRecord
import com.example.data.ParentNote
import com.example.data.PaymentRecord
import com.example.data.Student
import com.example.data.StudentQuestion
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

data class CloudSubmissionItem(
    val docId: String,
    val examCloudId: String,
    val studentCode: String,
    val score: Int,
    val maxScore: Int,
    val answersJson: String,
    val submittedAtMs: Long
)

data class CloudExamItem(
    val docId: String,
    val exam: Exam
)

data class CloudQuestionItem(
    val docId: String,
    val question: StudentQuestion
)

data class CloudMistakeItem(
    val docId: String,
    val examCloudId: String,
    val mistake: MistakeRecord
)

data class CloudStudentHydrationBundle(
    val teacherUid: String,
    val student: Student,
    val attendances: List<AttendanceRecord>,
    val homeworks: List<HomeworkRecord>,
    val payments: List<PaymentRecord>,
    val notes: List<ParentNote>,
    val exams: List<CloudExamItem>,
    val submissions: List<CloudSubmissionItem>,
    val resources: List<EducationalResource>,
    val schedules: List<ClassSchedule>,
    val announcements: List<Announcement>,
    val questions: List<CloudQuestionItem>,
    val mistakes: List<CloudMistakeItem>
)

data class CloudTeacherHydrationBundle(
    val teacherUid: String,
    val students: List<Student>,
    val attendancesByCode: List<Pair<String, AttendanceRecord>>,
    val homeworksByCode: List<Pair<String, HomeworkRecord>>,
    val paymentsByCode: List<Pair<String, PaymentRecord>>,
    val notesByCode: List<Pair<String, ParentNote>>,
    val exams: List<CloudExamItem>,
    val submissions: List<CloudSubmissionItem>,
    val resources: List<EducationalResource>,
    val schedules: List<ClassSchedule>,
    val announcements: List<Announcement>,
    val questions: List<CloudQuestionItem>,
    val mistakes: List<CloudMistakeItem>
)

class CloudClassroomRepository(
    val db: FirebaseFirestore,
    val auth: FirebaseAuth
) {
    constructor(context: Context) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        auth = Firebase.auth
    )

    // Cached studentCode -> memberUid and all enrolled memberUids for active teacher session
    private val memberUidByCode = ConcurrentHashMap<String, String>()
    private val allMemberUids = ConcurrentHashMap.newKeySet<String>()

    fun requireUserId(): String =
        auth.currentUser?.uid ?: throw IllegalStateException("المستخدم غير مسجل الدخول عبر Google")

    fun updateCachedMembers(codeToUid: Map<String, String>) {
        memberUidByCode.clear()
        codeToUid.forEach { (k, v) ->
            if (k.isNotBlank() && v.isNotBlank()) {
                memberUidByCode[CloudMappers.normalizeCode(k)] = v
            }
        }
        allMemberUids.clear()
        allMemberUids.addAll(codeToUid.values.filter { it.isNotBlank() }.take(200))
    }

    private fun currentMemberUidsList(): List<String> = allMemberUids.toList().take(200)

    private suspend fun resolveStudentAuthUid(teacherUid: String, studentCode: String): String {
        val norm = CloudMappers.normalizeCode(studentCode)
        val cached = memberUidByCode[norm]
        if (!cached.isNullOrBlank()) return cached
        return try {
            val doc = db.collection("student_passes")
                .document(CloudMappers.studentPassId(norm))
                .get()
                .await()
            val uid = doc.getString("studentAuthUid") ?: ""
            if (uid.isNotBlank()) {
                memberUidByCode[norm] = uid
                allMemberUids.add(uid)
            }
            uid
        } catch (_: Exception) {
            ""
        }
    }

    private fun classroomRef(teacherUid: String) = db.collection("classrooms").document(teacherUid)

    private suspend fun safeUpsert(
        path: String,
        docRef: com.google.firebase.firestore.DocumentReference,
        createMap: Map<String, Any>,
        updateMap: Map<String, Any>
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val snap = docRef.get().await()
            if (snap.exists()) {
                docRef.update(updateMap).await()
            } else {
                docRef.set(createMap).await()
            }
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    private suspend fun safeStudentUpsert(
        uid: String,
        teacherUid: String,
        normCode: String,
        manifestField: String,
        docId: String,
        docRef: com.google.firebase.firestore.DocumentReference,
        createMap: Map<String, Any>,
        updateMap: Map<String, Any>
    ): Result<String> = withContext(Dispatchers.IO) {
        if (uid == teacherUid) {
            return@withContext safeUpsert(docRef.path, docRef, createMap, updateMap)
        }
        try {
            val manifestRef = classroomRef(teacherUid)
                .collection("student_manifests")
                .document(CloudMappers.studentDocId(normCode))
            val manifestSnap = manifestRef.get().await()
            val ids = manifestSnap.get(manifestField) as? List<*>
            val existsAlready = ids?.contains(docId) == true
            if (existsAlready) {
                docRef.update(updateMap).await()
            } else {
                docRef.set(createMap).await()
            }
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun ensureTeacherClassroom(teacherName: String = "الأستاذ"): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                val uid = requireUserId()
                val profileRef = classroomRef(uid)
                val cleanName = teacherName.trim().ifBlank { "الأستاذ" }.take(200)
                if (!profileRef.get().await().exists()) {
                    profileRef.set(
                        mapOf(
                            "teacherUid" to uid,
                            "teacherName" to cleanName,
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
                val catalogRef = profileRef.collection("catalog").document("meta")
                if (!catalogRef.get().await().exists()) {
                    catalogRef.set(
                        mapOf(
                            "ownerUid" to uid,
                            "examIds" to emptyList<String>(),
                            "resourceIds" to emptyList<String>(),
                            "scheduleIds" to emptyList<String>(),
                            "announcementIds" to emptyList<String>(),
                            "publicQuestionIds" to emptyList<String>(),
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
                Result.success(uid)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.WRITE, "classrooms")
                Result.failure(e)
            }
        }

    private suspend fun ensureManifestAndAddId(
        teacherUid: String,
        studentCode: String,
        studentAuthUid: String,
        field: String,
        docId: String
    ) {
        val normCode = CloudMappers.normalizeCode(studentCode)
        val manifestRef = classroomRef(teacherUid)
            .collection("student_manifests")
            .document(CloudMappers.studentDocId(normCode))
        val snap = manifestRef.get().await()
        if (!snap.exists()) {
            val base = mutableMapOf<String, Any>(
                "ownerUid" to teacherUid,
                "studentCode" to normCode,
                "studentAuthUid" to studentAuthUid,
                "attendanceIds" to emptyList<String>(),
                "homeworkIds" to emptyList<String>(),
                "paymentIds" to emptyList<String>(),
                "noteIds" to emptyList<String>(),
                "submissionIds" to emptyList<String>(),
                "mistakeIds" to emptyList<String>(),
                "questionIds" to emptyList<String>(),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (field.isNotBlank() && docId.isNotBlank()) {
                base[field] = listOf(docId)
            }
            manifestRef.set(base).await()
        } else {
            val updates = mutableMapOf<String, Any>("updatedAt" to FieldValue.serverTimestamp())
            if (studentAuthUid.isNotBlank()) {
                updates["studentAuthUid"] = studentAuthUid
            }
            if (field.isNotBlank() && docId.isNotBlank()) {
                updates[field] = FieldValue.arrayUnion(docId)
            }
            manifestRef.update(updates).await()
        }
    }

    private suspend fun addCatalogId(teacherUid: String, field: String, docId: String) {
        val catalogRef = classroomRef(teacherUid).collection("catalog").document("meta")
        if (!catalogRef.get().await().exists()) {
            ensureTeacherClassroom()
        }
        catalogRef.update(
            mapOf(
                field to FieldValue.arrayUnion(docId),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
    }

    suspend fun upsertStudent(student: Student): Result<String> = withContext(Dispatchers.IO) {
        try {
            val teacherUid = requireUserId()
            ensureTeacherClassroom().getOrThrow()
            val normCode = CloudMappers.normalizeCode(student.code)
            val passId = CloudMappers.studentPassId(normCode)
            val sDocId = CloudMappers.studentDocId(normCode)
            val sAuthUid = resolveStudentAuthUid(teacherUid, normCode)

            val passRef = db.collection("student_passes").document(passId)
            safeUpsert(
                passRef.path,
                passRef,
                CloudMappers.studentPassCreateMap(teacherUid, student, sAuthUid),
                CloudMappers.studentPassUpdateMap(student, sAuthUid)
            ).getOrThrow()

            val studentRef = classroomRef(teacherUid).collection("students").document(sDocId)
            safeUpsert(
                studentRef.path,
                studentRef,
                CloudMappers.studentCreateMap(teacherUid, student, sAuthUid),
                CloudMappers.studentUpdateMap(student, sAuthUid)
            ).getOrThrow()

            ensureManifestAndAddId(teacherUid, normCode, sAuthUid, "", "")
            Result.success(sDocId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "students")
            Result.failure(e)
        }
    }

    suspend fun deleteStudent(studentCode: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val teacherUid = requireUserId()
            val normCode = CloudMappers.normalizeCode(studentCode)
            val sDocId = CloudMappers.studentDocId(normCode)
            val passId = CloudMappers.studentPassId(normCode)
            classroomRef(teacherUid).collection("students").document(sDocId).delete().await()
            classroomRef(teacherUid).collection("student_manifests").document(sDocId).delete().await()
            db.collection("student_passes").document(passId).delete().await()
            memberUidByCode.remove(normCode)?.let { allMemberUids.remove(it) }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, "students/$studentCode")
            Result.failure(e)
        }
    }

    suspend fun upsertAttendance(studentCode: String, record: AttendanceRecord): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                val teacherUid = requireUserId()
                val normCode = CloudMappers.normalizeCode(studentCode)
                val docId = CloudMappers.attendanceDocId(normCode, record.date)
                val sAuthUid = resolveStudentAuthUid(teacherUid, normCode)
                val docRef = classroomRef(teacherUid).collection("attendance").document(docId)
                val res = safeUpsert(
                    docRef.path,
                    docRef,
                    mapOf(
                        "ownerUid" to teacherUid,
                        "studentAuthUid" to sAuthUid,
                        "studentCode" to normCode,
                        "date" to record.date.trim().take(32),
                        "status" to record.status.trim().take(32),
                        "notes" to record.notes.take(500),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    ),
                    mapOf(
                        "studentAuthUid" to sAuthUid,
                        "date" to record.date.trim().take(32),
                        "status" to record.status.trim().take(32),
                        "notes" to record.notes.take(500),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                if (res.isSuccess) {
                    ensureManifestAndAddId(teacherUid, normCode, sAuthUid, "attendanceIds", docId)
                }
                res
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.WRITE, "attendance")
                Result.failure(e)
            }
        }

    suspend fun upsertHomework(studentCode: String, record: HomeworkRecord): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                val teacherUid = requireUserId()
                val normCode = CloudMappers.normalizeCode(studentCode)
                val docId = CloudMappers.homeworkDocId(normCode, record.date)
                val sAuthUid = resolveStudentAuthUid(teacherUid, normCode)
                val docRef = classroomRef(teacherUid).collection("homework").document(docId)
                val res = safeUpsert(
                    docRef.path,
                    docRef,
                    mapOf(
                        "ownerUid" to teacherUid,
                        "studentAuthUid" to sAuthUid,
                        "studentCode" to normCode,
                        "date" to record.date.trim().take(32),
                        "status" to record.status.trim().take(32),
                        "score" to record.score.take(64),
                        "notes" to record.notes.take(500),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    ),
                    mapOf(
                        "studentAuthUid" to sAuthUid,
                        "date" to record.date.trim().take(32),
                        "status" to record.status.trim().take(32),
                        "score" to record.score.take(64),
                        "notes" to record.notes.take(500),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                if (res.isSuccess) {
                    ensureManifestAndAddId(teacherUid, normCode, sAuthUid, "homeworkIds", docId)
                }
                res
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.WRITE, "homework")
                Result.failure(e)
            }
        }

    suspend fun upsertPayment(studentCode: String, record: PaymentRecord): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                val teacherUid = requireUserId()
                val normCode = CloudMappers.normalizeCode(studentCode)
                val docId = CloudMappers.paymentDocId(normCode, record.monthYear)
                val sAuthUid = resolveStudentAuthUid(teacherUid, normCode)
                val docRef = classroomRef(teacherUid).collection("payments").document(docId)
                val res = safeUpsert(
                    docRef.path,
                    docRef,
                    mapOf(
                        "ownerUid" to teacherUid,
                        "studentAuthUid" to sAuthUid,
                        "studentCode" to normCode,
                        "monthYear" to record.monthYear.trim().take(64),
                        "amount" to record.amount.coerceAtLeast(0.0),
                        "isPaid" to record.isPaid,
                        "paymentDate" to record.paymentDate.take(64),
                        "notes" to record.notes.take(500),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    ),
                    mapOf(
                        "studentAuthUid" to sAuthUid,
                        "monthYear" to record.monthYear.trim().take(64),
                        "amount" to record.amount.coerceAtLeast(0.0),
                        "isPaid" to record.isPaid,
                        "paymentDate" to record.paymentDate.take(64),
                        "notes" to record.notes.take(500),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                if (res.isSuccess) {
                    ensureManifestAndAddId(teacherUid, normCode, sAuthUid, "paymentIds", docId)
                }
                res
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.WRITE, "payments")
                Result.failure(e)
            }
        }

    suspend fun upsertParentNote(studentCode: String, note: ParentNote): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                val teacherUid = requireUserId()
                val normCode = CloudMappers.normalizeCode(studentCode)
                val docId = CloudMappers.noteDocId(normCode, note)
                val sAuthUid = resolveStudentAuthUid(teacherUid, normCode)
                val docRef = classroomRef(teacherUid).collection("parent_notes").document(docId)
                val res = safeUpsert(
                    docRef.path,
                    docRef,
                    mapOf(
                        "ownerUid" to teacherUid,
                        "studentAuthUid" to sAuthUid,
                        "studentCode" to normCode,
                        "title" to note.title.trim().ifBlank { "ملاحظة" }.take(200),
                        "content" to note.content.take(4000),
                        "date" to note.date.trim().take(32),
                        "teacherName" to note.teacherName.take(120),
                        "audioDurationSeconds" to note.audioDurationSeconds,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    ),
                    mapOf(
                        "studentAuthUid" to sAuthUid,
                        "title" to note.title.trim().ifBlank { "ملاحظة" }.take(200),
                        "content" to note.content.take(4000),
                        "date" to note.date.trim().take(32),
                        "teacherName" to note.teacherName.take(120),
                        "audioDurationSeconds" to note.audioDurationSeconds,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                if (res.isSuccess) {
                    ensureManifestAndAddId(teacherUid, normCode, sAuthUid, "noteIds", docId)
                }
                res
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.WRITE, "parent_notes")
                Result.failure(e)
            }
        }

    suspend fun upsertExam(exam: Exam, mappedCloudId: String? = null): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                val teacherUid = requireUserId()
                ensureTeacherClassroom().getOrThrow()
                val docId = CloudMappers.examDocId(exam, mappedCloudId)
                val docRef = classroomRef(teacherUid).collection("exams").document(docId)
                val questionsList = CloudMappers.questionsToNativeList(exam.parseQuestions())
                val members = currentMemberUidsList()
                val res = safeUpsert(
                    docRef.path,
                    docRef,
                    mapOf(
                        "ownerUid" to teacherUid,
                        "memberUids" to members,
                        "title" to exam.title.trim().take(200),
                        "groupName" to exam.groupName.trim().ifBlank { "الكل" }.take(120),
                        "durationMinutes" to exam.durationMinutes.coerceAtLeast(1),
                        "totalMarks" to exam.totalMarks.coerceAtLeast(1),
                        "questions" to questionsList,
                        "isActive" to exam.isActive,
                        "shuffleQuestions" to exam.shuffleQuestions,
                        "showResultImmediately" to exam.showResultImmediately,
                        "description" to exam.description.take(2000),
                        "deadlineDate" to exam.deadlineDate.take(64),
                        "allowRetake" to exam.allowRetake,
                        "localCreatedAt" to exam.createdAt,
                        "subject" to exam.subject.take(120),
                        "passingPercentage" to exam.passingPercentage,
                        "shuffleOptions" to exam.shuffleOptions,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    ),
                    mapOf(
                        "memberUids" to members,
                        "title" to exam.title.trim().take(200),
                        "groupName" to exam.groupName.trim().ifBlank { "الكل" }.take(120),
                        "durationMinutes" to exam.durationMinutes.coerceAtLeast(1),
                        "totalMarks" to exam.totalMarks.coerceAtLeast(1),
                        "questions" to questionsList,
                        "isActive" to exam.isActive,
                        "shuffleQuestions" to exam.shuffleQuestions,
                        "showResultImmediately" to exam.showResultImmediately,
                        "description" to exam.description.take(2000),
                        "deadlineDate" to exam.deadlineDate.take(64),
                        "allowRetake" to exam.allowRetake,
                        "localCreatedAt" to exam.createdAt,
                        "subject" to exam.subject.take(120),
                        "passingPercentage" to exam.passingPercentage,
                        "shuffleOptions" to exam.shuffleOptions,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                if (res.isSuccess) {
                    addCatalogId(teacherUid, "examIds", docId)
                }
                res
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.WRITE, "exams")
                Result.failure(e)
            }
        }

    suspend fun deleteExam(examCloudId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val teacherUid = requireUserId()
            classroomRef(teacherUid).collection("exams").document(examCloudId).delete().await()
            classroomRef(teacherUid).collection("catalog").document("meta").update(
                mapOf(
                    "examIds" to FieldValue.arrayRemove(examCloudId),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, "exams/$examCloudId")
            Result.failure(e)
        }
    }

    suspend fun upsertExamSubmission(
        teacherUid: String,
        examCloudId: String,
        studentCode: String,
        submission: ExamSubmission
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val uid = requireUserId()
            val normCode = CloudMappers.normalizeCode(studentCode)
            val docId = CloudMappers.submissionDocId(examCloudId, normCode)
            val sAuthUid = if (uid == teacherUid) resolveStudentAuthUid(teacherUid, normCode) else uid
            val docRef = classroomRef(teacherUid).collection("exam_submissions").document(docId)
            val answersMap = CloudMappers.answersJsonToNativeMap(submission.answersJson)
            val res = safeStudentUpsert(
                uid = uid,
                teacherUid = teacherUid,
                normCode = normCode,
                manifestField = "submissionIds",
                docId = docId,
                docRef = docRef,
                createMap = mapOf(
                    "ownerUid" to teacherUid,
                    "studentAuthUid" to sAuthUid,
                    "examCloudId" to examCloudId,
                    "studentCode" to normCode,
                    "score" to submission.score.coerceAtLeast(0),
                    "maxScore" to submission.maxScore.coerceAtLeast(1),
                    "answers" to answersMap,
                    "submittedAtMs" to submission.submittedAt,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                updateMap = mapOf(
                    "studentAuthUid" to sAuthUid,
                    "score" to submission.score.coerceAtLeast(0),
                    "maxScore" to submission.maxScore.coerceAtLeast(1),
                    "answers" to answersMap,
                    "submittedAtMs" to submission.submittedAt,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            if (res.isSuccess) {
                ensureManifestAndAddId(teacherUid, normCode, sAuthUid, "submissionIds", docId)
            }
            res
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "exam_submissions")
            Result.failure(e)
        }
    }

    suspend fun upsertResource(resource: EducationalResource): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                val teacherUid = requireUserId()
                ensureTeacherClassroom().getOrThrow()
                val docId = CloudMappers.resourceDocId(resource)
                val docRef = classroomRef(teacherUid).collection("educational_resources").document(docId)
                val members = currentMemberUidsList()
                val res = safeUpsert(
                    docRef.path,
                    docRef,
                    mapOf(
                        "ownerUid" to teacherUid,
                        "memberUids" to members,
                        "title" to resource.title.trim().take(200),
                        "subject" to resource.subject.trim().ifBlank { "عام" }.take(120),
                        "groupName" to resource.groupName.trim().ifBlank { "الكل" }.take(120),
                        "description" to resource.description.take(2000),
                        "fileType" to resource.fileType.trim().ifBlank { "ملخص" }.take(64),
                        "resourceContent" to resource.resourceContent.take(15000),
                        "externalUrl" to resource.externalUrl.take(1000),
                        "addedDate" to resource.addedDate.trim().take(32),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    ),
                    mapOf(
                        "memberUids" to members,
                        "title" to resource.title.trim().take(200),
                        "subject" to resource.subject.trim().ifBlank { "عام" }.take(120),
                        "groupName" to resource.groupName.trim().ifBlank { "الكل" }.take(120),
                        "description" to resource.description.take(2000),
                        "fileType" to resource.fileType.trim().ifBlank { "ملخص" }.take(64),
                        "resourceContent" to resource.resourceContent.take(15000),
                        "externalUrl" to resource.externalUrl.take(1000),
                        "addedDate" to resource.addedDate.trim().take(32),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                if (res.isSuccess) addCatalogId(teacherUid, "resourceIds", docId)
                res
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.WRITE, "educational_resources")
                Result.failure(e)
            }
        }

    suspend fun deleteResource(resource: EducationalResource): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                val teacherUid = requireUserId()
                val docId = CloudMappers.resourceDocId(resource)
                classroomRef(teacherUid).collection("educational_resources").document(docId).delete().await()
                classroomRef(teacherUid).collection("catalog").document("meta").update(
                    mapOf("resourceIds" to FieldValue.arrayRemove(docId), "updatedAt" to FieldValue.serverTimestamp())
                ).await()
                Result.success(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.DELETE, "educational_resources")
                Result.failure(e)
            }
        }

    suspend fun upsertSchedule(schedule: ClassSchedule): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                val teacherUid = requireUserId()
                ensureTeacherClassroom().getOrThrow()
                val docId = CloudMappers.scheduleDocId(schedule)
                val docRef = classroomRef(teacherUid).collection("class_schedules").document(docId)
                val members = currentMemberUidsList()
                val res = safeUpsert(
                    docRef.path,
                    docRef,
                    mapOf(
                        "ownerUid" to teacherUid,
                        "memberUids" to members,
                        "dayOfWeek" to schedule.dayOfWeek.coerceIn(1, 7),
                        "dayName" to schedule.dayName.trim().take(40),
                        "groupName" to schedule.groupName.trim().ifBlank { "الكل" }.take(120),
                        "subject" to schedule.subject.take(120),
                        "startTime" to schedule.startTime.trim().take(64),
                        "endTime" to schedule.endTime.take(64),
                        "location" to schedule.location.take(200),
                        "notes" to schedule.notes.take(1000),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    ),
                    mapOf(
                        "memberUids" to members,
                        "dayOfWeek" to schedule.dayOfWeek.coerceIn(1, 7),
                        "dayName" to schedule.dayName.trim().take(40),
                        "groupName" to schedule.groupName.trim().ifBlank { "الكل" }.take(120),
                        "subject" to schedule.subject.take(120),
                        "startTime" to schedule.startTime.trim().take(64),
                        "endTime" to schedule.endTime.take(64),
                        "location" to schedule.location.take(200),
                        "notes" to schedule.notes.take(1000),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                if (res.isSuccess) addCatalogId(teacherUid, "scheduleIds", docId)
                res
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.WRITE, "class_schedules")
                Result.failure(e)
            }
        }

    suspend fun deleteSchedule(schedule: ClassSchedule): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                val teacherUid = requireUserId()
                val docId = CloudMappers.scheduleDocId(schedule)
                classroomRef(teacherUid).collection("class_schedules").document(docId).delete().await()
                classroomRef(teacherUid).collection("catalog").document("meta").update(
                    mapOf("scheduleIds" to FieldValue.arrayRemove(docId), "updatedAt" to FieldValue.serverTimestamp())
                ).await()
                Result.success(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.DELETE, "class_schedules")
                Result.failure(e)
            }
        }

    suspend fun upsertAnnouncement(announcement: Announcement): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                val teacherUid = requireUserId()
                ensureTeacherClassroom().getOrThrow()
                val docId = CloudMappers.announcementDocId(announcement)
                val docRef = classroomRef(teacherUid).collection("announcements").document(docId)
                val members = currentMemberUidsList()
                val res = safeUpsert(
                    docRef.path,
                    docRef,
                    mapOf(
                        "ownerUid" to teacherUid,
                        "memberUids" to members,
                        "title" to announcement.title.trim().take(200),
                        "content" to announcement.content.trim().take(4000),
                        "groupName" to announcement.groupName.trim().ifBlank { "الكل" }.take(120),
                        "date" to announcement.date.trim().take(32),
                        "isUrgent" to announcement.isUrgent,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    ),
                    mapOf(
                        "memberUids" to members,
                        "title" to announcement.title.trim().take(200),
                        "content" to announcement.content.trim().take(4000),
                        "groupName" to announcement.groupName.trim().ifBlank { "الكل" }.take(120),
                        "date" to announcement.date.trim().take(32),
                        "isUrgent" to announcement.isUrgent,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                if (res.isSuccess) addCatalogId(teacherUid, "announcementIds", docId)
                res
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.WRITE, "announcements")
                Result.failure(e)
            }
        }

    suspend fun deleteAnnouncement(announcement: Announcement): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                val teacherUid = requireUserId()
                val docId = CloudMappers.announcementDocId(announcement)
                classroomRef(teacherUid).collection("announcements").document(docId).delete().await()
                classroomRef(teacherUid).collection("catalog").document("meta").update(
                    mapOf("announcementIds" to FieldValue.arrayRemove(docId), "updatedAt" to FieldValue.serverTimestamp())
                ).await()
                Result.success(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.DELETE, "announcements")
                Result.failure(e)
            }
        }

    suspend fun upsertQuestion(teacherUid: String, question: StudentQuestion): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                val uid = requireUserId()
                val normCode = CloudMappers.normalizeCode(question.studentCode)
                val docId = CloudMappers.questionDocId(question)
                val sAuthUid = if (uid == teacherUid) resolveStudentAuthUid(teacherUid, normCode) else uid
                val docRef = classroomRef(teacherUid).collection("student_questions").document(docId)
                val members = if (question.isPublicToGroup) currentMemberUidsList() else emptyList()
                val createMap = mapOf(
                    "ownerUid" to teacherUid,
                    "memberUids" to members,
                    "studentAuthUid" to sAuthUid,
                    "studentName" to question.studentName.trim().ifBlank { "طالب" }.take(200),
                    "studentCode" to normCode,
                    "groupName" to question.groupName.take(120),
                    "subject" to question.subject.take(120),
                    "questionText" to question.questionText.trim().take(4000),
                    "answerText" to question.answerText.take(4000),
                    "answerAudioDuration" to question.answerAudioDuration,
                    "isAnswered" to question.isAnswered,
                    "isPinned" to question.isPinned,
                    "isPublicToGroup" to question.isPublicToGroup,
                    "createdDate" to question.createdDate.take(32),
                    "answeredDate" to question.answeredDate.take(32),
                    "localCreatedAt" to question.createdAt,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                val updateMap = if (uid == teacherUid) {
                    mapOf(
                        "memberUids" to members,
                        "studentAuthUid" to sAuthUid,
                        "answerText" to question.answerText.take(4000),
                        "answerAudioDuration" to question.answerAudioDuration,
                        "isAnswered" to question.isAnswered,
                        "isPinned" to question.isPinned,
                        "isPublicToGroup" to question.isPublicToGroup,
                        "answeredDate" to question.answeredDate.take(32),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                } else {
                    mapOf("studentAuthUid" to uid, "updatedAt" to FieldValue.serverTimestamp())
                }
                val res = safeStudentUpsert(
                    uid = uid,
                    teacherUid = teacherUid,
                    normCode = normCode,
                    manifestField = "questionIds",
                    docId = docId,
                    docRef = docRef,
                    createMap = createMap,
                    updateMap = updateMap
                )
                if (res.isSuccess) {
                    ensureManifestAndAddId(teacherUid, normCode, sAuthUid, "questionIds", docId)
                    if (question.isPublicToGroup) {
                        classroomRef(teacherUid).collection("catalog").document("meta").update(
                            mapOf("publicQuestionIds" to FieldValue.arrayUnion(docId), "updatedAt" to FieldValue.serverTimestamp())
                        ).await()
                    }
                }
                res
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.WRITE, "student_questions")
                Result.failure(e)
            }
        }

    suspend fun deleteQuestion(question: StudentQuestion): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                val teacherUid = requireUserId()
                val docId = CloudMappers.questionDocId(question)
                classroomRef(teacherUid).collection("student_questions").document(docId).delete().await()
                Result.success(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.DELETE, "student_questions")
                Result.failure(e)
            }
        }

    suspend fun upsertMistake(
        teacherUid: String,
        examCloudId: String,
        mistake: MistakeRecord
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val uid = requireUserId()
            val normCode = CloudMappers.normalizeCode(mistake.studentCode)
            val docId = CloudMappers.mistakeDocId(mistake)
            val sAuthUid = if (uid == teacherUid) resolveStudentAuthUid(teacherUid, normCode) else uid
            val docRef = classroomRef(teacherUid).collection("mistake_bank").document(docId)
            val optsList = CloudMappers.optionsJsonToList(mistake.optionsJson)
            val createMap = mapOf(
                "ownerUid" to teacherUid,
                "studentAuthUid" to sAuthUid,
                "studentCode" to normCode,
                "studentName" to mistake.studentName.take(200),
                "examCloudId" to examCloudId,
                "examTitle" to mistake.examTitle.take(200),
                "subject" to mistake.subject.take(120),
                "questionId" to mistake.questionId,
                "questionText" to mistake.questionText.trim().take(4000),
                "questionType" to mistake.questionType.take(64),
                "options" to optsList,
                "studentAnswer" to mistake.studentAnswer.take(2000),
                "correctAnswer" to mistake.correctAnswer.take(2000),
                "correctOptionIndex" to mistake.correctOptionIndex,
                "explanation" to mistake.explanation.take(4000),
                "difficulty" to mistake.difficulty.take(64),
                "personalNote" to mistake.personalNote.take(2000),
                "mistakeCount" to mistake.mistakeCount,
                "practiceAttempts" to mistake.practiceAttempts,
                "isMastered" to mistake.isMastered,
                "lastMistakeDate" to mistake.lastMistakeDate.take(32),
                "localCreatedAt" to mistake.createdAt,
                "localUpdatedAt" to mistake.updatedAt,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            val updateMap = if (uid == teacherUid) {
                mapOf(
                    "studentAuthUid" to sAuthUid,
                    "studentAnswer" to mistake.studentAnswer.take(2000),
                    "correctAnswer" to mistake.correctAnswer.take(2000),
                    "explanation" to mistake.explanation.take(4000),
                    "personalNote" to mistake.personalNote.take(2000),
                    "mistakeCount" to mistake.mistakeCount,
                    "practiceAttempts" to mistake.practiceAttempts,
                    "isMastered" to mistake.isMastered,
                    "lastMistakeDate" to mistake.lastMistakeDate.take(32),
                    "localUpdatedAt" to mistake.updatedAt,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            } else {
                mapOf(
                    "studentAuthUid" to uid,
                    "studentAnswer" to mistake.studentAnswer.take(2000),
                    "personalNote" to mistake.personalNote.take(2000),
                    "mistakeCount" to mistake.mistakeCount,
                    "practiceAttempts" to mistake.practiceAttempts,
                    "isMastered" to mistake.isMastered,
                    "lastMistakeDate" to mistake.lastMistakeDate.take(32),
                    "localUpdatedAt" to mistake.updatedAt,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            }
            val res = safeStudentUpsert(
                uid = uid,
                teacherUid = teacherUid,
                normCode = normCode,
                manifestField = "mistakeIds",
                docId = docId,
                docRef = docRef,
                createMap = createMap,
                updateMap = updateMap
            )
            if (res.isSuccess) {
                ensureManifestAndAddId(teacherUid, normCode, sAuthUid, "mistakeIds", docId)
            }
            res
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "mistake_bank")
            Result.failure(e)
        }
    }

    suspend fun deleteMistake(mistake: MistakeRecord): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                val teacherUid = requireUserId()
                val docId = CloudMappers.mistakeDocId(mistake)
                classroomRef(teacherUid).collection("mistake_bank").document(docId).delete().await()
                Result.success(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.DELETE, "mistake_bank")
                Result.failure(e)
            }
        }

    // --- Phone B Student Enrollment & Full Hydration ---
    suspend fun enrollAndFetchStudent(
        enteredCode: String,
        enteredPassword: String
    ): Result<CloudStudentHydrationBundle> = withContext(Dispatchers.IO) {
        try {
            val studentUid = requireUserId()
            val normCode = CloudMappers.normalizeCode(enteredCode)
            val passId = CloudMappers.studentPassId(normCode)
            val passRef = db.collection("student_passes").document(passId)
            val passSnap = passRef.get().await()
            if (!passSnap.exists()) {
                return@withContext Result.failure(IllegalArgumentException("الكود أو كلمة المرور غير صحيحة"))
            }
            val storedPass = passSnap.getString("password") ?: ""
            if (storedPass != enteredPassword.trim()) {
                return@withContext Result.failure(IllegalArgumentException("الكود أو كلمة المرور غير صحيحة"))
            }
            val teacherUid = passSnap.getString("teacherUid")
                ?: return@withContext Result.failure(IllegalStateException("بيانات المعلم غير مكتملة"))
            val studentDocId = passSnap.getString("studentDocId")
                ?: CloudMappers.studentDocId(normCode)

            // 1. Bind current Google UID to pass and classroom membership
            passRef.update(
                mapOf("studentAuthUid" to studentUid, "updatedAt" to FieldValue.serverTimestamp())
            ).await()

            val memberRef = classroomRef(teacherUid).collection("members").document(studentUid)
            safeUpsert(
                memberRef.path,
                memberRef,
                mapOf(
                    "memberUid" to studentUid,
                    "teacherUid" to teacherUid,
                    "studentCode" to normCode,
                    "passId" to passId,
                    "studentDocId" to studentDocId,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                mapOf(
                    "studentCode" to normCode,
                    "passId" to passId,
                    "studentDocId" to studentDocId,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).getOrThrow()

            // 2. Claim studentAuthUid on student profile doc
            val studentRef = classroomRef(teacherUid).collection("students").document(studentDocId)
            val studentSnap = studentRef.get().await()
            if (studentSnap.exists() && studentSnap.getString("studentAuthUid") != studentUid) {
                studentRef.update(
                    mapOf("studentAuthUid" to studentUid, "updatedAt" to FieldValue.serverTimestamp())
                ).await()
            }
            val student = CloudMappers.snapshotToStudent(studentSnap) ?: Student(
                code = normCode,
                password = storedPass,
                name = passSnap.getString("studentName") ?: "طالب",
                groupName = passSnap.getString("groupName") ?: "عام",
                scheduleTime = "",
                parentPhone = ""
            )

            // 3. Hydrate manifest & catalog doc IDs
            val manifestSnap = classroomRef(teacherUid).collection("student_manifests")
                .document(studentDocId).get().await()
            val catalogSnap = classroomRef(teacherUid).collection("catalog")
                .document("meta").get().await()

            suspend fun fetchIds(col: String, ids: List<String>, claimPersonalAuth: Boolean): List<DocumentSnapshot> =
                coroutineScope {
                    ids.distinct().map { docId ->
                        async {
                            val ref = classroomRef(teacherUid).collection(col).document(docId)
                            val snap = ref.get().await()
                            if (claimPersonalAuth && snap.exists() && snap.getString("studentAuthUid") != studentUid) {
                                try {
                                    ref.update(
                                        mapOf(
                                            "studentAuthUid" to studentUid,
                                            "updatedAt" to FieldValue.serverTimestamp()
                                        )
                                    ).await()
                                } catch (_: Exception) {}
                            }
                            snap
                        }
                    }.awaitAll()
                }

            fun DocumentSnapshot.idList(key: String): List<String> =
                (get(key) as? List<*>)?.mapNotNull { it as? String } ?: emptyList()

            val attSnaps = fetchIds("attendance", manifestSnap.idList("attendanceIds"), true)
            val hwSnaps = fetchIds("homework", manifestSnap.idList("homeworkIds"), true)
            val paySnaps = fetchIds("payments", manifestSnap.idList("paymentIds"), true)
            val noteSnaps = fetchIds("parent_notes", manifestSnap.idList("noteIds"), true)
            val subSnaps = fetchIds("exam_submissions", manifestSnap.idList("submissionIds"), true)
            val mskSnaps = fetchIds("mistake_bank", manifestSnap.idList("mistakeIds"), true)
            val ownQIds = manifestSnap.idList("questionIds")
            val pubQIds = catalogSnap.idList("publicQuestionIds")
            val qSnaps = fetchIds("student_questions", (ownQIds + pubQIds).distinct(), false)
            val examSnaps = fetchIds("exams", catalogSnap.idList("examIds"), false)
            val resSnaps = fetchIds("educational_resources", catalogSnap.idList("resourceIds"), false)
            val schedSnaps = fetchIds("class_schedules", catalogSnap.idList("scheduleIds"), false)
            val annSnaps = fetchIds("announcements", catalogSnap.idList("announcementIds"), false)

            Result.success(
                CloudStudentHydrationBundle(
                    teacherUid = teacherUid,
                    student = student,
                    attendances = attSnaps.mapNotNull { CloudMappers.snapshotToAttendance(it, 0L) },
                    homeworks = hwSnaps.mapNotNull { CloudMappers.snapshotToHomework(it, 0L) },
                    payments = paySnaps.mapNotNull { CloudMappers.snapshotToPayment(it, 0L) },
                    notes = noteSnaps.mapNotNull { CloudMappers.snapshotToParentNote(it, 0L) },
                    exams = examSnaps.mapNotNull { d -> CloudMappers.snapshotToExam(d)?.let { CloudExamItem(d.id, it) } },
                    submissions = subSnaps.mapNotNull { d ->
                        val eId = d.getString("examCloudId") ?: return@mapNotNull null
                        val code = d.getString("studentCode") ?: return@mapNotNull null
                        CloudSubmissionItem(
                            docId = d.id,
                            examCloudId = eId,
                            studentCode = CloudMappers.normalizeCode(code),
                            score = (d.getLong("score") ?: 0L).toInt(),
                            maxScore = (d.getLong("maxScore") ?: 1L).toInt(),
                            answersJson = CloudMappers.nativeMapToAnswersJson(d.get("answers")),
                            submittedAtMs = d.getLong("submittedAtMs") ?: System.currentTimeMillis()
                        )
                    },
                    resources = resSnaps.mapNotNull { CloudMappers.snapshotToResource(it) },
                    schedules = schedSnaps.mapNotNull { CloudMappers.snapshotToSchedule(it) },
                    announcements = annSnaps.mapNotNull { CloudMappers.snapshotToAnnouncement(it) },
                    questions = qSnaps.mapNotNull { d -> CloudMappers.snapshotToQuestion(d, 0L)?.let { CloudQuestionItem(d.id, it) } },
                    mistakes = mskSnaps.mapNotNull { d ->
                        val eCid = d.getString("examCloudId") ?: ""
                        CloudMappers.snapshotToMistake(d, 0L, 0L)?.let { CloudMistakeItem(d.id, eCid, it) }
                    }
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, "student_passes")
            Result.failure(e)
        }
    }

    // Backfills newly enrolled student's authUid onto all shared & personal classroom docs when Teacher is online
    suspend fun grantMemberAccessToExistingDocs(teacherUid: String, studentCode: String, memberUid: String) {
        withContext(Dispatchers.IO) {
            try {
                val cRef = classroomRef(teacherUid)
                val normCode = CloudMappers.normalizeCode(studentCode)
                val manifestSnap = cRef.collection("student_manifests")
                    .document(CloudMappers.studentDocId(normCode)).get().await()

                suspend fun stampAuth(col: String, ids: List<String>) {
                    ids.forEach { id ->
                        try {
                            cRef.collection(col).document(id).update(
                                mapOf("studentAuthUid" to memberUid, "updatedAt" to FieldValue.serverTimestamp())
                            ).await()
                        } catch (_: Exception) {}
                    }
                }
                fun DocumentSnapshot.idList(key: String): List<String> =
                    (get(key) as? List<*>)?.mapNotNull { it as? String } ?: emptyList()

                stampAuth("attendance", manifestSnap.idList("attendanceIds"))
                stampAuth("homework", manifestSnap.idList("homeworkIds"))
                stampAuth("payments", manifestSnap.idList("paymentIds"))
                stampAuth("parent_notes", manifestSnap.idList("noteIds"))
                stampAuth("exam_submissions", manifestSnap.idList("submissionIds"))
                stampAuth("mistake_bank", manifestSnap.idList("mistakeIds"))

                listOf("exams", "educational_resources", "class_schedules", "announcements").forEach { col ->
                    val docs = cRef.collection(col).get().await()
                    docs.documents.forEach { d ->
                        val existingMembers = (d.get("memberUids") as? List<*>)?.mapNotNull { it as? String } ?: emptyList()
                        if (memberUid !in existingMembers && existingMembers.size < 200) {
                            try {
                                d.reference.update(
                                    mapOf(
                                        "memberUids" to FieldValue.arrayUnion(memberUid),
                                        "updatedAt" to FieldValue.serverTimestamp()
                                    )
                                ).await()
                            } catch (_: Exception) {}
                        }
                    }
                }
            } catch (_: Exception) {}
        }
    }
}
