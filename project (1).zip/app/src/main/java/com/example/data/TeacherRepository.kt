package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File

class TeacherRepository(private val dao: AppDao) {

    // --- Students ---
    val allStudents: Flow<List<Student>> = dao.getAllStudents()
    val allGroups: Flow<List<String>> = dao.getDistinctGroups()

    fun getStudentById(id: Long): Flow<Student?> = dao.getStudentById(id)

    suspend fun verifyStudentLogin(code: String, pass: String): Student? = withContext(Dispatchers.IO) {
        val student = dao.getStudentByCode(code.trim())
        if (student != null && student.password == pass.trim()) {
            student
        } else {
            null
        }
    }

    suspend fun saveStudent(student: Student): Long = withContext(Dispatchers.IO) {
        if (student.id == 0L) {
            val existingByCode = dao.getStudentByCode(student.code.trim())
            if (existingByCode != null) {
                dao.updateStudent(student.copy(id = existingByCode.id))
                existingByCode.id
            } else {
                dao.insertStudent(student)
            }
        } else {
            dao.updateStudent(student)
            student.id
        }
    }

    suspend fun updateStudentCredentials(studentId: Long, newCode: String, newPass: String) = withContext(Dispatchers.IO) {
        val current = dao.getStudentByCode(newCode)
        // If not conflicting with another student
        val students = dao.getStudentByCode(newCode)
        // Update directly
    }

    suspend fun deleteStudent(student: Student) = withContext(Dispatchers.IO) {
        val mediaPaths = (
            dao.getNoteAudioPathsForStudent(student.id) +
                dao.getQuestionImagePathsForStudent(student.id) +
                dao.getQuestionAnswerAudioPathsForStudent(student.id)
            ).distinct()
        dao.deleteStudentCascade(student)
        mediaPaths.forEach { path ->
            if (path.isNotBlank()) {
                try {
                    val file = File(path)
                    if (file.exists()) file.delete()
                } catch (_: Exception) {}
            }
        }
    }

    suspend fun purgeOrphanedRecords() = withContext(Dispatchers.IO) {
        dao.deleteOrphanedStudentRecords()
    }

    // --- Attendance ---
    val allAttendances: Flow<List<AttendanceRecord>> = dao.getAllAttendances()
    fun getAttendanceForDate(date: String): Flow<List<AttendanceRecord>> = dao.getAttendanceForDate(date)
    fun getAttendanceForStudent(studentId: Long): Flow<List<AttendanceRecord>> = dao.getAttendanceForStudent(studentId)

    suspend fun saveAttendanceRecord(record: AttendanceRecord) = withContext(Dispatchers.IO) {
        dao.upsertAttendance(record)
    }

    suspend fun saveBatchAttendance(records: List<AttendanceRecord>) = withContext(Dispatchers.IO) {
        dao.upsertAttendances(records)
    }

    // --- Homework ---
    val allHomework: Flow<List<HomeworkRecord>> = dao.getAllHomework()
    fun getHomeworkForDate(date: String): Flow<List<HomeworkRecord>> = dao.getHomeworkForDate(date)
    fun getHomeworkForStudent(studentId: Long): Flow<List<HomeworkRecord>> = dao.getHomeworkForStudent(studentId)

    suspend fun saveHomeworkRecord(record: HomeworkRecord) = withContext(Dispatchers.IO) {
        dao.upsertHomework(record)
    }

    suspend fun saveBatchHomework(records: List<HomeworkRecord>) = withContext(Dispatchers.IO) {
        dao.upsertHomeworks(records)
    }

    // --- Payments ---
    fun getPaymentsForStudent(studentId: Long): Flow<List<PaymentRecord>> = dao.getPaymentsForStudent(studentId)
    val allPayments: Flow<List<PaymentRecord>> = dao.getAllPayments()

    suspend fun savePayment(record: PaymentRecord) = withContext(Dispatchers.IO) {
        dao.replacePayment(record)
    }

    // --- Exams ---
    val allExams: Flow<List<Exam>> = dao.getAllExams()
    suspend fun getExamById(id: Long): Exam? = withContext(Dispatchers.IO) { dao.getExamById(id) }

    suspend fun saveExam(exam: Exam): Long = withContext(Dispatchers.IO) {
        if (exam.id == 0L) {
            dao.insertExam(exam)
        } else {
            dao.updateExam(exam)
            exam.id
        }
    }

    suspend fun deleteExam(exam: Exam) = withContext(Dispatchers.IO) {
        dao.deleteExam(exam)
    }

    val allSubmissions: Flow<List<ExamSubmission>> = dao.getAllSubmissions()
    fun getSubmissionsForExam(examId: Long): Flow<List<ExamSubmission>> = dao.getSubmissionsForExam(examId)
    fun getSubmissionsForStudent(studentId: Long): Flow<List<ExamSubmission>> = dao.getSubmissionsForStudent(studentId)

    suspend fun submitExam(submission: ExamSubmission) = withContext(Dispatchers.IO) {
        dao.upsertSubmission(submission)
    }

    // --- Parent Notes ---
    fun getNotesForStudent(studentId: Long): Flow<List<ParentNote>> = dao.getNotesForStudent(studentId)
    val allNotes: Flow<List<ParentNote>> = dao.getAllNotes()

    suspend fun addParentNote(note: ParentNote) = withContext(Dispatchers.IO) {
        dao.insertNote(note)
    }

    suspend fun deleteParentNote(note: ParentNote) = withContext(Dispatchers.IO) {
        dao.deleteNote(note)
    }

    // --- Resources ---
    val allResources: Flow<List<EducationalResource>> = dao.getAllResources()

    suspend fun addResource(resource: EducationalResource): Long = withContext(Dispatchers.IO) {
        dao.insertResource(resource)
    }

    suspend fun deleteResource(resource: EducationalResource) = withContext(Dispatchers.IO) {
        dao.deleteResource(resource)
    }

    // --- Announcements ---
    val allAnnouncements: Flow<List<Announcement>> = dao.getAllAnnouncements()

    suspend fun addAnnouncement(announcement: Announcement) = withContext(Dispatchers.IO) {
        dao.insertAnnouncement(announcement)
    }

    suspend fun deleteAnnouncement(announcement: Announcement) = withContext(Dispatchers.IO) {
        dao.deleteAnnouncement(announcement)
    }

    // --- Question Bank ---
    val allBankQuestions: Flow<List<QuestionBankItem>> = dao.getAllBankQuestions()

    suspend fun addBankQuestion(item: QuestionBankItem): Long = withContext(Dispatchers.IO) {
        dao.insertBankQuestion(item)
    }

    suspend fun addBankQuestions(items: List<QuestionBankItem>) = withContext(Dispatchers.IO) {
        dao.insertBankQuestions(items)
    }

    suspend fun deleteBankQuestion(item: QuestionBankItem) = withContext(Dispatchers.IO) {
        dao.deleteBankQuestion(item)
    }

    // --- Weekly Class Schedules ---
    val allSchedules: Flow<List<ClassSchedule>> = dao.getAllSchedules()

    suspend fun saveSchedule(schedule: ClassSchedule): Long = withContext(Dispatchers.IO) {
        if (schedule.id == 0L) {
            dao.insertSchedule(schedule)
        } else {
            dao.updateSchedule(schedule)
            schedule.id
        }
    }

    suspend fun deleteSchedule(schedule: ClassSchedule) = withContext(Dispatchers.IO) {
        dao.deleteSchedule(schedule)
    }

    // --- Ask the Teacher (Q&A Corner) ---
    val allQuestions: Flow<List<StudentQuestion>> = dao.getAllQuestions()

    suspend fun insertQuestion(question: StudentQuestion): Long = withContext(Dispatchers.IO) {
        dao.insertQuestion(question)
    }

    suspend fun updateQuestion(question: StudentQuestion) = withContext(Dispatchers.IO) {
        dao.updateQuestion(question)
    }

    suspend fun deleteQuestion(question: StudentQuestion) = withContext(Dispatchers.IO) {
        dao.deleteQuestion(question)
    }

    // --- Mistake Bank (بنك الأخطاء) ---
    val allMistakes: Flow<List<MistakeRecord>> = dao.getAllMistakes()
    fun getMistakesForStudent(studentId: Long): Flow<List<MistakeRecord>> =
        dao.getMistakesForStudent(studentId)

    suspend fun recordOrIncrementMistake(record: MistakeRecord): MistakeRecord = withContext(Dispatchers.IO) {
        val existing = dao.findExistingMistake(record.studentId, record.examId, record.questionText)
        if (existing != null) {
            val updated = existing.copy(
                studentAnswer = record.studentAnswer,
                correctAnswer = record.correctAnswer,
                explanation = record.explanation.ifBlank { existing.explanation },
                mistakeCount = existing.mistakeCount + 1,
                isMastered = false,
                lastMistakeDate = record.lastMistakeDate,
                updatedAt = System.currentTimeMillis()
            )
            dao.updateMistake(updated)
            updated
        } else {
            val newId = dao.insertMistake(record)
            record.copy(id = newId)
        }
    }

    suspend fun updateMistake(record: MistakeRecord) = withContext(Dispatchers.IO) {
        dao.updateMistake(record.copy(updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteMistake(record: MistakeRecord) = withContext(Dispatchers.IO) {
        dao.deleteMistake(record)
    }

    suspend fun seedIfEmpty() = withContext(Dispatchers.IO) {
        // Handled in Room Database callback
    }
}
