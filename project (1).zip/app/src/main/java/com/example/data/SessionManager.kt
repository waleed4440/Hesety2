package com.example.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class SavedAccount(
    val id: String,
    val role: String,
    val code: String,
    val displayName: String,
    val subtitle: String,
    val studentId: Long = -1L
)

class SessionManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("app_auth_session", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_ROLE = "user_role"
        private const val KEY_STUDENT_ID = "student_id"
        private const val KEY_STUDENT_CODE = "student_code"
        private const val KEY_ACTIVE_ACCOUNT_ID = "active_account_id"
        private const val KEY_SAVED_ACCOUNTS = "saved_accounts_json"

        const val ROLE_NONE = "NONE"
        const val ROLE_TEACHER = "TEACHER"
        const val ROLE_STUDENT = "STUDENT"

        const val TEACHER_ACCOUNT_ID = "TEACHER_ADMIN123"
    }

    fun saveTeacherSession(displayName: String = "الأستاذ (المعلم)", subtitle: String = "لوحة تحكم المعلم") {
        val account = SavedAccount(
            id = TEACHER_ACCOUNT_ID,
            role = ROLE_TEACHER,
            code = "admin123",
            displayName = displayName,
            subtitle = subtitle
        )
        upsertSavedAccount(account)
        prefs.edit()
            .putString(KEY_ROLE, ROLE_TEACHER)
            .putString(KEY_ACTIVE_ACCOUNT_ID, account.id)
            .remove(KEY_STUDENT_ID)
            .remove(KEY_STUDENT_CODE)
            .apply()
    }

    fun saveStudentSession(
        studentId: Long,
        studentCode: String,
        studentName: String = "",
        groupName: String = ""
    ) {
        val normalizedCode = studentCode.trim().uppercase()
        val accountId = "STUDENT_$normalizedCode"
        val account = SavedAccount(
            id = accountId,
            role = ROLE_STUDENT,
            code = normalizedCode,
            displayName = studentName.ifBlank { "طالب ($normalizedCode)" },
            subtitle = groupName.ifBlank { "حساب طالب" },
            studentId = studentId
        )
        upsertSavedAccount(account)
        prefs.edit()
            .putString(KEY_ROLE, ROLE_STUDENT)
            .putString(KEY_ACTIVE_ACCOUNT_ID, accountId)
            .putLong(KEY_STUDENT_ID, studentId)
            .putString(KEY_STUDENT_CODE, normalizedCode)
            .apply()
    }

    fun getSavedAccounts(): List<SavedAccount> {
        val raw = prefs.getString(KEY_SAVED_ACCOUNTS, "[]") ?: "[]"
        val list = mutableListOf<SavedAccount>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    SavedAccount(
                        id = obj.getString("id"),
                        role = obj.getString("role"),
                        code = obj.getString("code"),
                        displayName = obj.getString("displayName"),
                        subtitle = obj.optString("subtitle", ""),
                        studentId = obj.optLong("studentId", -1L)
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    private fun upsertSavedAccount(account: SavedAccount) {
        val current = getSavedAccounts().filterNot { it.id == account.id }.toMutableList()
        current.add(0, account)
        persistAccounts(current)
    }

    fun removeSavedAccount(accountId: String) {
        val updated = getSavedAccounts().filterNot { it.id == accountId }
        persistAccounts(updated)
    }

    private fun persistAccounts(accounts: List<SavedAccount>) {
        val arr = JSONArray()
        accounts.forEach { acc ->
            val obj = JSONObject()
            obj.put("id", acc.id)
            obj.put("role", acc.role)
            obj.put("code", acc.code)
            obj.put("displayName", acc.displayName)
            obj.put("subtitle", acc.subtitle)
            obj.put("studentId", acc.studentId)
            arr.put(obj)
        }
        prefs.edit().putString(KEY_SAVED_ACCOUNTS, arr.toString()).apply()
    }

    fun getCurrentAccountId(): String? {
        return prefs.getString(KEY_ACTIVE_ACCOUNT_ID, null)
    }

    fun clearSession() {
        prefs.edit()
            .remove(KEY_ROLE)
            .remove(KEY_ACTIVE_ACCOUNT_ID)
            .remove(KEY_STUDENT_ID)
            .remove(KEY_STUDENT_CODE)
            .apply()
    }

    fun clearAllData() {
        prefs.edit().clear().apply()
    }

    fun getSavedRole(): String {
        return prefs.getString(KEY_ROLE, ROLE_NONE) ?: ROLE_NONE
    }

    fun getSavedStudentId(): Long {
        return prefs.getLong(KEY_STUDENT_ID, -1L)
    }

    fun getSavedStudentCode(): String {
        return prefs.getString(KEY_STUDENT_CODE, "") ?: ""
    }
}
