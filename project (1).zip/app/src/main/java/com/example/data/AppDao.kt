package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    // --- Students ---
    @Query("SELECT * FROM students ORDER BY name ASC")
    fun getAllStudents(): Flow<List<Student>>

    @Query("SELECT * FROM students ORDER BY name ASC")
    suspend fun getAllStudentsSync(): List<Student>

    @Query("SELECT * FROM students WHERE id = :id LIMIT 1")
    suspend fun getStudentByIdSync(id: Long): Student?

    @Query("SELECT * FROM students WHERE id = :id LIMIT 1")
    fun getStudentById(id: Long): Flow<Student?>

    @Query("SELECT * FROM students WHERE code = :code LIMIT 1")
    suspend fun getStudentByCode(code: String): Student?

    @Query("SELECT DISTINCT groupName FROM students ORDER BY groupName ASC")
    fun getDistinctGroups(): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudent(student: Student): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudents(students: List<Student>)

    @Update
    suspend fun updateStudent(student: Student)

    @Delete
    suspend fun deleteStudent(student: Student)

    @Query("SELECT COUNT(*) FROM students WHERE id = :studentId")
    suspend fun countStudentById(studentId: Long): Int

    @Query("SELECT audioFilePath FROM parent_notes WHERE studentId = :studentId AND audioFilePath != ''")
    suspend fun getNoteAudioPathsForStudent(studentId: Long): List<String>

    @Query("SELECT questionImagePath FROM student_questions WHERE studentId = :studentId AND questionImagePath != ''")
    suspend fun getQuestionImagePathsForStudent(studentId: Long): List<String>

    @Query("SELECT answerAudioPath FROM student_questions WHERE studentId = :studentId AND answerAudioPath != ''")
    suspend fun getQuestionAnswerAudioPathsForStudent(studentId: Long): List<String>

    @Query("DELETE FROM attendance_records WHERE studentId = :studentId")
    suspend fun deleteAttendanceForStudent(studentId: Long)

    @Query("DELETE FROM homework_records WHERE studentId = :studentId")
    suspend fun deleteHomeworkForStudent(studentId: Long)

    @Query("DELETE FROM payment_records WHERE studentId = :studentId")
    suspend fun deletePaymentsForStudent(studentId: Long)

    @Query("DELETE FROM exam_submissions WHERE studentId = :studentId")
    suspend fun deleteSubmissionsForStudent(studentId: Long)

    @Query("DELETE FROM parent_notes WHERE studentId = :studentId")
    suspend fun deleteNotesForStudent(studentId: Long)

    @Query("DELETE FROM student_questions WHERE studentId = :studentId")
    suspend fun deleteQuestionsForStudent(studentId: Long)

    @Query("DELETE FROM mistake_bank WHERE studentId = :studentId")
    suspend fun deleteMistakesForStudent(studentId: Long)

    @Transaction
    suspend fun deleteStudentCascade(student: Student) {
        deleteAttendanceForStudent(student.id)
        deleteHomeworkForStudent(student.id)
        deletePaymentsForStudent(student.id)
        deleteSubmissionsForStudent(student.id)
        deleteNotesForStudent(student.id)
        deleteQuestionsForStudent(student.id)
        deleteMistakesForStudent(student.id)
        deleteStudent(student)
    }

    @Query("DELETE FROM attendance_records WHERE studentId NOT IN (SELECT id FROM students)")
    suspend fun deleteOrphanedAttendance()

    @Query("DELETE FROM homework_records WHERE studentId NOT IN (SELECT id FROM students)")
    suspend fun deleteOrphanedHomework()

    @Query("DELETE FROM payment_records WHERE studentId NOT IN (SELECT id FROM students)")
    suspend fun deleteOrphanedPayments()

    @Query("DELETE FROM exam_submissions WHERE studentId NOT IN (SELECT id FROM students)")
    suspend fun deleteOrphanedSubmissions()

    @Query("DELETE FROM parent_notes WHERE studentId NOT IN (SELECT id FROM students)")
    suspend fun deleteOrphanedNotes()

    @Query("DELETE FROM student_questions WHERE studentId NOT IN (SELECT id FROM students)")
    suspend fun deleteOrphanedQuestions()

    @Query("DELETE FROM mistake_bank WHERE studentId NOT IN (SELECT id FROM students)")
    suspend fun deleteOrphanedMistakes()

    @Transaction
    suspend fun deleteOrphanedStudentRecords() {
        deleteOrphanedAttendance()
        deleteOrphanedHomework()
        deleteOrphanedPayments()
        deleteOrphanedSubmissions()
        deleteOrphanedNotes()
        deleteOrphanedQuestions()
        deleteOrphanedMistakes()
    }

    // --- Attendance ---
    @Query("SELECT * FROM attendance_records WHERE date = :date")
    fun getAttendanceForDate(date: String): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance_records ORDER BY date DESC")
    fun getAllAttendances(): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance_records WHERE studentId = :studentId ORDER BY date DESC")
    fun getAttendanceForStudent(studentId: Long): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance_records WHERE studentId = :studentId AND date = :date LIMIT 1")
    suspend fun getStudentAttendanceForDate(studentId: Long, date: String): AttendanceRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAttendance(record: AttendanceRecord)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAttendances(records: List<AttendanceRecord>)

    // --- Homework ---
    @Query("SELECT * FROM homework_records WHERE date = :date")
    fun getHomeworkForDate(date: String): Flow<List<HomeworkRecord>>

    @Query("SELECT * FROM homework_records ORDER BY date DESC")
    fun getAllHomework(): Flow<List<HomeworkRecord>>

    @Query("SELECT * FROM homework_records WHERE studentId = :studentId ORDER BY date DESC")
    fun getHomeworkForStudent(studentId: Long): Flow<List<HomeworkRecord>>

    @Query("SELECT * FROM homework_records WHERE studentId = :studentId AND date = :date LIMIT 1")
    suspend fun getStudentHomeworkForDate(studentId: Long, date: String): HomeworkRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertHomework(record: HomeworkRecord)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertHomeworks(records: List<HomeworkRecord>)

    // --- Payments ---
    @Query("SELECT * FROM payment_records WHERE studentId = :studentId ORDER BY id DESC")
    fun getPaymentsForStudent(studentId: Long): Flow<List<PaymentRecord>>

    @Query("SELECT * FROM payment_records ORDER BY id DESC")
    fun getAllPayments(): Flow<List<PaymentRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPayment(record: PaymentRecord)

    @Query("DELETE FROM payment_records WHERE studentId = :studentId AND monthYear = :monthYear")
    suspend fun deletePaymentsForStudentMonth(studentId: Long, monthYear: String)

    @Transaction
    suspend fun replacePayment(record: PaymentRecord) {
        deletePaymentsForStudentMonth(record.studentId, record.monthYear)
        upsertPayment(record)
    }

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPayments(records: List<PaymentRecord>)

    // --- Exams & Submissions ---
    @Query("SELECT * FROM exams ORDER BY id DESC")
    fun getAllExams(): Flow<List<Exam>>

    @Query("SELECT * FROM exams WHERE id = :id LIMIT 1")
    suspend fun getExamById(id: Long): Exam?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExam(exam: Exam): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExams(exams: List<Exam>)

    @Update
    suspend fun updateExam(exam: Exam)

    @Delete
    suspend fun deleteExam(exam: Exam)

    @Query("SELECT * FROM exam_submissions WHERE examId = :examId")
    fun getSubmissionsForExam(examId: Long): Flow<List<ExamSubmission>>

    @Query("SELECT * FROM exam_submissions ORDER BY id DESC")
    fun getAllSubmissions(): Flow<List<ExamSubmission>>

    @Query("SELECT * FROM exam_submissions WHERE studentId = :studentId ORDER BY id DESC")
    fun getSubmissionsForStudent(studentId: Long): Flow<List<ExamSubmission>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSubmission(submission: ExamSubmission)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSubmissions(submissions: List<ExamSubmission>)

    // --- Parent Notes ---
    @Query("SELECT * FROM parent_notes WHERE studentId = :studentId ORDER BY id DESC")
    fun getNotesForStudent(studentId: Long): Flow<List<ParentNote>>

    @Query("SELECT * FROM parent_notes ORDER BY id DESC")
    fun getAllNotes(): Flow<List<ParentNote>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: ParentNote)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotes(notes: List<ParentNote>)

    @Delete
    suspend fun deleteNote(note: ParentNote)

    // --- Educational Resources ---
    @Query("SELECT * FROM educational_resources ORDER BY id DESC")
    fun getAllResources(): Flow<List<EducationalResource>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertResource(resource: EducationalResource): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertResources(resources: List<EducationalResource>)

    @Delete
    suspend fun deleteResource(resource: EducationalResource)

    // --- Announcements ---
    @Query("SELECT * FROM announcements ORDER BY id DESC")
    fun getAllAnnouncements(): Flow<List<Announcement>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnnouncement(announcement: Announcement)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnnouncements(announcements: List<Announcement>)

    @Delete
    suspend fun deleteAnnouncement(announcement: Announcement)

    // --- Question Bank ---
    @Query("SELECT * FROM question_bank ORDER BY id DESC")
    fun getAllBankQuestions(): Flow<List<QuestionBankItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBankQuestion(item: QuestionBankItem): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBankQuestions(items: List<QuestionBankItem>)

    @Delete
    suspend fun deleteBankQuestion(item: QuestionBankItem)

    // --- Weekly Class Schedules ---
    @Query("SELECT * FROM class_schedules ORDER BY dayOfWeek ASC, startTime ASC")
    fun getAllSchedules(): Flow<List<ClassSchedule>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchedule(schedule: ClassSchedule): Long

    @Update
    suspend fun updateSchedule(schedule: ClassSchedule)

    @Delete
    suspend fun deleteSchedule(schedule: ClassSchedule)

    // --- Ask the Teacher (Q&A Corner) ---
    @Query("SELECT * FROM student_questions ORDER BY isPinned DESC, isAnswered ASC, id DESC")
    fun getAllQuestions(): Flow<List<StudentQuestion>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuestion(question: StudentQuestion): Long

    @Update
    suspend fun updateQuestion(question: StudentQuestion)

    @Delete
    suspend fun deleteQuestion(question: StudentQuestion)

    // --- Offline Pending Sync Outbox ---
    @Query("SELECT * FROM pending_sync_ops ORDER BY updatedAt ASC")
    fun getPendingSyncOpsFlow(): Flow<List<PendingSyncOp>>

    @Query("SELECT COUNT(*) FROM pending_sync_ops")
    fun getPendingSyncCountFlow(): Flow<Int>

    @Query("SELECT * FROM pending_sync_ops ORDER BY updatedAt ASC")
    suspend fun getPendingSyncOps(): List<PendingSyncOp>

    @Query("SELECT syncKey FROM pending_sync_ops")
    suspend fun getPendingSyncKeys(): List<String>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPendingSyncOp(op: PendingSyncOp)

    @Query("DELETE FROM pending_sync_ops WHERE syncKey = :syncKey")
    suspend fun deletePendingSyncOpByKey(syncKey: String)

    @Query("DELETE FROM pending_sync_ops WHERE syncKey LIKE :prefix || '%'")
    suspend fun deletePendingSyncOpsByPrefix(prefix: String)

    @Query("UPDATE pending_sync_ops SET retryCount = retryCount + 1, updatedAt = :updatedAt WHERE syncKey = :syncKey")
    suspend fun incrementPendingSyncRetry(syncKey: String, updatedAt: Long = System.currentTimeMillis())

    @Query("DELETE FROM pending_sync_ops")
    suspend fun clearAllPendingSyncOps()

    // --- Mistake Bank (بنك الأخطاء) ---
    @Query("SELECT * FROM mistake_bank ORDER BY isMastered ASC, mistakeCount DESC, updatedAt DESC")
    fun getAllMistakes(): Flow<List<MistakeRecord>>

    @Query("SELECT * FROM mistake_bank WHERE studentId = :studentId ORDER BY isMastered ASC, mistakeCount DESC, updatedAt DESC")
    fun getMistakesForStudent(studentId: Long): Flow<List<MistakeRecord>>

    @Query("SELECT * FROM mistake_bank WHERE studentId = :studentId AND examId = :examId AND questionText = :questionText LIMIT 1")
    suspend fun findExistingMistake(studentId: Long, examId: Long, questionText: String): MistakeRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMistake(record: MistakeRecord): Long

    @Update
    suspend fun updateMistake(record: MistakeRecord)

    @Delete
    suspend fun deleteMistake(record: MistakeRecord)
}
