package com.example.data.remote

import com.example.data.Announcement
import com.example.data.AttendanceRecord
import com.example.data.ClassSchedule
import com.example.data.EducationalResource
import com.example.data.Exam
import com.example.data.ExamQuestion
import com.example.data.ExamSubmission
import com.example.data.HomeworkRecord
import com.example.data.MistakeRecord
import com.example.data.ParentNote
import com.example.data.PaymentRecord
import com.example.data.QuestionBankItem
import com.example.data.Student
import com.example.data.StudentQuestion
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.Locale
import kotlin.math.abs

object CloudMappers {

    fun normalizeCode(code: String): String = code.trim().uppercase(Locale.ENGLISH)

    fun sha256Short(input: String, length: Int = 24): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }.take(length)
    }

    private fun codeSegment(code: String): String {
        val norm = normalizeCode(code)
        return if (norm.matches(Regex("^[A-Za-z0-9_\\-]{1,48}$"))) {
            norm
        } else {
            sha256Short(norm, 24)
        }
    }

    fun studentPassId(code: String): String = "PASS_${codeSegment(code)}"

    fun studentDocId(code: String): String = "STU_${codeSegment(code)}"

    fun attendanceDocId(studentCode: String, date: String): String {
        val safeDate = date.trim().replace(Regex("[^A-Za-z0-9_\\-]"), "_")
        return "ATT_${codeSegment(studentCode)}_$safeDate"
    }

    fun homeworkDocId(studentCode: String, date: String): String {
        val safeDate = date.trim().replace(Regex("[^A-Za-z0-9_\\-]"), "_")
        return "HW_${codeSegment(studentCode)}_$safeDate"
    }

    fun paymentDocId(studentCode: String, monthYear: String): String =
        "PAY_${codeSegment(studentCode)}_${sha256Short(monthYear.trim(), 20)}"

    fun noteDocId(studentCode: String, note: ParentNote): String =
        "NOTE_${codeSegment(studentCode)}_${sha256Short("${note.date.trim()}|${note.title.trim()}|${note.content.trim()}", 20)}"

    fun examDocId(exam: Exam, mappedCloudId: String? = null): String {
        if (!mappedCloudId.isNullOrBlank()) return mappedCloudId
        val suffix = abs(exam.title.trim().hashCode()).toString(16)
        return "EXAM_${exam.createdAt}_$suffix"
    }

    fun submissionDocId(examCloudId: String, studentCode: String): String =
        "SUB_${examCloudId}_${codeSegment(studentCode)}"

    fun resourceDocId(res: EducationalResource): String =
        "RES_${sha256Short("${res.title.trim()}|${res.addedDate.trim()}|${res.fileType.trim()}", 24)}"

    fun scheduleDocId(sched: ClassSchedule): String =
        "SCHED_${sched.dayOfWeek}_${sha256Short("${sched.groupName.trim()}|${sched.startTime.trim()}|${sched.subject.trim()}", 20)}"

    fun announcementDocId(ann: Announcement): String =
        "ANN_${sha256Short("${ann.title.trim()}|${ann.date.trim()}|${ann.groupName.trim()}", 24)}"

    fun questionDocId(q: StudentQuestion): String =
        "QA_${codeSegment(q.studentCode)}_${q.createdAt}_${sha256Short(q.questionText.trim(), 8)}"

    fun mistakeDocId(m: MistakeRecord): String =
        "MSK_${codeSegment(m.studentCode)}_${sha256Short("${m.examTitle.trim()}|${m.questionText.trim()}", 20)}"

    // --- Native Firestore Conversions (Zero JSON strings stored in Firestore) ---

    fun questionsToNativeList(questions: List<ExamQuestion>): List<Map<String, Any>> {
        return questions.take(100).map { q ->
            mapOf(
                "id" to q.id,
                "questionText" to q.questionText.take(2000),
                "options" to q.options.take(10).map { it.take(500) },
                "correctOptionIndex" to q.correctOptionIndex,
                "points" to q.points,
                "explanation" to q.explanation.take(1500),
                "imageUri" to q.imageUri.take(500),
                "questionType" to q.questionType.take(40),
                "correctTextAnswer" to q.correctTextAnswer.take(500),
                "difficulty" to q.difficulty.take(40),
                "topic" to q.topic.take(120)
            )
        }
    }

    @Suppress("UNCHECKED_CAST")
    fun nativeListToQuestionsJson(raw: Any?): String {
        val list = raw as? List<*> ?: return "[]"
        val parsed = list.mapIndexedNotNull { idx, item ->
            val map = item as? Map<String, Any?> ?: return@mapIndexedNotNull null
            val optionsRaw = map["options"] as? List<*> ?: emptyList<Any?>()
            ExamQuestion(
                id = (map["id"] as? Number)?.toInt() ?: (idx + 1),
                questionText = map["questionText"] as? String ?: "",
                options = optionsRaw.mapNotNull { it as? String },
                correctOptionIndex = (map["correctOptionIndex"] as? Number)?.toInt() ?: 0,
                points = (map["points"] as? Number)?.toInt() ?: 5,
                explanation = map["explanation"] as? String ?: "",
                imageUri = map["imageUri"] as? String ?: "",
                questionType = map["questionType"] as? String ?: ExamQuestion.TYPE_MCQ,
                correctTextAnswer = map["correctTextAnswer"] as? String ?: "",
                difficulty = map["difficulty"] as? String ?: ExamQuestion.DIFFICULTY_MEDIUM,
                topic = map["topic"] as? String ?: ""
            )
        }
        return Exam.encodeQuestions(parsed)
    }

    fun answersJsonToNativeMap(answersJson: String): Map<String, Any> {
        val result = mutableMapOf<String, Any>()
        try {
            val obj = JSONObject(answersJson.ifBlank { "{}" })
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val v = obj.opt(k)
                if (v != null && v != JSONObject.NULL) {
                    result[k] = v
                }
            }
        } catch (_: Exception) {}
        return result
    }

    fun nativeMapToAnswersJson(raw: Any?): String {
        val map = raw as? Map<*, *> ?: return "{}"
        val obj = JSONObject()
        map.forEach { (k, v) ->
            if (k is String && v != null) {
                obj.put(k, v)
            }
        }
        return obj.toString()
    }

    fun optionsJsonToList(optionsJson: String): List<String> {
        val list = mutableListOf<String>()
        try {
            val arr = JSONArray(optionsJson.ifBlank { "[]" })
            for (i in 0 until arr.length()) {
                list.add(arr.optString(i, ""))
            }
        } catch (_: Exception) {}
        return list.take(12)
    }

    // --- Entity Serializers ---

    fun studentPassCreateMap(
        teacherUid: String,
        student: Student,
        studentAuthUid: String
    ): Map<String, Any> {
        val normCode = normalizeCode(student.code)
        val passId = studentPassId(normCode)
        val sDocId = studentDocId(normCode)
        return mapOf(
            "passId" to passId,
            "studentCode" to normCode,
            "password" to student.password.take(128),
            "teacherUid" to teacherUid,
            "studentDocId" to sDocId,
            "studentName" to student.name.take(200),
            "groupName" to student.groupName.ifBlank { "عام" }.take(120),
            "studentAuthUid" to studentAuthUid,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
    }

    fun studentPassUpdateMap(student: Student, studentAuthUid: String): Map<String, Any> = mapOf(
        "password" to student.password.take(128),
        "studentName" to student.name.take(200),
        "groupName" to student.groupName.ifBlank { "عام" }.take(120),
        "studentAuthUid" to studentAuthUid,
        "updatedAt" to FieldValue.serverTimestamp()
    )

    fun studentCreateMap(
        teacherUid: String,
        student: Student,
        studentAuthUid: String
    ): Map<String, Any> = mapOf(
        "ownerUid" to teacherUid,
        "studentAuthUid" to studentAuthUid,
        "code" to normalizeCode(student.code),
        "password" to student.password.take(128),
        "name" to student.name.take(200),
        "groupName" to student.groupName.ifBlank { "عام" }.take(120),
        "scheduleTime" to student.scheduleTime.take(200),
        "parentPhone" to student.parentPhone.take(40),
        "monthlyFee" to student.monthlyFee,
        "localCreatedAt" to student.createdAt,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )

    fun studentUpdateMap(student: Student, studentAuthUid: String): Map<String, Any> = mapOf(
        "studentAuthUid" to studentAuthUid,
        "password" to student.password.take(128),
        "name" to student.name.take(200),
        "groupName" to student.groupName.ifBlank { "عام" }.take(120),
        "scheduleTime" to student.scheduleTime.take(200),
        "parentPhone" to student.parentPhone.take(40),
        "monthlyFee" to student.monthlyFee,
        "localCreatedAt" to student.createdAt,
        "updatedAt" to FieldValue.serverTimestamp()
    )

    fun snapshotToStudent(doc: DocumentSnapshot, localId: Long = 0L): Student? {
        if (!doc.exists()) return null
        val code = doc.getString("code") ?: return null
        val name = doc.getString("name") ?: return null
        return Student(
            id = localId,
            code = normalizeCode(code),
            password = doc.getString("password") ?: "",
            name = name,
            groupName = doc.getString("groupName") ?: "عام",
            scheduleTime = doc.getString("scheduleTime") ?: "",
            parentPhone = doc.getString("parentPhone") ?: "",
            monthlyFee = doc.getDouble("monthlyFee") ?: 250.0,
            createdAt = doc.getLong("localCreatedAt") ?: System.currentTimeMillis()
        )
    }

    fun snapshotToExam(doc: DocumentSnapshot, localId: Long = 0L): Exam? {
        if (!doc.exists()) return null
        val title = doc.getString("title") ?: return null
        return Exam(
            id = localId,
            title = title,
            groupName = doc.getString("groupName") ?: "الكل",
            durationMinutes = (doc.getLong("durationMinutes") ?: 30L).toInt(),
            totalMarks = (doc.getLong("totalMarks") ?: 20L).toInt(),
            questionsJson = nativeListToQuestionsJson(doc.get("questions")),
            isActive = doc.getBoolean("isActive") ?: true,
            shuffleQuestions = doc.getBoolean("shuffleQuestions") ?: false,
            showResultImmediately = doc.getBoolean("showResultImmediately") ?: true,
            description = doc.getString("description") ?: "",
            deadlineDate = doc.getString("deadlineDate") ?: "",
            allowRetake = doc.getBoolean("allowRetake") ?: false,
            createdAt = doc.getLong("localCreatedAt") ?: System.currentTimeMillis(),
            subject = doc.getString("subject") ?: "عام",
            passingPercentage = (doc.getLong("passingPercentage") ?: 50L).toInt(),
            shuffleOptions = doc.getBoolean("shuffleOptions") ?: false
        )
    }

    fun snapshotToAttendance(doc: DocumentSnapshot, localStudentId: Long): AttendanceRecord? {
        if (!doc.exists()) return null
        val date = doc.getString("date") ?: return null
        val status = doc.getString("status") ?: return null
        return AttendanceRecord(
            studentId = localStudentId,
            date = date,
            status = status,
            notes = doc.getString("notes") ?: ""
        )
    }

    fun snapshotToHomework(doc: DocumentSnapshot, localStudentId: Long): HomeworkRecord? {
        if (!doc.exists()) return null
        val date = doc.getString("date") ?: return null
        val status = doc.getString("status") ?: return null
        return HomeworkRecord(
            studentId = localStudentId,
            date = date,
            status = status,
            score = doc.getString("score") ?: "10/10",
            notes = doc.getString("notes") ?: ""
        )
    }

    fun snapshotToPayment(doc: DocumentSnapshot, localStudentId: Long): PaymentRecord? {
        if (!doc.exists()) return null
        val monthYear = doc.getString("monthYear") ?: return null
        return PaymentRecord(
            studentId = localStudentId,
            monthYear = monthYear,
            amount = doc.getDouble("amount") ?: 250.0,
            isPaid = doc.getBoolean("isPaid") ?: false,
            paymentDate = doc.getString("paymentDate") ?: "",
            notes = doc.getString("notes") ?: ""
        )
    }

    fun snapshotToParentNote(doc: DocumentSnapshot, localStudentId: Long): ParentNote? {
        if (!doc.exists()) return null
        val title = doc.getString("title") ?: return null
        val date = doc.getString("date") ?: return null
        return ParentNote(
            studentId = localStudentId,
            title = title,
            content = doc.getString("content") ?: "",
            date = date,
            teacherName = doc.getString("teacherName") ?: "الأستاذ",
            audioFilePath = "",
            audioDurationSeconds = (doc.getLong("audioDurationSeconds") ?: 0L).toInt()
        )
    }

    fun snapshotToResource(doc: DocumentSnapshot): EducationalResource? {
        if (!doc.exists()) return null
        val title = doc.getString("title") ?: return null
        return EducationalResource(
            title = title,
            subject = doc.getString("subject") ?: "عام",
            groupName = doc.getString("groupName") ?: "الكل",
            description = doc.getString("description") ?: "",
            fileType = doc.getString("fileType") ?: "ملخص مراجعة",
            resourceContent = doc.getString("resourceContent") ?: "",
            localFilePath = "",
            externalUrl = doc.getString("externalUrl") ?: "",
            addedDate = doc.getString("addedDate") ?: ""
        )
    }

    fun snapshotToSchedule(doc: DocumentSnapshot): ClassSchedule? {
        if (!doc.exists()) return null
        val dayName = doc.getString("dayName") ?: return null
        val startTime = doc.getString("startTime") ?: return null
        return ClassSchedule(
            dayOfWeek = (doc.getLong("dayOfWeek") ?: 1L).toInt(),
            dayName = dayName,
            groupName = doc.getString("groupName") ?: "الكل",
            subject = doc.getString("subject") ?: "",
            startTime = startTime,
            endTime = doc.getString("endTime") ?: "",
            location = doc.getString("location") ?: "",
            notes = doc.getString("notes") ?: ""
        )
    }

    fun snapshotToAnnouncement(doc: DocumentSnapshot): Announcement? {
        if (!doc.exists()) return null
        val title = doc.getString("title") ?: return null
        val content = doc.getString("content") ?: return null
        val date = doc.getString("date") ?: return null
        return Announcement(
            title = title,
            content = content,
            groupName = doc.getString("groupName") ?: "الكل",
            date = date,
            isUrgent = doc.getBoolean("isUrgent") ?: false
        )
    }

    fun snapshotToQuestion(doc: DocumentSnapshot, localStudentId: Long): StudentQuestion? {
        if (!doc.exists()) return null
        val studentName = doc.getString("studentName") ?: return null
        val studentCode = doc.getString("studentCode") ?: return null
        val questionText = doc.getString("questionText") ?: return null
        return StudentQuestion(
            studentId = localStudentId,
            studentName = studentName,
            studentCode = normalizeCode(studentCode),
            groupName = doc.getString("groupName") ?: "الكل",
            subject = doc.getString("subject") ?: "عام",
            questionText = questionText,
            questionImagePath = "",
            answerText = doc.getString("answerText") ?: "",
            answerAudioPath = "",
            answerAudioDuration = (doc.getLong("answerAudioDuration") ?: 0L).toInt(),
            isAnswered = doc.getBoolean("isAnswered") ?: false,
            isPinned = doc.getBoolean("isPinned") ?: false,
            isPublicToGroup = doc.getBoolean("isPublicToGroup") ?: true,
            createdDate = doc.getString("createdDate") ?: "",
            answeredDate = doc.getString("answeredDate") ?: "",
            createdAt = doc.getLong("localCreatedAt") ?: System.currentTimeMillis()
        )
    }

    @Suppress("UNCHECKED_CAST")
    fun snapshotToMistake(doc: DocumentSnapshot, localStudentId: Long, localExamId: Long): MistakeRecord? {
        if (!doc.exists()) return null
        val studentCode = doc.getString("studentCode") ?: return null
        val questionText = doc.getString("questionText") ?: return null
        val opts = (doc.get("options") as? List<*>)?.mapNotNull { it as? String } ?: emptyList()
        return MistakeRecord(
            studentId = localStudentId,
            studentCode = normalizeCode(studentCode),
            studentName = doc.getString("studentName") ?: "",
            examId = localExamId,
            examTitle = doc.getString("examTitle") ?: "مراجعة يدوية",
            subject = doc.getString("subject") ?: "عام",
            questionId = (doc.getLong("questionId") ?: 0L).toInt(),
            questionText = questionText,
            questionType = doc.getString("questionType") ?: ExamQuestion.TYPE_MCQ,
            optionsJson = QuestionBankItem.encodeOptions(opts),
            studentAnswer = doc.getString("studentAnswer") ?: "",
            correctAnswer = doc.getString("correctAnswer") ?: "",
            correctOptionIndex = (doc.getLong("correctOptionIndex") ?: 0L).toInt(),
            explanation = doc.getString("explanation") ?: "",
            difficulty = doc.getString("difficulty") ?: ExamQuestion.DIFFICULTY_MEDIUM,
            personalNote = doc.getString("personalNote") ?: "",
            mistakeCount = (doc.getLong("mistakeCount") ?: 1L).toInt(),
            practiceAttempts = (doc.getLong("practiceAttempts") ?: 0L).toInt(),
            isMastered = doc.getBoolean("isMastered") ?: false,
            lastMistakeDate = doc.getString("lastMistakeDate") ?: "",
            createdAt = doc.getLong("localCreatedAt") ?: System.currentTimeMillis(),
            updatedAt = doc.getLong("localUpdatedAt") ?: System.currentTimeMillis()
        )
    }
}
