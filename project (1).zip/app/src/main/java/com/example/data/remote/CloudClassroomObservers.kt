package com.example.data.remote

import com.example.data.Announcement
import com.example.data.AttendanceRecord
import com.example.data.ClassSchedule
import com.example.data.EducationalResource
import com.example.data.HomeworkRecord
import com.example.data.ParentNote
import com.example.data.PaymentRecord
import com.example.data.Student
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class CloudClassroomObservers(private val db: FirebaseFirestore) {

    private fun classroom(teacherUid: String) = db.collection("classrooms").document(teacherUid)

    fun observeMembers(teacherUid: String): Flow<Map<String, String>> =
        classroom(teacherUid).collection("members").snapshots().map { snap ->
            val map = linkedMapOf<String, String>()
            snap.documents.forEach { d ->
                val code = d.getString("studentCode") ?: return@forEach
                val uid = d.getString("memberUid") ?: d.id
                map[CloudMappers.normalizeCode(code)] = uid
            }
            map
        }

    // --- Teacher Collections ---

    fun observeTeacherStudents(teacherUid: String): Flow<List<Student>> =
        classroom(teacherUid).collection("students").snapshots().map { snap ->
            snap.documents.mapNotNull { CloudMappers.snapshotToStudent(it) }
        }

    fun observeTeacherAttendances(teacherUid: String): Flow<List<Pair<String, AttendanceRecord>>> =
        classroom(teacherUid).collection("attendance").snapshots().map(::mapAttendances)

    fun observeTeacherHomeworks(teacherUid: String): Flow<List<Pair<String, HomeworkRecord>>> =
        classroom(teacherUid).collection("homework").snapshots().map(::mapHomeworks)

    fun observeTeacherPayments(teacherUid: String): Flow<List<Pair<String, PaymentRecord>>> =
        classroom(teacherUid).collection("payments").snapshots().map(::mapPayments)

    fun observeTeacherNotes(teacherUid: String): Flow<List<Pair<String, ParentNote>>> =
        classroom(teacherUid).collection("parent_notes").snapshots().map(::mapNotes)

    fun observeTeacherExams(teacherUid: String): Flow<List<CloudExamItem>> =
        classroom(teacherUid).collection("exams").snapshots().map(::mapExams)

    fun observeTeacherSubmissions(teacherUid: String): Flow<List<CloudSubmissionItem>> =
        classroom(teacherUid).collection("exam_submissions").snapshots().map(::mapSubmissions)

    fun observeTeacherResources(teacherUid: String): Flow<List<EducationalResource>> =
        classroom(teacherUid).collection("educational_resources").snapshots().map { snap ->
            snap.documents.mapNotNull { CloudMappers.snapshotToResource(it) }
        }

    fun observeTeacherSchedules(teacherUid: String): Flow<List<ClassSchedule>> =
        classroom(teacherUid).collection("class_schedules").snapshots().map { snap ->
            snap.documents.mapNotNull { CloudMappers.snapshotToSchedule(it) }
        }

    fun observeTeacherAnnouncements(teacherUid: String): Flow<List<Announcement>> =
        classroom(teacherUid).collection("announcements").snapshots().map { snap ->
            snap.documents.mapNotNull { CloudMappers.snapshotToAnnouncement(it) }
        }

    fun observeTeacherQuestions(teacherUid: String): Flow<List<CloudQuestionItem>> =
        classroom(teacherUid).collection("student_questions").snapshots().map(::mapQuestions)

    fun observeTeacherMistakes(teacherUid: String): Flow<List<CloudMistakeItem>> =
        classroom(teacherUid).collection("mistake_bank").snapshots().map(::mapMistakes)

    // --- Student Filtered Collections (zero get()/exists() in rules) ---

    fun observeStudentProfile(teacherUid: String, studentUid: String): Flow<Student?> =
        classroom(teacherUid).collection("students")
            .whereEqualTo("studentAuthUid", studentUid)
            .snapshots()
            .map { snap -> snap.documents.firstOrNull()?.let { CloudMappers.snapshotToStudent(it) } }

    fun observeStudentAttendances(teacherUid: String, studentUid: String): Flow<List<AttendanceRecord>> =
        classroom(teacherUid).collection("attendance")
            .whereEqualTo("studentAuthUid", studentUid)
            .snapshots()
            .map { snap -> mapAttendances(snap).map { it.second } }

    fun observeStudentHomeworks(teacherUid: String, studentUid: String): Flow<List<HomeworkRecord>> =
        classroom(teacherUid).collection("homework")
            .whereEqualTo("studentAuthUid", studentUid)
            .snapshots()
            .map { snap -> mapHomeworks(snap).map { it.second } }

    fun observeStudentPayments(teacherUid: String, studentUid: String): Flow<List<PaymentRecord>> =
        classroom(teacherUid).collection("payments")
            .whereEqualTo("studentAuthUid", studentUid)
            .snapshots()
            .map { snap -> mapPayments(snap).map { it.second } }

    fun observeStudentNotes(teacherUid: String, studentUid: String): Flow<List<ParentNote>> =
        classroom(teacherUid).collection("parent_notes")
            .whereEqualTo("studentAuthUid", studentUid)
            .snapshots()
            .map { snap -> mapNotes(snap).map { it.second } }

    fun observeStudentSubmissions(teacherUid: String, studentUid: String): Flow<List<CloudSubmissionItem>> =
        classroom(teacherUid).collection("exam_submissions")
            .whereEqualTo("studentAuthUid", studentUid)
            .snapshots()
            .map(::mapSubmissions)

    fun observeStudentMistakes(teacherUid: String, studentUid: String): Flow<List<CloudMistakeItem>> =
        classroom(teacherUid).collection("mistake_bank")
            .whereEqualTo("studentAuthUid", studentUid)
            .snapshots()
            .map(::mapMistakes)

    fun observeStudentOwnQuestions(teacherUid: String, studentUid: String): Flow<List<CloudQuestionItem>> =
        classroom(teacherUid).collection("student_questions")
            .whereEqualTo("studentAuthUid", studentUid)
            .snapshots()
            .map(::mapQuestions)

    fun observeSharedExams(teacherUid: String, studentUid: String): Flow<List<CloudExamItem>> =
        classroom(teacherUid).collection("exams")
            .whereArrayContains("memberUids", studentUid)
            .snapshots()
            .map(::mapExams)

    fun observeSharedResources(teacherUid: String, studentUid: String): Flow<List<EducationalResource>> =
        classroom(teacherUid).collection("educational_resources")
            .whereArrayContains("memberUids", studentUid)
            .snapshots()
            .map { snap -> snap.documents.mapNotNull { CloudMappers.snapshotToResource(it) } }

    fun observeSharedSchedules(teacherUid: String, studentUid: String): Flow<List<ClassSchedule>> =
        classroom(teacherUid).collection("class_schedules")
            .whereArrayContains("memberUids", studentUid)
            .snapshots()
            .map { snap -> snap.documents.mapNotNull { CloudMappers.snapshotToSchedule(it) } }

    fun observeSharedAnnouncements(teacherUid: String, studentUid: String): Flow<List<Announcement>> =
        classroom(teacherUid).collection("announcements")
            .whereArrayContains("memberUids", studentUid)
            .snapshots()
            .map { snap -> snap.documents.mapNotNull { CloudMappers.snapshotToAnnouncement(it) } }

    fun observeSharedQuestions(teacherUid: String, studentUid: String): Flow<List<CloudQuestionItem>> =
        classroom(teacherUid).collection("student_questions")
            .whereArrayContains("memberUids", studentUid)
            .snapshots()
            .map(::mapQuestions)

    // --- Snapshot Mapping Helpers ---

    private fun mapAttendances(snap: QuerySnapshot): List<Pair<String, AttendanceRecord>> =
        snap.documents.mapNotNull { d ->
            val code = d.getString("studentCode") ?: return@mapNotNull null
            CloudMappers.snapshotToAttendance(d, 0L)?.let { CloudMappers.normalizeCode(code) to it }
        }

    private fun mapHomeworks(snap: QuerySnapshot): List<Pair<String, HomeworkRecord>> =
        snap.documents.mapNotNull { d ->
            val code = d.getString("studentCode") ?: return@mapNotNull null
            CloudMappers.snapshotToHomework(d, 0L)?.let { CloudMappers.normalizeCode(code) to it }
        }

    private fun mapPayments(snap: QuerySnapshot): List<Pair<String, PaymentRecord>> =
        snap.documents.mapNotNull { d ->
            val code = d.getString("studentCode") ?: return@mapNotNull null
            CloudMappers.snapshotToPayment(d, 0L)?.let { CloudMappers.normalizeCode(code) to it }
        }

    private fun mapNotes(snap: QuerySnapshot): List<Pair<String, ParentNote>> =
        snap.documents.mapNotNull { d ->
            val code = d.getString("studentCode") ?: return@mapNotNull null
            CloudMappers.snapshotToParentNote(d, 0L)?.let { CloudMappers.normalizeCode(code) to it }
        }

    private fun mapExams(snap: QuerySnapshot): List<CloudExamItem> =
        snap.documents.mapNotNull { d -> CloudMappers.snapshotToExam(d)?.let { CloudExamItem(d.id, it) } }

    private fun mapSubmissions(snap: QuerySnapshot): List<CloudSubmissionItem> =
        snap.documents.mapNotNull { d ->
            val examCid = d.getString("examCloudId") ?: return@mapNotNull null
            val code = d.getString("studentCode") ?: return@mapNotNull null
            CloudSubmissionItem(
                docId = d.id,
                examCloudId = examCid,
                studentCode = CloudMappers.normalizeCode(code),
                score = (d.getLong("score") ?: 0L).toInt(),
                maxScore = (d.getLong("maxScore") ?: 1L).toInt(),
                answersJson = CloudMappers.nativeMapToAnswersJson(d.get("answers")),
                submittedAtMs = d.getLong("submittedAtMs") ?: System.currentTimeMillis()
            )
        }

    private fun mapQuestions(snap: QuerySnapshot): List<CloudQuestionItem> =
        snap.documents.mapNotNull { d ->
            CloudMappers.snapshotToQuestion(d, 0L)?.let { CloudQuestionItem(d.id, it) }
        }

    private fun mapMistakes(snap: QuerySnapshot): List<CloudMistakeItem> =
        snap.documents.mapNotNull { d ->
            val examCid = d.getString("examCloudId") ?: ""
            CloudMappers.snapshotToMistake(d, 0L, 0L)?.let { CloudMistakeItem(d.id, examCid, it) }
        }
}
