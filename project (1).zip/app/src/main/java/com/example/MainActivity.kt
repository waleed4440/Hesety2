package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.example.ui.TeacherViewModel
import com.example.ui.UserRole
import com.example.ui.auth.GoogleAuthGateScreen
import com.example.ui.components.ClearInputFocusEffect
import com.example.ui.components.ProvideWindowSafeTextToolbar
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.StudentMainScreen
import com.example.ui.screens.TeacherMainScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.util.AppNotificationManager
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

class MainActivity : ComponentActivity() {
    private val viewModel: TeacherViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        AppNotificationManager.initNotificationChannel(this)
        setContent {
            MyApplicationTheme {
                ProvideWindowSafeTextToolbar {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }

                        DisposableEffect(Unit) {
                            val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
                                currentUser = firebaseAuth.currentUser
                            }
                            Firebase.auth.addAuthStateListener(listener)
                            onDispose {
                                Firebase.auth.removeAuthStateListener(listener)
                            }
                        }

                        val user = currentUser
                        if (user == null) {
                            GoogleAuthGateScreen(
                                onAuthSuccess = {
                                    currentUser = Firebase.auth.currentUser
                                }
                            )
                        } else {
                            key(user.uid) {
                                LaunchedEffect(user.uid) {
                                    viewModel.onGoogleSignedIn()
                                }
                                NotificationPermissionHandler()
                                AppNavigationRoot(viewModel = viewModel)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NotificationPermissionHandler() {
    val context = LocalContext.current
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        val permissionLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.RequestPermission()
        ) { _ -> }

        LaunchedEffect(Unit) {
            val hasPermission = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!hasPermission) {
                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}

@Composable
fun AppNavigationRoot(viewModel: TeacherViewModel) {
    val role by viewModel.currentUserRole.collectAsState()
    ClearInputFocusEffect(role)

    when (role) {
        UserRole.NONE -> {
            LoginScreen(viewModel = viewModel)
        }
        UserRole.TEACHER -> {
            TeacherMainScreen(viewModel = viewModel)
        }
        UserRole.STUDENT -> {
            StudentMainScreen(viewModel = viewModel)
        }
    }
}
