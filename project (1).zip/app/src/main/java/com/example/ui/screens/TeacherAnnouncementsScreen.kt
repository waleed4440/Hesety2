package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.Announcement
import com.example.ui.TeacherViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.EmptyStateView
import com.example.ui.components.SafeAlertDialog
import com.example.ui.components.StatusBadge
import com.example.ui.components.rememberActiveInputDismisser
import com.example.ui.theme.AcademicBluePrimary
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.calmAnnouncementPalette

@Composable
fun TeacherAnnouncementsScreen(
    viewModel: TeacherViewModel,
    modifier: Modifier = Modifier
) {
    val announcements by viewModel.allAnnouncements.collectAsState()
    val context = LocalContext.current
    var showAddDialog by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = AcademicBluePrimary,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("fab_post_announcement")
            ) {
                Icon(Icons.Default.Add, contentDescription = "نشر تنبيه جديد")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AppHeader(
                title = "التنبيهات والإشعارات (${announcements.size})",
                subtitle = "نشر رسائل وتذكيرات فورية لكافة الطلاب وأولياء الأمور"
            )

            if (announcements.isEmpty()) {
                EmptyStateView(
                    title = "لا توجد تنبيهات منشورة",
                    description = "اضغط على زر (+) لإرسال أول إشعار أو تنبيه للطلاب",
                    icon = Icons.Default.Campaign
                )
            } else {
                val isDark = isSystemInDarkTheme()
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(announcements) { notice ->
                        val palette = calmAnnouncementPalette(isUrgent = notice.isUrgent, isDarkTheme = isDark)
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = palette.container),
                            border = BorderStroke(1.dp, palette.border),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("card_announcement_${notice.id}")
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = notice.title,
                                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                                color = palette.title
                                            )
                                            if (notice.isUrgent) {
                                                Spacer(modifier = Modifier.padding(horizontal = 4.dp))
                                                StatusBadge(
                                                    text = "عاجل وهام",
                                                    color = palette.badgeText,
                                                    bgColor = palette.badgeBg
                                                )
                                            }
                                        }
                                        Text(
                                            text = "المجموعة: ${notice.groupName} • التاريخ: ${notice.date}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = palette.meta
                                        )
                                    }

                                    IconButton(
                                        onClick = {
                                            viewModel.deleteAnnouncement(notice)
                                            Toast.makeText(context, "تم حذف الإعلان", Toast.LENGTH_SHORT).show()
                                        }
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = StatusDanger)
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = notice.content,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = palette.body
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        var title by remember { mutableStateOf("") }
        var content by remember { mutableStateOf("") }
        var isUrgent by remember { mutableStateOf(false) }

        SafeAlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("نشر تنبيه أو إشعار فوري للطلاب") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("عنوان التنبيه (مثال: تذكير بموعد الامتحان)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = content,
                        onValueChange = { content = it },
                        label = { Text("نص التنبيه والتعليمات") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Checkbox(checked = isUrgent, onCheckedChange = { isUrgent = it })
                        Text("تحديد كتنبيه عاجل وهام", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            },
            confirmButton = {
                val dismissInput = rememberActiveInputDismisser()
                Button(
                    onClick = {
                        if (title.isNotBlank() && content.isNotBlank()) {
                            dismissInput()
                            viewModel.postAnnouncement(title, content, "الكل", isUrgent)
                            showAddDialog = false
                            Toast.makeText(context, "تم نشر التنبيه بنجاح للطلاب", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary)
                ) {
                    Text("إرسال ونشر")
                }
            },
            dismissButton = {
                val dismissInput = rememberActiveInputDismisser()
                OutlinedButton(onClick = {
                    dismissInput()
                    showAddDialog = false
                }) {
                    Text("إلغاء")
                }
            }
        )
    }
}
