package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AttendanceRecord
import com.example.data.HomeworkRecord
import com.example.data.Student
import com.example.ui.TeacherViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.EmptyStateView
import com.example.ui.components.QuickParentContactDialog
import com.example.ui.components.SafeAlertDialog
import com.example.ui.theme.AcademicBlueContainer
import com.example.ui.theme.AcademicBluePrimary
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusDangerContainer
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessContainer
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningContainer
import com.example.util.ParentCommunicationHelper
import com.example.util.ParentMessageTemplate
import com.example.util.StudentGuardianSnapshot

@Composable
fun TeacherAttendanceScreen(
    viewModel: TeacherViewModel,
    modifier: Modifier = Modifier
) {
    val students by viewModel.allStudents.collectAsState()
    val attendanceRecords by viewModel.currentSessionAttendance.collectAsState()
    val homeworkRecords by viewModel.currentSessionHomework.collectAsState()
    val allAttendances by viewModel.allAttendances.collectAsState()
    val allHomework by viewModel.allHomework.collectAsState()
    val allNotes by viewModel.allNotes.collectAsState()
    val payments by viewModel.allPayments.collectAsState()
    val allSubmissions by viewModel.allSubmissions.collectAsState()
    val allExams by viewModel.allExams.collectAsState()
    val sessionDate by viewModel.selectedSessionDate.collectAsState()
    val selectedGroup by viewModel.selectedGroupFilter.collectAsState()
    val context = LocalContext.current

    var searchQuery by remember { mutableStateOf("") }
    var showQrScannerDialog by remember { mutableStateOf(false) }
    var showAbsentFollowUpDialog by remember { mutableStateOf(false) }
    var quickContactState by remember { mutableStateOf<Pair<StudentGuardianSnapshot, ParentMessageTemplate>?>(null) }

    val distinctGroups = listOf("الكل") + students.map { it.groupName }.distinct()
    val filteredStudents = students.filter { s ->
        val matchesGroup = selectedGroup == "الكل" || s.groupName == selectedGroup
        val matchesSearch = s.name.contains(searchQuery, ignoreCase = true) || s.code.contains(searchQuery, ignoreCase = true)
        matchesGroup && matchesSearch
    }

    val activeStudentIds = remember(students) { students.map { it.id }.toSet() }
    val presentCount = attendanceRecords.count { it.studentId in activeStudentIds && it.status == AttendanceRecord.STATUS_PRESENT }
    val absentCount = attendanceRecords.count { it.studentId in activeStudentIds && it.status == AttendanceRecord.STATUS_ABSENT }
    val hwDoneCount = homeworkRecords.count { it.studentId in activeStudentIds && it.status == HomeworkRecord.STATUS_COMPLETED }

    Column(
        modifier = modifier
            .fillMaxSize()
    ) {
        AppHeader(
            title = "تسجيل الحضور والواجب والمصروفات",
            subtitle = "تاريخ الحصة: $sessionDate"
        )

        // Session Date & Quick Dates
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 1.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = null,
                            tint = AcademicBluePrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "تاريخ الحصة: $sessionDate",
                            fontWeight = FontWeight.Bold,
                            color = AcademicBluePrimary
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = sessionDate == "2026-11-11",
                            onClick = { viewModel.setSessionDate("2026-11-11") },
                            label = { Text("اليوم", fontSize = 11.sp) }
                        )
                        FilterChip(
                            selected = sessionDate == "2026-11-10",
                            onClick = { viewModel.setSessionDate("2026-11-10") },
                            label = { Text("أمس", fontSize = 11.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Group Filter Chips
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(distinctGroups) { grp ->
                        FilterChip(
                            selected = selectedGroup == grp,
                            onClick = { viewModel.setSelectedGroupFilter(grp) },
                            label = { Text(grp) },
                            modifier = Modifier.testTag("filter_session_grp_$grp")
                        )
                    }
                }
            }
        }

        // Student Search Bar during class
        Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("بحث عن طالب بالاسم أو الكود لتسجيل الحضور...") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "بحث",
                        tint = AcademicBluePrimary
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "مسح البحث")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_session_student_input")
            )
        }

        // QR Attendance & Fast Absentee Follow-up Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { showQrScannerDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("btn_open_qr_scanner")
            ) {
                Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("مسح QR للحضور", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = { showAbsentFollowUpDialog = true },
                colors = ButtonDefaults.buttonColors(
                    containerColor = StatusDangerContainer,
                    contentColor = StatusDanger
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("btn_absent_followup")
            ) {
                Icon(Icons.Default.Warning, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("متابعة الغائبين ($absentCount)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Quick Batch Action Buttons
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = {
                    viewModel.markAllAttendance(filteredStudents, AttendanceRecord.STATUS_PRESENT)
                    Toast.makeText(context, "تم تحضير جميع الطلاب كحاضرين", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("btn_mark_all_present"),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("تحضير الكل", fontSize = 11.sp)
            }

            OutlinedButton(
                onClick = {
                    viewModel.markAllHomework(filteredStudents, HomeworkRecord.STATUS_COMPLETED)
                    Toast.makeText(context, "تم تعيين الواجب تم الحل للجميع", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("btn_mark_all_hw"),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("الكل حل الواجب", fontSize = 11.sp)
            }
        }

        if (filteredStudents.isEmpty()) {
            EmptyStateView(
                title = "لا يوجد طلاب في هذه المجموعة",
                description = "اختر مجموعة أخرى أو أضف طلاباً من تبويب إدارة الطلاب",
                icon = Icons.Default.Person
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredStudents) { student ->
                    val attRecord = attendanceRecords.firstOrNull { it.studentId == student.id }
                    val currentAttendance = attRecord?.status ?: ""

                    val hwRecord = homeworkRecords.firstOrNull { it.studentId == student.id }
                    val currentHomework = hwRecord?.status ?: ""

                    val paymentRecord = payments.firstOrNull { it.studentId == student.id }
                    val isPaid = paymentRecord?.isPaid ?: false

                    StudentSessionCard(
                        student = student,
                        attendanceStatus = currentAttendance,
                        homeworkStatus = currentHomework,
                        isPaid = isPaid,
                        onAttendanceChanged = { status ->
                            viewModel.toggleAttendance(student.id, status)
                        },
                        onHomeworkChanged = { status ->
                            viewModel.toggleHomework(student.id, status)
                        },
                        onPaymentChanged = { paid ->
                            viewModel.togglePayment(student.id, "نوفمبر 2026", paid, student.monthlyFee)
                        },
                        onQuickContact = {
                            val smartTemplate = when {
                                currentAttendance == AttendanceRecord.STATUS_ABSENT -> ParentMessageTemplate.ABSENCE_ALERT
                                currentHomework == HomeworkRecord.STATUS_NOT_COMPLETED || currentHomework == HomeworkRecord.STATUS_PARTIAL ->
                                    ParentMessageTemplate.HOMEWORK_REMINDER
                                !isPaid -> ParentMessageTemplate.PAYMENT_REMINDER
                                else -> ParentMessageTemplate.FULL_REPORT
                            }
                            val snapshot = ParentCommunicationHelper.buildSnapshot(
                                student = student,
                                allAttendances = allAttendances,
                                allHomework = allHomework,
                                allPayments = payments,
                                allSubmissions = allSubmissions,
                                allExams = allExams,
                                allNotes = allNotes,
                                sessionDate = sessionDate
                            )
                            quickContactState = snapshot to smartTemplate
                        }
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(30.dp))
                }
            }
        }
    }

    if (showQrScannerDialog) {
        com.example.ui.components.QrAttendanceScannerDialog(
            sessionDate = sessionDate,
            onQrScanned = { rawCode, markHw, cb ->
                viewModel.markAttendanceByQrCode(rawCode, markHw, cb)
            },
            onDismiss = { showQrScannerDialog = false }
        )
    }

    if (showAbsentFollowUpDialog) {
        AbsenteeFollowUpDialog(
            sessionDate = sessionDate,
            students = filteredStudents,
            attendanceRecords = attendanceRecords,
            allSubmissions = allSubmissions,
            allExams = allExams,
            onMarkUnmarkedAbsent = {
                viewModel.markUnmarkedAsAbsent(filteredStudents)
                Toast.makeText(context, "تم تسجيل غير المسجلين كغائبين", Toast.LENGTH_SHORT).show()
            },
            onQuickStatusChange = { studentId, status ->
                viewModel.toggleAttendance(studentId, status)
            },
            onDismiss = { showAbsentFollowUpDialog = false }
        )
    }

    if (quickContactState != null) {
        QuickParentContactDialog(
            snapshot = quickContactState!!.first,
            initialTemplate = quickContactState!!.second,
            onDismiss = { quickContactState = null }
        )
    }
}

@Composable
private fun AbsenteeFollowUpDialog(
    sessionDate: String,
    students: List<Student>,
    attendanceRecords: List<AttendanceRecord>,
    allSubmissions: List<com.example.data.ExamSubmission>,
    allExams: List<com.example.data.Exam>,
    onMarkUnmarkedAbsent: () -> Unit,
    onQuickStatusChange: (Long, String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val attendanceByStudent = remember(attendanceRecords) {
        attendanceRecords.associateBy { it.studentId }
    }
    val absentStudents = remember(students, attendanceByStudent) {
        students.filter { attendanceByStudent[it.id]?.status == AttendanceRecord.STATUS_ABSENT }
    }
    val unmarkedCount = remember(students, attendanceByStudent) {
        students.count { attendanceByStudent[it.id] == null }
    }
    var contactedIds by remember { mutableStateOf(setOf<Long>()) }

    SafeAlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(
                    text = "المتابعة السريعة للغائبين",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "تاريخ الحصة: $sessionDate • غائب: ${absentStudents.size} • غير مسجل: $unmarkedCount",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (unmarkedCount > 0) {
                    OutlinedButton(
                        onClick = onMarkUnmarkedAbsent,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_mark_unmarked_absent")
                    ) {
                        Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تسجيل غير المسجلين كغائبين ($unmarkedCount)", fontSize = 12.sp)
                    }
                }

                if (absentStudents.isEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = StatusSuccessContainer.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "لا يوجد طلاب مسجلون كغائبين حالياً في هذه الحصة.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = StatusSuccess,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(320.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(absentStudents, key = { it.id }) { student ->
                            val latestSub = allSubmissions
                                .filter { it.studentId == student.id }
                                .maxByOrNull { it.submittedAt }
                            val latestExamTitle = latestSub?.let { sub ->
                                allExams.firstOrNull { it.id == sub.examId }?.title
                            }
                            val examSummary = latestSub?.let { sub ->
                                if (latestExamTitle != null) "${sub.score}/${sub.maxScore} ($latestExamTitle)"
                                else "${sub.score}/${sub.maxScore}"
                            }
                            val isContacted = student.id in contactedIds

                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = student.name,
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.bodyMedium
                                            )
                                            Text(
                                                text = "${student.groupName} • كود: ${student.code}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        if (isContacted) {
                                            Surface(shape = RoundedCornerShape(8.dp), color = StatusSuccessContainer) {
                                                Text(
                                                    text = "تم التواصل ✓",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = StatusSuccess,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                                )
                                            }
                                        }
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(14.dp), tint = AcademicBluePrimary)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "ولي الأمر: ${student.parentPhone.ifBlank { "غير مسجل" }}",
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    }

                                    if (examSummary != null) {
                                        Text(
                                            text = "آخر امتحان: $examSummary",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = AcademicBluePrimary
                                        )
                                    }

                                        Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Button(
                                            onClick = {
                                                contactedIds = contactedIds + student.id
                                                com.example.util.QrCodeHelper.sendAbsenteeWhatsAppMessage(
                                                    context = context,
                                                    student = student,
                                                    date = sessionDate,
                                                    latestExamSummary = examSummary
                                                )
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("btn_whatsapp_absent_${student.id}")
                                        ) {
                                            Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("واتساب", fontSize = 11.sp)
                                        }

                                        if (ParentCommunicationHelper.normalizeDialPhone(student.parentPhone) != null) {
                                            IconButton(
                                                onClick = {
                                                    contactedIds = contactedIds + student.id
                                                    ParentCommunicationHelper.dialParent(context, student.parentPhone)
                                                },
                                                modifier = Modifier
                                                    .size(48.dp)
                                                    .testTag("btn_call_absent_${student.id}")
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Call,
                                                    contentDescription = "اتصال بولي أمر ${student.name}",
                                                    tint = StatusSuccess
                                                )
                                            }
                                        }

                                        OutlinedButton(
                                            onClick = { onQuickStatusChange(student.id, AttendanceRecord.STATUS_EXCUSED) },
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("بعذر", fontSize = 11.sp)
                                        }

                                        OutlinedButton(
                                            onClick = { onQuickStatusChange(student.id, AttendanceRecord.STATUS_PRESENT) },
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("حضر", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary)
            ) {
                Text("إغلاق")
            }
        }
    )
}

@Composable
fun StudentSessionCard(
    student: Student,
    attendanceStatus: String,
    homeworkStatus: String,
    isPaid: Boolean,
    onAttendanceChanged: (String) -> Unit,
    onHomeworkChanged: (String) -> Unit,
    onPaymentChanged: (Boolean) -> Unit,
    onQuickContact: () -> Unit = {}
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(AcademicBlueContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = student.code.takeLast(3),
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = AcademicBluePrimary
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = student.name,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "الكود: ${student.code} • ${student.groupName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                IconButton(
                    onClick = onQuickContact,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("btn_session_contact_${student.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.PhoneInTalk,
                        contentDescription = "تواصل سريع مع ولي أمر ${student.name}",
                        tint = AcademicBluePrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            Spacer(modifier = Modifier.height(10.dp))

            // 1. Attendance Toggle Row
            Text(
                text = "1. تسجيل الحضور والغياب:",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                SelectableStatusPill(
                    text = "حاضر",
                    isSelected = attendanceStatus == AttendanceRecord.STATUS_PRESENT,
                    activeColor = StatusSuccess,
                    activeBg = StatusSuccessContainer,
                    modifier = Modifier.weight(1f),
                    testTag = "pill_present_${student.id}",
                    onClick = { onAttendanceChanged(AttendanceRecord.STATUS_PRESENT) }
                )
                SelectableStatusPill(
                    text = "غائب",
                    isSelected = attendanceStatus == AttendanceRecord.STATUS_ABSENT,
                    activeColor = StatusDanger,
                    activeBg = StatusDangerContainer,
                    modifier = Modifier.weight(1f),
                    testTag = "pill_absent_${student.id}",
                    onClick = { onAttendanceChanged(AttendanceRecord.STATUS_ABSENT) }
                )
                SelectableStatusPill(
                    text = "متأخر",
                    isSelected = attendanceStatus == AttendanceRecord.STATUS_LATE,
                    activeColor = StatusWarning,
                    activeBg = StatusWarningContainer,
                    modifier = Modifier.weight(1f),
                    testTag = "pill_late_${student.id}",
                    onClick = { onAttendanceChanged(AttendanceRecord.STATUS_LATE) }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 2. Homework Toggle Row
            Text(
                text = "2. تقييم حل الواجب:",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                SelectableStatusPill(
                    text = "تم الحل ✓",
                    isSelected = homeworkStatus == HomeworkRecord.STATUS_COMPLETED,
                    activeColor = StatusSuccess,
                    activeBg = StatusSuccessContainer,
                    modifier = Modifier.weight(1f),
                    testTag = "pill_hw_done_${student.id}",
                    onClick = { onHomeworkChanged(HomeworkRecord.STATUS_COMPLETED) }
                )
                SelectableStatusPill(
                    text = "لم يحل ✗",
                    isSelected = homeworkStatus == HomeworkRecord.STATUS_NOT_COMPLETED,
                    activeColor = StatusDanger,
                    activeBg = StatusDangerContainer,
                    modifier = Modifier.weight(1f),
                    testTag = "pill_hw_not_${student.id}",
                    onClick = { onHomeworkChanged(HomeworkRecord.STATUS_NOT_COMPLETED) }
                )
                SelectableStatusPill(
                    text = "حل جزئي ⚠",
                    isSelected = homeworkStatus == HomeworkRecord.STATUS_PARTIAL,
                    activeColor = StatusWarning,
                    activeBg = StatusWarningContainer,
                    modifier = Modifier.weight(1f),
                    testTag = "pill_hw_partial_${student.id}",
                    onClick = { onHomeworkChanged(HomeworkRecord.STATUS_PARTIAL) }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 3. Payment Toggle Row
            Text(
                text = "3. المصروفات الشهرية (${student.monthlyFee} ج.م):",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                SelectableStatusPill(
                    text = "تم السداد (دفع)",
                    isSelected = isPaid,
                    activeColor = StatusSuccess,
                    activeBg = StatusSuccessContainer,
                    modifier = Modifier.weight(1f),
                    testTag = "pill_paid_${student.id}",
                    onClick = { onPaymentChanged(true) }
                )
                SelectableStatusPill(
                    text = "مستحق (لم يدفع)",
                    isSelected = !isPaid,
                    activeColor = StatusDanger,
                    activeBg = StatusDangerContainer,
                    modifier = Modifier.weight(1f),
                    testTag = "pill_unpaid_${student.id}",
                    onClick = { onPaymentChanged(false) }
                )
            }
        }
    }
}

@Composable
fun SelectableStatusPill(
    text: String,
    isSelected: Boolean,
    activeColor: Color,
    activeBg: Color,
    modifier: Modifier = Modifier,
    testTag: String = "",
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (isSelected) activeBg else MaterialTheme.colorScheme.surfaceVariant,
        modifier = modifier
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) activeColor else Color.Transparent,
                shape = RoundedCornerShape(10.dp)
            )
            .clickable { onClick() }
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium
                ),
                color = if (isSelected) activeColor else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
