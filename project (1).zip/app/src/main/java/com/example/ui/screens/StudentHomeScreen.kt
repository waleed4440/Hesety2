package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SwitchAccount
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AttendanceRecord
import com.example.data.HomeworkRecord
import com.example.data.Student
import com.example.data.remote.CloudSyncStatus
import com.example.ui.StudentTab
import com.example.ui.TeacherViewModel
import com.example.ui.components.AttendanceBadge
import com.example.ui.components.ClearInputFocusEffect
import com.example.ui.components.EmptyStateView
import com.example.ui.components.HomeworkBadge
import com.example.ui.components.PaymentBadge
import com.example.ui.components.VoiceNotePlayerBar
import com.example.ui.components.rememberActiveInputDismisser
import com.example.ui.theme.AcademicBlueContainer
import com.example.ui.theme.AcademicBluePrimary
import com.example.ui.theme.AcademicBlueSecondary
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningContainer
import com.example.ui.theme.calmAnnouncementPalette

@Composable
fun StudentMainScreen(
    viewModel: TeacherViewModel,
    modifier: Modifier = Modifier
) {
    val student by viewModel.currentStudent.collectAsState()
    val activeTakingExam by viewModel.activeTakingExam.collectAsState()
    val isRetakingExam by viewModel.isRetakingExam.collectAsState()
    val currentTab by viewModel.studentTab.collectAsState()
    val dismissInput = rememberActiveInputDismisser()

    ClearInputFocusEffect(currentTab to (activeTakingExam != null))

    if (student == null) {
        EmptyStateView(
            title = "لا يوجد طالب مسجل",
            description = "يرجى تسجيل الدخول بكود الطالب",
            icon = Icons.Default.Person
        )
        return
    }

    // If student is currently taking or reviewing an exam, show interactive exam view
    if (activeTakingExam != null) {
        val studentSubmissions by viewModel.studentSubmissions.collectAsState()
        val existingSubmission = if (isRetakingExam) null else studentSubmissions.firstOrNull { it.examId == activeTakingExam!!.id }
        StudentExamTakerScreen(
            exam = activeTakingExam!!,
            student = student!!,
            existingSubmission = existingSubmission,
            onFinish = { score, maxScore, answersJson ->
                viewModel.submitStudentExam(
                    examId = activeTakingExam!!.id,
                    studentId = student!!.id,
                    score = score,
                    maxScore = maxScore,
                    answersJson = answersJson
                )
            },
            onCancel = {
                viewModel.finishTakingExam()
            },
            onOpenMistakeBank = {
                viewModel.finishTakingExam()
                viewModel.setStudentTab(StudentTab.MISTAKE_BANK)
            }
        )
        return
    }

    BackHandler(enabled = currentTab != StudentTab.HOME) {
        dismissInput()
        viewModel.setStudentTab(StudentTab.HOME)
    }

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                NavigationBarItem(
                    selected = currentTab == StudentTab.HOME,
                    onClick = {
                        dismissInput()
                        viewModel.setStudentTab(StudentTab.HOME)
                    },
                    icon = { Icon(Icons.Default.Person, contentDescription = "الرئيسية") },
                    label = { Text("الرئيسية") },
                    modifier = Modifier.testTag("nav_student_home")
                )
                NavigationBarItem(
                    selected = currentTab == StudentTab.EXAMS,
                    onClick = {
                        dismissInput()
                        viewModel.setStudentTab(StudentTab.EXAMS)
                    },
                    icon = { Icon(Icons.Default.Quiz, contentDescription = "الامتحانات") },
                    label = { Text("الامتحانات") },
                    modifier = Modifier.testTag("nav_student_exams")
                )
                NavigationBarItem(
                    selected = currentTab == StudentTab.RESOURCES,
                    onClick = {
                        dismissInput()
                        viewModel.setStudentTab(StudentTab.RESOURCES)
                    },
                    icon = { Icon(Icons.Default.Description, contentDescription = "المصادر") },
                    label = { Text("المصادر") },
                    modifier = Modifier.testTag("nav_student_resources")
                )
                NavigationBarItem(
                    selected = currentTab == StudentTab.NOTICES,
                    onClick = {
                        dismissInput()
                        viewModel.setStudentTab(StudentTab.NOTICES)
                    },
                    icon = { Icon(Icons.Default.Notifications, contentDescription = "التنبيهات") },
                    label = { Text("التنبيهات") },
                    modifier = Modifier.testTag("nav_student_notices")
                )
                NavigationBarItem(
                    selected = currentTab == StudentTab.REPORT,
                    onClick = {
                        dismissInput()
                        viewModel.setStudentTab(StudentTab.REPORT)
                    },
                    icon = { Icon(Icons.Default.Star, contentDescription = "مستواي") },
                    label = { Text("مستواي") },
                    modifier = Modifier.testTag("nav_student_report")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .consumeWindowInsets(innerPadding)
                .imePadding()
        ) {
            when (currentTab) {
                StudentTab.HOME -> StudentDashboardContent(viewModel, student!!)
                StudentTab.EXAMS -> StudentExamsTab(viewModel, student!!)
                StudentTab.MISTAKE_BANK -> MistakeBankScreen(
                    viewModel = viewModel,
                    isTeacher = false,
                    currentStudent = student,
                    onBack = { viewModel.setStudentTab(StudentTab.EXAMS) }
                )
                StudentTab.RESOURCES -> StudentResourcesTab(viewModel, student!!)
                StudentTab.NOTICES -> StudentAnnouncementsTab(viewModel)
                StudentTab.REPORT -> StudentReportCardTab(viewModel, student!!)
                StudentTab.QA_CORNER -> AskTeacherScreen(
                    viewModel = viewModel,
                    isTeacher = false,
                    currentStudent = student,
                    onBack = { viewModel.setStudentTab(StudentTab.HOME) }
                )
            }
        }
    }
}

@Composable
fun StudentDashboardContent(
    viewModel: TeacherViewModel,
    student: Student
) {
    val attendanceList by viewModel.studentAttendance.collectAsState()
    val homeworkList by viewModel.studentHomework.collectAsState()
    val paymentsList by viewModel.studentPayments.collectAsState()
    val notesList by viewModel.studentNotes.collectAsState()
    val announcements by viewModel.allAnnouncements.collectAsState()
    val schedules by viewModel.allSchedules.collectAsState()
    val allQuestions by viewModel.allQuestions.collectAsState()
    val studentMistakes by viewModel.studentMistakes.collectAsState()
    val allExams by viewModel.allExams.collectAsState()
    val savedAccounts by viewModel.savedAccounts.collectAsState()
    val currentAccountId by viewModel.currentAccountId.collectAsState()
    val cloudSyncStatus by viewModel.cloudSyncStatus.collectAsState()
    var showQrPassDialog by remember { mutableStateOf(false) }
    var showWeeklyScheduleDialog by remember { mutableStateOf(false) }
    var showAccountSwitcher by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }

    val unmasteredMistakesCount = studentMistakes.count { m ->
        !m.isMastered && (m.examId == 0L || allExams.firstOrNull { it.id == m.examId }?.let { it.showResultImmediately || !it.isActive } != false)
    }

    val visibleQuestionsCount = allQuestions.count { q ->
        q.studentId == student.id ||
            (q.isPublicToGroup && (q.groupName.equals(student.groupName, ignoreCase = true) || q.groupName == "الكل"))
    }

    val todayDate = viewModel.selectedSessionDate.collectAsState().value
    val todayAttendance = attendanceList.firstOrNull { it.date == todayDate }?.status ?: ""
    val todayHomework = homeworkList.firstOrNull { it.date == todayDate }?.status ?: ""
    val latestPayment = paymentsList.firstOrNull()
    val isPaidThisMonth = latestPayment?.isPaid ?: false

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Student Profile Header Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = AcademicBluePrimary),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                listOf(AcademicBluePrimary, AcademicBlueSecondary)
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = student.name,
                                        style = MaterialTheme.typography.titleLarge.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 20.sp
                                        ),
                                        color = Color.White
                                    )
                                    Text(
                                        text = "كود الطالب: ${student.code}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = AcademicBlueContainer
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = Color.White.copy(alpha = 0.16f)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                                        ) {
                                            Icon(
                                                imageVector = when (cloudSyncStatus) {
                                                    CloudSyncStatus.SYNCED -> Icons.Default.CloudDone
                                                    CloudSyncStatus.CONNECTING -> Icons.Default.CloudSync
                                                    CloudSyncStatus.OFFLINE_LOCAL -> Icons.Default.CloudOff
                                                },
                                                contentDescription = "حالة السيرفر",
                                                tint = Color.White,
                                                modifier = Modifier.size(13.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = when (cloudSyncStatus) {
                                                    CloudSyncStatus.SYNCED -> "السيرفر متصل"
                                                    CloudSyncStatus.CONNECTING -> "جاري الاتصال..."
                                                    CloudSyncStatus.OFFLINE_LOCAL -> "وضع محلي"
                                                },
                                                style = MaterialTheme.typography.labelSmall,
                                                color = Color.White
                                            )
                                        }
                                    }
                                }
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    onClick = { showAccountSwitcher = true },
                                    shape = RoundedCornerShape(20.dp),
                                    color = Color.White.copy(alpha = 0.2f),
                                    modifier = Modifier
                                        .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                                        .testTag("btn_student_accounts")
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.SwitchAccount,
                                            contentDescription = "تبديل الحساب",
                                            tint = Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "${savedAccounts.size}",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }
                                }

                                IconButton(
                                    onClick = { showQrPassDialog = true },
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.2f))
                                        .testTag("btn_student_qr_top")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.QrCode2,
                                        contentDescription = "بطاقة الحضور QR",
                                        tint = Color.White
                                    )
                                }

                                IconButton(
                                    onClick = { showAboutDialog = true },
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.2f))
                                        .testTag("btn_student_about_top")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Info,
                                        contentDescription = "حول التطبيق",
                                        tint = Color.White
                                    )
                                }

                                IconButton(
                                    onClick = { viewModel.logout() },
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.2f))
                                        .testTag("btn_student_logout")
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.Logout,
                                        contentDescription = "خروج",
                                        tint = Color.White
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        HorizontalDivider(color = Color.White.copy(alpha = 0.2f))
                        Spacer(modifier = Modifier.height(14.dp))

                        // Group & Schedule Time Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Group,
                                    contentDescription = null,
                                    tint = AcademicBlueContainer,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = student.groupName,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                                    color = Color.White,
                                    maxLines = 1
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccessTime,
                                contentDescription = null,
                                tint = AcademicBlueContainer,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "الموعد: ${student.scheduleTime}",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }

        // Urgent Alert if any
        val urgentNotice = announcements.firstOrNull { it.isUrgent }
        if (urgentNotice != null) {
            item {
                val urgentPalette = calmAnnouncementPalette(isUrgent = true, isDarkTheme = isSystemInDarkTheme())
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = urgentPalette.container),
                    border = BorderStroke(1.dp, urgentPalette.border),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("card_urgent_notice_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Campaign,
                            contentDescription = null,
                            tint = urgentPalette.iconTint,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = urgentNotice.title,
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = urgentPalette.title
                            )
                            Text(
                                text = urgentNotice.content,
                                style = MaterialTheme.typography.bodySmall,
                                color = urgentPalette.body
                            )
                        }
                    }
                }
            }
        }

        // Today's Follow-up Status Section
        item {
            Text(
                text = "متابعة اليوم والحصص الأخيرة",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // 1. Attendance row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(AcademicBlueContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = AcademicBluePrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "حضور وغياب اليوم",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "تسجيل الأستاذ الرسمي",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        AttendanceBadge(status = todayAttendance)
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)

                    // 2. Homework row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(AcademicBlueContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Assignment,
                                    contentDescription = null,
                                    tint = AcademicBluePrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "الواجب المنزلي",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "تقييم حل تدريبات الحصة",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        HomeworkBadge(status = todayHomework)
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)

                    // 3. Payment row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(AcademicBlueContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CreditCard,
                                    contentDescription = null,
                                    tint = AcademicBluePrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "مصروفات الشهر",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "${student.monthlyFee} ج.م",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        PaymentBadge(isPaid = isPaidThisMonth)
                    }
                }
            }
        }

        // Guardian Notes Card ("ملاحظات المعلم لولي الأمر")
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = StatusWarning
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "ملاحظات وتوجيهات الأستاذ لولي الأمر",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    val recentNotes = notesList.take(3)
                    if (recentNotes.isNotEmpty()) {
                        val notePalette = calmAnnouncementPalette(isUrgent = false, isDarkTheme = isSystemInDarkTheme())
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            recentNotes.forEach { note ->
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = notePalette.container,
                                    border = BorderStroke(1.dp, notePalette.border),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = note.title,
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = notePalette.title
                                            )
                                            Text(
                                                text = note.date,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = notePalette.meta
                                            )
                                        }
                                        if (note.content.isNotBlank()) {
                                            Text(
                                                text = note.content,
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = notePalette.body
                                            )
                                        }
                                        if (note.hasAudio()) {
                                            VoiceNotePlayerBar(
                                                audioPath = note.audioFilePath,
                                                durationSeconds = note.audioDurationSeconds,
                                                label = "رسالة صوتية من الأستاذ",
                                                showShareButton = false
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        Text(
                            text = "لا توجد ملاحظات مسجلة حالياً من الأستاذ. سلوك الطالب ممتاز.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Quick Navigation to Online Exams & Resources
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("card_goto_exams"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = AcademicBlueContainer),
                    onClick = { viewModel.setStudentTab(StudentTab.EXAMS) }
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Quiz,
                            contentDescription = null,
                            tint = AcademicBluePrimary,
                            modifier = Modifier.size(28.dp)
                        )
                        Text(
                            text = "الامتحانات الأونلاين",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = AcademicBluePrimary
                        )
                        Text(
                            text = "ابدأ حل الاختبارات الآن",
                            style = MaterialTheme.typography.bodySmall,
                            color = AcademicBluePrimary.copy(alpha = 0.8f)
                        )
                    }
                }

                Card(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("card_goto_resources"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    onClick = { viewModel.setStudentTab(StudentTab.RESOURCES) }
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Description,
                            contentDescription = null,
                            tint = AcademicBluePrimary,
                            modifier = Modifier.size(28.dp)
                        )
                        Text(
                            text = "المذكرات والمصادر",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "ملخصات وكتب PDF",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // QR Code Pass & Weekly Schedule Quick Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("card_student_qr"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = AcademicBlueContainer),
                    onClick = { showQrPassDialog = true }
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCode2,
                            contentDescription = null,
                            tint = AcademicBluePrimary,
                            modifier = Modifier.size(28.dp)
                        )
                        Text(
                            text = "بطاقة الـ QR Code",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = AcademicBluePrimary
                        )
                        Text(
                            text = "تسجيل الحضور السريع",
                            style = MaterialTheme.typography.bodySmall,
                            color = AcademicBluePrimary.copy(alpha = 0.8f)
                        )
                    }
                }

                Card(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("card_student_schedule"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    onClick = { showWeeklyScheduleDialog = true }
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = null,
                            tint = AcademicBluePrimary,
                            modifier = Modifier.size(28.dp)
                        )
                        Text(
                            text = "جدول الحصص الأسبوعي",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "مواعيد مجموعتك",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Ask the Teacher Q&A Quick Card
        item {
            Card(
                onClick = { viewModel.setStudentTab(StudentTab.QA_CORNER) },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = StatusWarningContainer.copy(alpha = 0.7f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("card_student_qa_corner")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.85f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Chat,
                                contentDescription = null,
                                tint = StatusWarning,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "ركن اسأل المعلم",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = Color(0xFF92400E)
                            )
                            Text(
                                text = "اطرح سؤالك بصورة أو نص وتابع الإجابات ($visibleQuestionsCount سؤال)",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF92400E).copy(alpha = 0.85f)
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "فتح ركن اسأل المعلم",
                        tint = Color(0xFF92400E)
                    )
                }
            }
        }

        // Mistake Bank Quick Card
        item {
            Card(
                onClick = { viewModel.setStudentTab(StudentTab.MISTAKE_BANK) },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AcademicBlueContainer.copy(alpha = 0.7f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("card_student_mistake_bank")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.85f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Quiz,
                                contentDescription = null,
                                tint = AcademicBluePrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "بنك أخطائي والمراجعة",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = AcademicBluePrimary
                            )
                            Text(
                                text = if (unmasteredMistakesCount > 0) {
                                    "لديك $unmasteredMistakesCount خطأ بانتظار التدريب والإتقان"
                                } else {
                                    "راجع أخطاء الامتحانات وتدرب عليها لتحقيق 100%"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = AcademicBluePrimary.copy(alpha = 0.85f)
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "فتح بنك أخطائي",
                        tint = AcademicBluePrimary
                    )
                }
            }
        }
        // About App Card
        item {
            Card(
                onClick = { showAboutDialog = true },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 48.dp)
                    .testTag("btn_about_app")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(AcademicBlueContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = AcademicBluePrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "حول التطبيق",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "معلومات برنامج حصتي والإصدار الحالي",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "فتح حول التطبيق",
                        tint = AcademicBluePrimary
                    )
                }
            }
        }
    }

    if (showQrPassDialog) {
        com.example.ui.components.StudentQrPassDialog(
            student = student,
            onDismiss = { showQrPassDialog = false }
        )
    }

    if (showWeeklyScheduleDialog) {
        StudentWeeklyScheduleDialog(
            schedules = schedules,
            studentGroupName = student.groupName,
            onDismiss = { showWeeklyScheduleDialog = false }
        )
    }

    if (showAccountSwitcher) {
        com.example.ui.components.AccountSwitcherDialog(
            savedAccounts = savedAccounts,
            currentAccountId = currentAccountId,
            onSwitchAccount = { acc -> viewModel.switchToSavedAccount(acc) },
            onLoginExistingAccount = { isTeacher, id, pass, cb ->
                viewModel.switchWithCredentials(isTeacher, id, pass, cb)
            },
            onRemoveAccount = { accId -> viewModel.removeSavedAccount(accId) },
            onDismiss = { showAccountSwitcher = false }
        )
    }

    if (showAboutDialog) {
        com.example.ui.components.AboutAppDialog(
            onDismiss = { showAboutDialog = false }
        )
    }
}
