package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.Announcement
import com.example.data.AppDatabase
import com.example.data.AttendanceRecord
import com.example.data.ClassSchedule
import com.example.data.EducationalResource
import com.example.data.Exam
import com.example.data.ExamQuestion
import com.example.data.ExamSubmission
import com.example.data.HomeworkRecord
import com.example.data.MistakeRecord
import com.example.data.ParentNote
import com.example.data.PaymentRecord
import com.example.data.QuestionBankItem
import com.example.data.SavedAccount
import com.example.data.SessionManager
import com.example.data.Student
import com.example.data.StudentQuestion
import com.example.data.TeacherRepository
import com.example.data.remote.CloudSyncBridge
import com.example.data.remote.CloudSyncStatus
import com.example.util.AppNotificationManager
import com.example.util.ExamMistakeAnalyzer
import com.example.util.QrCodeHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class UserRole { NONE, TEACHER, STUDENT }

enum class TeacherTab {
    DASHBOARD,
    STUDENTS,
    SESSION_LOG,
    SCHEDULE,
    EXAMS,
    MISTAKE_BANK,
    RESOURCES,
    ANNOUNCEMENTS,
    REPORTS,
    QA_CORNER
}

enum class StudentTab {
    HOME,
    EXAMS,
    MISTAKE_BANK,
    RESOURCES,
    NOTICES,
    REPORT,
    QA_CORNER
}

class TeacherViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val repository = TeacherRepository(database.appDao())
    private val sessionManager = SessionManager(application)
    private val cloudSync = CloudSyncBridge(application, database.appDao())

    val cloudSyncStatus: StateFlow<CloudSyncStatus> = cloudSync.syncStatus

    // --- Auth & Session State ---
    private val _currentUserRole = MutableStateFlow(UserRole.NONE)
    val currentUserRole: StateFlow<UserRole> = _currentUserRole.asStateFlow()

    private val _currentStudent = MutableStateFlow<Student?>(null)
    val currentStudent: StateFlow<Student?> = _currentStudent.asStateFlow()

    private val _loginError = MutableStateFlow<String?>(null)
    val loginError: StateFlow<String?> = _loginError.asStateFlow()

    private val _isLoggingIn = MutableStateFlow(false)
    val isLoggingIn: StateFlow<Boolean> = _isLoggingIn.asStateFlow()

    private val _teacherTab = MutableStateFlow(TeacherTab.DASHBOARD)
    val teacherTab: StateFlow<TeacherTab> = _teacherTab.asStateFlow()

    private val _studentTab = MutableStateFlow(StudentTab.HOME)
    val studentTab: StateFlow<StudentTab> = _studentTab.asStateFlow()

    private val _savedAccounts = MutableStateFlow<List<SavedAccount>>(emptyList())
    val savedAccounts: StateFlow<List<SavedAccount>> = _savedAccounts.asStateFlow()

    private val _currentAccountId = MutableStateFlow<String?>(null)
    val currentAccountId: StateFlow<String?> = _currentAccountId.asStateFlow()

    // --- Active Exam for Taking ---
    private val _activeTakingExam = MutableStateFlow<Exam?>(null)
    val activeTakingExam: StateFlow<Exam?> = _activeTakingExam.asStateFlow()

    private val _isRetakingExam = MutableStateFlow(false)
    val isRetakingExam: StateFlow<Boolean> = _isRetakingExam.asStateFlow()

    // --- Shared Flows ---
    val allStudents: StateFlow<List<Student>> = repository.allStudents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allGroups: StateFlow<List<String>> = repository.allGroups
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allExams: StateFlow<List<Exam>> = repository.allExams
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSubmissions: StateFlow<List<ExamSubmission>> = repository.allSubmissions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allResources: StateFlow<List<EducationalResource>> = repository.allResources
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAnnouncements: StateFlow<List<Announcement>> = repository.allAnnouncements
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPayments: StateFlow<List<PaymentRecord>> = repository.allPayments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allNotes: StateFlow<List<ParentNote>> = repository.allNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAttendances: StateFlow<List<AttendanceRecord>> = repository.allAttendances
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allHomework: StateFlow<List<HomeworkRecord>> = repository.allHomework
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allBankQuestions: StateFlow<List<QuestionBankItem>> = repository.allBankQuestions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSchedules: StateFlow<List<ClassSchedule>> = repository.allSchedules
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allQuestions: StateFlow<List<StudentQuestion>> = repository.allQuestions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allMistakes: StateFlow<List<MistakeRecord>> = repository.allMistakes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Session Recording (Attendance & Homework) ---
    private val defaultDate = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date())
    private val _selectedSessionDate = MutableStateFlow(defaultDate)
    val selectedSessionDate: StateFlow<String> = _selectedSessionDate.asStateFlow()

    private val _selectedGroupFilter = MutableStateFlow<String>("الكل")
    val selectedGroupFilter: StateFlow<String> = _selectedGroupFilter.asStateFlow()

    val currentSessionAttendance: StateFlow<List<AttendanceRecord>> = _selectedSessionDate
        .flatMapLatest { date -> repository.getAttendanceForDate(date) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentSessionHomework: StateFlow<List<HomeworkRecord>> = _selectedSessionDate
        .flatMapLatest { date -> repository.getHomeworkForDate(date) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Student-specific data (when logged in as student) ---
    private val _studentSubmissions = MutableStateFlow<List<ExamSubmission>>(emptyList())
    val studentSubmissions: StateFlow<List<ExamSubmission>> = _studentSubmissions.asStateFlow()

    private val _studentAttendance = MutableStateFlow<List<AttendanceRecord>>(emptyList())
    val studentAttendance: StateFlow<List<AttendanceRecord>> = _studentAttendance.asStateFlow()

    private val _studentHomework = MutableStateFlow<List<HomeworkRecord>>(emptyList())
    val studentHomework: StateFlow<List<HomeworkRecord>> = _studentHomework.asStateFlow()

    private val _studentPayments = MutableStateFlow<List<PaymentRecord>>(emptyList())
    val studentPayments: StateFlow<List<PaymentRecord>> = _studentPayments.asStateFlow()

    private val _studentNotes = MutableStateFlow<List<ParentNote>>(emptyList())
    val studentNotes: StateFlow<List<ParentNote>> = _studentNotes.asStateFlow()

    private val _studentMistakes = MutableStateFlow<List<MistakeRecord>>(emptyList())
    val studentMistakes: StateFlow<List<MistakeRecord>> = _studentMistakes.asStateFlow()

    init {
        // Restore persistent login session from device
        refreshSavedAccounts()
        val savedRole = sessionManager.getSavedRole()
        if (savedRole == SessionManager.ROLE_TEACHER) {
            _currentUserRole.value = UserRole.TEACHER
            _teacherTab.value = TeacherTab.DASHBOARD
            _currentAccountId.value = sessionManager.getCurrentAccountId() ?: SessionManager.TEACHER_ACCOUNT_ID
            if (cloudSync.isAvailable()) {
                cloudSync.startTeacherSync(viewModelScope)
            }
        } else if (savedRole == SessionManager.ROLE_STUDENT) {
            val studentCode = sessionManager.getSavedStudentCode()
            if (studentCode.isNotBlank()) {
                viewModelScope.launch {
                    val student = database.appDao().getStudentByCode(studentCode)
                    if (student != null) {
                        _currentStudent.value = student
                        _currentUserRole.value = UserRole.STUDENT
                        _studentTab.value = StudentTab.HOME
                        _currentAccountId.value = sessionManager.getCurrentAccountId()
                        loadStudentDetails(student.id)
                        if (cloudSync.isAvailable()) {
                            cloudSync.startStudentSync(viewModelScope, student.code)
                        }
                    } else {
                        sessionManager.clearSession()
                    }
                }
            }
        }
        viewModelScope.launch {
            repository.purgeOrphanedRecords()
            database.appDao().clearAllPendingSyncOps()
        }
    }

    fun cloudAccountEmail(): String? = cloudSync.currentUserEmail()

    fun onGoogleSignedIn() {
        if (!cloudSync.isAvailable() || cloudSync.isSyncing()) return
        when (_currentUserRole.value) {
            UserRole.TEACHER -> cloudSync.startTeacherSync(viewModelScope)
            UserRole.STUDENT -> {
                val code = _currentStudent.value?.code ?: return
                cloudSync.startStudentSync(viewModelScope, code)
            }
            UserRole.NONE -> Unit
        }
    }

    fun refreshSavedAccounts() {
        _savedAccounts.value = sessionManager.getSavedAccounts()
        _currentAccountId.value = sessionManager.getCurrentAccountId()
    }

    // --- Authentication & Account Switching Actions ---
    fun loginTeacher(user: String, pass: String): Boolean {
        _loginError.value = null
        if (user.trim() == "admin123" && pass.trim() == "adminusername12345") {
            _currentStudent.value = null
            _currentUserRole.value = UserRole.TEACHER
            _teacherTab.value = TeacherTab.DASHBOARD
            sessionManager.saveTeacherSession()
            refreshSavedAccounts()
            if (cloudSync.isAvailable()) {
                cloudSync.startTeacherSync(viewModelScope)
            }
            return true
        } else {
            _loginError.value = "خطأ في بيانات المعلم! اسم المستخدم أو كلمة المرور غير صحيحة."
            return false
        }
    }

    fun loginStudent(code: String, pass: String) {
        _loginError.value = null
        if (code.isBlank() || pass.isBlank()) {
            _loginError.value = "يرجى كتابة كود الطالب وكلمة المرور الخاصة به"
            return
        }

        viewModelScope.launch {
            _isLoggingIn.value = true
            try {
                var resolvedStudent: Student? = null
                var credentialRejected = false

                if (cloudSync.isAvailable()) {
                    val cloudResult = cloudSync.enrollAndHydrateStudent(code, pass)
                    if (cloudResult.isSuccess) {
                        resolvedStudent = cloudResult.getOrNull()
                    } else if (cloudResult.exceptionOrNull() is IllegalArgumentException) {
                        credentialRejected = true
                    }
                }

                if (resolvedStudent == null && !credentialRejected) {
                    resolvedStudent = repository.verifyStudentLogin(code, pass)
                }

                if (resolvedStudent != null) {
                    _currentStudent.value = resolvedStudent
                    _currentUserRole.value = UserRole.STUDENT
                    _studentTab.value = StudentTab.HOME
                    sessionManager.saveStudentSession(
                        resolvedStudent.id,
                        resolvedStudent.code,
                        resolvedStudent.name,
                        resolvedStudent.groupName
                    )
                    refreshSavedAccounts()
                    loadStudentDetails(resolvedStudent.id)
                    if (cloudSync.isAvailable()) {
                        cloudSync.startStudentSync(viewModelScope, resolvedStudent.code)
                    }
                } else {
                    _loginError.value = "الكود أو كلمة المرور غير صحيحة! يرجى مراجعة الأستاذ."
                }
            } finally {
                _isLoggingIn.value = false
            }
        }
    }

    fun switchToSavedAccount(account: SavedAccount) {
        _loginError.value = null
        _activeTakingExam.value = null
        _isRetakingExam.value = false
        if (account.role == SessionManager.ROLE_TEACHER) {
            _currentStudent.value = null
            _currentUserRole.value = UserRole.TEACHER
            _teacherTab.value = TeacherTab.DASHBOARD
            sessionManager.saveTeacherSession(account.displayName, account.subtitle)
            refreshSavedAccounts()
            if (cloudSync.isAvailable()) {
                cloudSync.startTeacherSync(viewModelScope)
            }
        } else if (account.role == SessionManager.ROLE_STUDENT) {
            viewModelScope.launch {
                val student = database.appDao().getStudentByCode(account.code)
                if (student != null) {
                    _currentStudent.value = student
                    _currentUserRole.value = UserRole.STUDENT
                    _studentTab.value = StudentTab.HOME
                    sessionManager.saveStudentSession(student.id, student.code, student.name, student.groupName)
                    refreshSavedAccounts()
                    loadStudentDetails(student.id)
                    if (cloudSync.isAvailable()) {
                        cloudSync.startStudentSync(viewModelScope, student.code)
                    }
                } else {
                    sessionManager.removeSavedAccount(account.id)
                    refreshSavedAccounts()
                    _loginError.value = "لم يعد حساب هذا الطالب موجوداً."
                }
            }
        }
    }

    fun switchWithCredentials(
        isTeacher: Boolean,
        identifier: String,
        password: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        if (isTeacher) {
            if (identifier.trim() == "admin123" && password.trim() == "adminusername12345") {
                _currentStudent.value = null
                _currentUserRole.value = UserRole.TEACHER
                _teacherTab.value = TeacherTab.DASHBOARD
                _activeTakingExam.value = null
                _isRetakingExam.value = false
                sessionManager.saveTeacherSession()
                refreshSavedAccounts()
                if (cloudSync.isAvailable()) {
                    cloudSync.startTeacherSync(viewModelScope)
                }
                onResult(true, null)
            } else {
                onResult(false, "اسم المستخدم أو كلمة المرور للمعلم غير صحيحة.")
            }
        } else {
            if (identifier.isBlank() || password.isBlank()) {
                onResult(false, "أدخل كود الطالب وكلمة المرور.")
                return
            }
            viewModelScope.launch {
                var student: Student? = null
                var rejected = false
                if (cloudSync.isAvailable()) {
                    val cloudRes = cloudSync.enrollAndHydrateStudent(identifier, password)
                    if (cloudRes.isSuccess) {
                        student = cloudRes.getOrNull()
                    } else if (cloudRes.exceptionOrNull() is IllegalArgumentException) {
                        rejected = true
                    }
                }
                if (student == null && !rejected) {
                    student = repository.verifyStudentLogin(identifier, password)
                }
                if (student != null) {
                    _currentStudent.value = student
                    _currentUserRole.value = UserRole.STUDENT
                    _studentTab.value = StudentTab.HOME
                    _activeTakingExam.value = null
                    _isRetakingExam.value = false
                    sessionManager.saveStudentSession(student.id, student.code, student.name, student.groupName)
                    refreshSavedAccounts()
                    loadStudentDetails(student.id)
                    if (cloudSync.isAvailable()) {
                        cloudSync.startStudentSync(viewModelScope, student.code)
                    }
                    onResult(true, null)
                } else {
                    onResult(false, "كود الطالب أو كلمة المرور غير صحيحة.")
                }
            }
        }
    }

    fun removeSavedAccount(accountId: String) {
        sessionManager.removeSavedAccount(accountId)
        refreshSavedAccounts()
    }

    private fun loadStudentDetails(studentId: Long) {
        viewModelScope.launch {
            repository.getSubmissionsForStudent(studentId).collect {
                _studentSubmissions.value = it
            }
        }
        viewModelScope.launch {
            repository.getAttendanceForStudent(studentId).collect {
                _studentAttendance.value = it
            }
        }
        viewModelScope.launch {
            repository.getHomeworkForStudent(studentId).collect {
                _studentHomework.value = it
            }
        }
        viewModelScope.launch {
            repository.getPaymentsForStudent(studentId).collect {
                _studentPayments.value = it
            }
        }
        viewModelScope.launch {
            repository.getNotesForStudent(studentId).collect {
                _studentNotes.value = it
            }
        }
        viewModelScope.launch {
            repository.getMistakesForStudent(studentId).collect {
                _studentMistakes.value = it
            }
        }
    }

    fun logout() {
        cloudSync.stopAllListeners()
        sessionManager.clearSession()
        _currentUserRole.value = UserRole.NONE
        _currentStudent.value = null
        _currentAccountId.value = null
        _loginError.value = null
        _activeTakingExam.value = null
        _isRetakingExam.value = false
    }

    fun setTeacherTab(tab: TeacherTab) {
        _teacherTab.value = tab
    }

    fun setStudentTab(tab: StudentTab) {
        _studentTab.value = tab
        _activeTakingExam.value = null
        _isRetakingExam.value = false
    }

    fun startTakingExam(exam: Exam, retake: Boolean = false) {
        _isRetakingExam.value = retake
        _activeTakingExam.value = exam
    }

    fun finishTakingExam() {
        _activeTakingExam.value = null
        _isRetakingExam.value = false
    }

    // --- Session Recording ---
    fun setSessionDate(date: String) {
        _selectedSessionDate.value = date
    }

    fun setSelectedGroupFilter(group: String) {
        _selectedGroupFilter.value = group
    }

    fun toggleAttendance(studentId: Long, status: String) {
        viewModelScope.launch {
            val record = AttendanceRecord(
                studentId = studentId,
                date = _selectedSessionDate.value,
                status = status,
                notes = if (status == AttendanceRecord.STATUS_PRESENT) "حاضر في الموعد" else if (status == AttendanceRecord.STATUS_LATE) "متأخر" else "غائب"
            )
            repository.saveAttendanceRecord(record)
            cloudSync.pushAttendance(studentId, record)
        }
    }

    fun toggleHomework(studentId: Long, status: String, score: String = "10/10") {
        viewModelScope.launch {
            val record = HomeworkRecord(
                studentId = studentId,
                date = _selectedSessionDate.value,
                status = status,
                score = score,
                notes = if (status == HomeworkRecord.STATUS_COMPLETED) "تم التسليم" else if (status == HomeworkRecord.STATUS_PARTIAL) "تسليم جزئي" else "لم يسلم"
            )
            repository.saveHomeworkRecord(record)
            cloudSync.pushHomework(studentId, record)
        }
    }

    fun togglePayment(studentId: Long, monthYear: String, isPaid: Boolean, amount: Double = 250.0) {
        viewModelScope.launch {
            val paymentDate = if (isPaid) SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date()) else ""
            val record = PaymentRecord(
                studentId = studentId,
                monthYear = monthYear,
                amount = amount,
                isPaid = isPaid,
                paymentDate = paymentDate,
                notes = if (isPaid) "تم السداد" else "مستحق السداد"
            )
            repository.savePayment(record)
            cloudSync.pushPayment(studentId, record)
        }
    }

    fun markAttendanceByQrCode(
        rawQr: String,
        markHomeworkToo: Boolean = false,
        onResult: (Student?) -> Unit
    ) {
        val code = QrCodeHelper.parseStudentCodeFromQr(rawQr)
        if (code == null) {
            onResult(null)
            return
        }
        viewModelScope.launch {
            val student = allStudents.value.firstOrNull {
                it.code.equals(code, ignoreCase = true)
            } ?: database.appDao().getStudentByCode(code)

            if (student == null) {
                onResult(null)
                return@launch
            }

            val attRecord = AttendanceRecord(
                studentId = student.id,
                date = _selectedSessionDate.value,
                status = AttendanceRecord.STATUS_PRESENT,
                notes = "حضور عبر مسح QR"
            )
            repository.saveAttendanceRecord(attRecord)
            cloudSync.pushAttendance(student.id, attRecord)

            if (markHomeworkToo) {
                val hwRecord = HomeworkRecord(
                    studentId = student.id,
                    date = _selectedSessionDate.value,
                    status = HomeworkRecord.STATUS_COMPLETED,
                    score = "10/10",
                    notes = "تم التسليم (QR)"
                )
                repository.saveHomeworkRecord(hwRecord)
                cloudSync.pushHomework(student.id, hwRecord)
            }

            onResult(student)
        }
    }

    fun markUnmarkedAsAbsent(students: List<Student>) {
        viewModelScope.launch {
            val existingIds = currentSessionAttendance.value.map { it.studentId }.toSet()
            val unmarked = students.filter { it.id !in existingIds }
            if (unmarked.isEmpty()) return@launch

            val date = _selectedSessionDate.value
            val records = unmarked.map { student ->
                AttendanceRecord(
                    studentId = student.id,
                    date = date,
                    status = AttendanceRecord.STATUS_ABSENT,
                    notes = "غائب (متابعة سريعة)"
                )
            }
            repository.saveBatchAttendance(records)
            records.forEach { cloudSync.pushAttendance(it.studentId, it) }
        }
    }

    fun markAllAttendance(students: List<Student>, status: String) {
        if (students.isEmpty()) return
        viewModelScope.launch {
            val date = _selectedSessionDate.value
            val notes = when (status) {
                AttendanceRecord.STATUS_PRESENT -> "حاضر في الموعد"
                AttendanceRecord.STATUS_LATE -> "متأخر"
                else -> "غائب"
            }
            val records = students.map { student ->
                AttendanceRecord(
                    studentId = student.id,
                    date = date,
                    status = status,
                    notes = notes
                )
            }
            repository.saveBatchAttendance(records)
            records.forEach { cloudSync.pushAttendance(it.studentId, it) }
        }
    }

    fun markAllHomework(students: List<Student>, status: String, score: String = "10/10") {
        if (students.isEmpty()) return
        viewModelScope.launch {
            val date = _selectedSessionDate.value
            val notes = when (status) {
                HomeworkRecord.STATUS_COMPLETED -> "تم التسليم"
                HomeworkRecord.STATUS_PARTIAL -> "تسليم جزئي"
                else -> "لم يسلم"
            }
            val records = students.map { student ->
                HomeworkRecord(
                    studentId = student.id,
                    date = date,
                    status = status,
                    score = score,
                    notes = notes
                )
            }
            repository.saveBatchHomework(records)
            records.forEach { cloudSync.pushHomework(it.studentId, it) }
        }
    }

    // --- Weekly Class Schedule Management ---
    fun saveClassSchedule(
        id: Long = 0,
        dayOfWeek: Int,
        groupName: String,
        subject: String,
        startTime: String,
        endTime: String,
        location: String,
        notes: String = ""
    ) {
        viewModelScope.launch {
            val schedule = ClassSchedule(
                id = id,
                dayOfWeek = dayOfWeek.coerceIn(1, 7),
                dayName = ClassSchedule.dayNameFor(dayOfWeek),
                groupName = groupName.trim().ifBlank { "الكل" },
                subject = subject.trim(),
                startTime = startTime.trim(),
                endTime = endTime.trim(),
                location = location.trim(),
                notes = notes.trim()
            )
            val savedId = repository.saveSchedule(schedule)
            cloudSync.pushSchedule(schedule.copy(id = savedId))
        }
    }

    fun deleteClassSchedule(schedule: ClassSchedule) {
        viewModelScope.launch {
            repository.deleteSchedule(schedule)
            cloudSync.removeSchedule(schedule)
        }
    }

    fun sendScheduleReminder(schedule: ClassSchedule) {
        viewModelScope.launch {
            AppNotificationManager.notifyClassReminder(
                context = getApplication(),
                dayName = schedule.dayName,
                groupName = schedule.groupName,
                startTime = schedule.startTime,
                location = schedule.location
            )
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date())
            val ann = Announcement(
                title = "🗓️ تذكير بحصة ${schedule.dayName} (${schedule.groupName})",
                content = "الساعة: ${schedule.startTime}${if (schedule.endTime.isNotBlank()) " - ${schedule.endTime}" else ""}${if (schedule.location.isNotBlank()) "\nالمكان: ${schedule.location}" else ""}",
                groupName = schedule.groupName,
                date = today,
                isUrgent = false
            )
            repository.addAnnouncement(ann)
            cloudSync.pushAnnouncement(ann)
        }
    }

    // --- Student Management ---
    fun saveStudent(
        id: Long = 0,
        name: String,
        code: String,
        password: String,
        groupName: String,
        scheduleTime: String,
        parentPhone: String,
        monthlyFee: Double
    ) {
        viewModelScope.launch {
            val student = Student(
                id = id,
                name = name.trim(),
                code = code.trim().uppercase(Locale.ENGLISH),
                password = password.trim().ifBlank { Student.generateStrongPassword() },
                groupName = groupName.trim(),
                scheduleTime = scheduleTime.trim(),
                parentPhone = parentPhone.trim(),
                monthlyFee = monthlyFee
            )
            val savedId = repository.saveStudent(student)
            cloudSync.pushStudent(student.copy(id = savedId))
        }
    }

    fun deleteStudent(student: Student) {
        viewModelScope.launch {
            repository.deleteStudent(student)
            cloudSync.removeStudent(student.code)
            val savedId = "STUDENT_${student.code.trim().uppercase(Locale.ENGLISH)}"
            sessionManager.removeSavedAccount(savedId)
            if (_currentStudent.value?.id == student.id) {
                _currentStudent.value = null
                if (_currentUserRole.value == UserRole.STUDENT) {
                    _currentUserRole.value = UserRole.NONE
                    sessionManager.clearSession()
                }
            }
            refreshSavedAccounts()
        }
    }

    // --- Online Exam, Question Bank & Mistake Bank Management ---
    fun saveExam(
        id: Long = 0,
        title: String,
        groupName: String,
        durationMinutes: Int,
        totalMarks: Int,
        questions: List<ExamQuestion>,
        shuffleQuestions: Boolean = false,
        showResultImmediately: Boolean = true,
        description: String = "",
        saveToBank: Boolean = true,
        bankSubject: String = "عام",
        deadlineDate: String = "",
        allowRetake: Boolean = false,
        subject: String = "عام",
        passingPercentage: Int = 50,
        shuffleOptions: Boolean = false
    ) {
        viewModelScope.launch {
            val cleanSubject = subject.trim().ifBlank { bankSubject.trim().ifBlank { "عام" } }
            val existingExam = if (id != 0L) repository.getExamById(id) else null
            val exam = Exam(
                id = id,
                title = title.trim(),
                groupName = groupName.trim().ifBlank { "الكل" },
                durationMinutes = durationMinutes.coerceAtLeast(1),
                totalMarks = totalMarks.coerceAtLeast(1),
                questionsJson = Exam.encodeQuestions(questions),
                isActive = existingExam?.isActive ?: true,
                shuffleQuestions = shuffleQuestions,
                showResultImmediately = showResultImmediately,
                description = description.trim(),
                createdAt = existingExam?.createdAt ?: System.currentTimeMillis(),
                deadlineDate = deadlineDate.trim(),
                allowRetake = allowRetake,
                subject = cleanSubject,
                passingPercentage = passingPercentage.coerceIn(1, 100),
                shuffleOptions = shuffleOptions
            )
            val savedExamId = repository.saveExam(exam)
            cloudSync.pushExam(exam.copy(id = savedExamId), savedExamId)

            if (saveToBank && questions.isNotEmpty() && id == 0L) {
                val bankItems = questions.map { q ->
                    QuestionBankItem(
                        subject = q.topic.ifBlank { cleanSubject },
                        questionText = q.questionText,
                        optionsJson = QuestionBankItem.encodeOptions(q.options),
                        correctOptionIndex = q.correctOptionIndex,
                        points = q.points,
                        explanation = q.explanation,
                        imageUri = q.imageUri,
                        questionType = q.questionType,
                        correctTextAnswer = q.correctTextAnswer,
                        difficulty = q.difficulty,
                        topic = q.topic
                    )
                }
                repository.addBankQuestions(bankItems)
            }
        }
    }

    fun createExam(
        title: String,
        groupName: String,
        durationMinutes: Int,
        totalMarks: Int,
        questions: List<ExamQuestion>,
        shuffleQuestions: Boolean = false,
        showResultImmediately: Boolean = true,
        description: String = "",
        saveToBank: Boolean = true,
        bankSubject: String = "عام",
        deadlineDate: String = "",
        allowRetake: Boolean = false,
        subject: String = "عام",
        passingPercentage: Int = 50,
        shuffleOptions: Boolean = false
    ) {
        saveExam(
            id = 0,
            title = title,
            groupName = groupName,
            durationMinutes = durationMinutes,
            totalMarks = totalMarks,
            questions = questions,
            shuffleQuestions = shuffleQuestions,
            showResultImmediately = showResultImmediately,
            description = description,
            saveToBank = saveToBank,
            bankSubject = bankSubject,
            deadlineDate = deadlineDate,
            allowRetake = allowRetake,
            subject = subject,
            passingPercentage = passingPercentage,
            shuffleOptions = shuffleOptions
        )
    }

    fun duplicateExam(exam: Exam, targetGroupName: String = exam.groupName) {
        viewModelScope.launch {
            val copyExam = exam.copy(
                id = 0,
                title = "${exam.title} (نسخة)",
                groupName = targetGroupName.trim().ifBlank { exam.groupName },
                createdAt = System.currentTimeMillis()
            )
            val copiedId = repository.saveExam(copyExam)
            cloudSync.pushExam(copyExam.copy(id = copiedId), copiedId)
        }
    }

    fun toggleExamActive(exam: Exam) {
        viewModelScope.launch {
            val updated = exam.copy(isActive = !exam.isActive)
            repository.saveExam(updated)
            cloudSync.pushExam(updated, updated.id)
        }
    }

    fun addQuestionToBank(
        subject: String,
        questionText: String,
        options: List<String>,
        correctOptionIndex: Int,
        points: Int,
        explanation: String,
        imageUri: String = "",
        questionType: String = ExamQuestion.TYPE_MCQ,
        correctTextAnswer: String = "",
        difficulty: String = ExamQuestion.DIFFICULTY_MEDIUM,
        topic: String = ""
    ) {
        viewModelScope.launch {
            val item = QuestionBankItem(
                subject = subject.trim().ifBlank { "عام" },
                questionText = questionText.trim(),
                optionsJson = QuestionBankItem.encodeOptions(options),
                correctOptionIndex = correctOptionIndex,
                points = points,
                explanation = explanation.trim(),
                imageUri = imageUri,
                questionType = questionType,
                correctTextAnswer = correctTextAnswer.trim(),
                difficulty = difficulty,
                topic = topic.trim()
            )
            repository.addBankQuestion(item)
        }
    }

    fun deleteQuestionFromBank(item: QuestionBankItem) {
        viewModelScope.launch {
            repository.deleteBankQuestion(item)
        }
    }

    fun deleteExam(exam: Exam) {
        viewModelScope.launch {
            repository.deleteExam(exam)
            cloudSync.removeExam(exam)
        }
    }

    fun submitStudentExam(examId: Long, studentId: Long, score: Int, maxScore: Int, answersJson: String) {
        viewModelScope.launch {
            val sub = ExamSubmission(
                examId = examId,
                studentId = studentId,
                score = score,
                maxScore = maxScore,
                answersJson = answersJson
            )
            repository.submitExam(sub)
            val isTeacher = (_currentUserRole.value == UserRole.TEACHER)
            cloudSync.pushSubmission(sub, isTeacher)
            val student = database.appDao().getStudentByIdSync(studentId)
                ?: allStudents.value.firstOrNull { it.id == studentId }
            val studentCode = student?.code ?: "STU$studentId"
            _activeTakingExam.value = null
            _isRetakingExam.value = false
            loadStudentDetails(studentId)

            val exam = repository.getExamById(examId)
                ?: allExams.value.firstOrNull { it.id == examId }
            if (exam != null) {
                val today = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date())
                val mistakes = ExamMistakeAnalyzer.extractMistakesFromSubmission(
                    exam = exam,
                    studentId = studentId,
                    studentCode = studentCode,
                    studentName = student?.name ?: "طالب",
                    answersJson = answersJson,
                    date = today
                )
                for (mistake in mistakes) {
                    val savedMistake = repository.recordOrIncrementMistake(mistake)
                    cloudSync.pushMistake(savedMistake, isTeacher)
                }
            }

            val examTitle = exam?.title ?: "الاختبار"
            val studentName = student?.name ?: "طالب"
            AppNotificationManager.notifyExamGrade(
                context = getApplication(),
                examTitle = examTitle,
                studentName = studentName,
                score = score,
                maxScore = maxScore,
                notes = "تم تصحيح إجاباتك بنجاح."
            )
        }
    }

    // --- Mistake Bank (بنك الأخطاء) Actions ---
    fun addManualMistake(
        studentId: Long,
        subject: String,
        questionText: String,
        questionType: String = ExamQuestion.TYPE_MCQ,
        options: List<String> = emptyList(),
        correctOptionIndex: Int = 0,
        correctTextAnswer: String = "",
        studentAnswer: String = "",
        explanation: String = "",
        difficulty: String = ExamQuestion.DIFFICULTY_MEDIUM,
        personalNote: String = ""
    ) {
        if (questionText.isBlank()) return
        viewModelScope.launch {
            val student = database.appDao().getStudentByIdSync(studentId)
                ?: allStudents.value.firstOrNull { it.id == studentId }
                ?: return@launch
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date())
            val resolvedOpts = when (questionType) {
                ExamQuestion.TYPE_TRUE_FALSE -> listOf("صح", "خطأ")
                ExamQuestion.TYPE_SHORT_ANSWER -> emptyList()
                else -> options.ifEmpty { listOf("أ", "ب", "ج", "د") }
            }
            val safeIdx = if (resolvedOpts.isNotEmpty()) correctOptionIndex.coerceIn(0, resolvedOpts.lastIndex) else 0
            val correctText = if (questionType == ExamQuestion.TYPE_SHORT_ANSWER) {
                correctTextAnswer.trim()
            } else {
                resolvedOpts.getOrElse(safeIdx) { "" }
            }
            val record = MistakeRecord(
                studentId = student.id,
                studentCode = student.code,
                studentName = student.name,
                examId = 0L,
                examTitle = "مراجعة يدوية",
                subject = subject.trim().ifBlank { "عام" },
                questionId = 0,
                questionText = questionText.trim(),
                questionType = questionType,
                optionsJson = QuestionBankItem.encodeOptions(resolvedOpts),
                studentAnswer = studentAnswer.trim().ifBlank { "إضافة للمراجعة" },
                correctAnswer = correctText,
                correctOptionIndex = safeIdx,
                explanation = explanation.trim(),
                difficulty = difficulty,
                personalNote = personalNote.trim(),
                lastMistakeDate = today
            )
            val saved = repository.recordOrIncrementMistake(record)
            cloudSync.pushMistake(saved, _currentUserRole.value == UserRole.TEACHER)
        }
    }

    fun updateMistakeNote(mistake: MistakeRecord, personalNote: String, explanation: String = mistake.explanation) {
        viewModelScope.launch {
            val updated = mistake.copy(
                personalNote = personalNote.trim(),
                explanation = explanation.trim(),
                updatedAt = System.currentTimeMillis()
            )
            repository.updateMistake(updated)
            cloudSync.pushMistake(updated, _currentUserRole.value == UserRole.TEACHER)
        }
    }

    fun toggleMistakeMastered(mistake: MistakeRecord) {
        viewModelScope.launch {
            val updated = mistake.copy(
                isMastered = !mistake.isMastered,
                updatedAt = System.currentTimeMillis()
            )
            repository.updateMistake(updated)
            cloudSync.pushMistake(updated, _currentUserRole.value == UserRole.TEACHER)
        }
    }

    fun recordMistakePracticeAttempt(mistake: MistakeRecord, isCorrect: Boolean) {
        viewModelScope.launch {
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date())
            val updated = mistake.copy(
                practiceAttempts = mistake.practiceAttempts + 1,
                isMastered = if (isCorrect) true else false,
                mistakeCount = if (isCorrect) mistake.mistakeCount else mistake.mistakeCount + 1,
                lastMistakeDate = if (isCorrect) mistake.lastMistakeDate else today,
                updatedAt = System.currentTimeMillis()
            )
            repository.updateMistake(updated)
            cloudSync.pushMistake(updated, _currentUserRole.value == UserRole.TEACHER)
        }
    }

    fun deleteMistake(mistake: MistakeRecord) {
        viewModelScope.launch {
            repository.deleteMistake(mistake)
            cloudSync.removeMistake(mistake)
        }
    }

    fun createRemedialExamFromMistakes(
        title: String,
        groupName: String,
        durationMinutes: Int,
        mistakes: List<MistakeRecord>,
        subject: String = "مراجعة الأخطاء"
    ) {
        val uniqueMistakes = mistakes.distinctBy { it.questionText.trim() }.take(30)
        if (uniqueMistakes.isEmpty()) return
        val questions = uniqueMistakes.mapIndexed { idx, m ->
            m.toExamQuestion(idx + 1)
        }
        val totalMarks = questions.sumOf { it.points }.coerceAtLeast(1)
        saveExam(
            id = 0L,
            title = title.trim().ifBlank { "امتحان علاجي - مراجعة الأخطاء" },
            groupName = groupName.trim().ifBlank { "الكل" },
            durationMinutes = durationMinutes.coerceAtLeast(5),
            totalMarks = totalMarks,
            questions = questions,
            shuffleQuestions = true,
            showResultImmediately = true,
            description = "امتحان تدريبي تلقائي لعلاج أبرز الأخطاء المتكررة",
            saveToBank = false,
            subject = subject,
            passingPercentage = 60,
            shuffleOptions = true
        )
    }

    fun assignStudentExamGrade(examId: Long, studentId: Long, score: Int, maxScore: Int, notes: String = "") {
        viewModelScope.launch {
            val sub = ExamSubmission(
                examId = examId,
                studentId = studentId,
                score = score,
                maxScore = maxScore,
                answersJson = """{"manualGraded":true,"teacherNote":"$notes"}"""
            )
            repository.submitExam(sub)
            cloudSync.pushSubmission(sub, true)
            val student = allStudents.value.firstOrNull { it.id == studentId }

            val exam = allExams.value.firstOrNull { it.id == examId }
            val examTitle = exam?.title ?: "الامتحان"
            val studentName = student?.name ?: "طالب"
            AppNotificationManager.notifyExamGrade(
                context = getApplication(),
                examTitle = examTitle,
                studentName = studentName,
                score = score,
                maxScore = maxScore,
                notes = notes
            )

            val today = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date())
            val ann = Announcement(
                title = "🎯 تم رصد درجة امتحان: $examTitle",
                content = "رصد المستر درجة $score/$maxScore للطالب $studentName.${if (notes.isNotBlank()) " ملاحظة: $notes" else ""}",
                groupName = student?.groupName ?: "الكل",
                date = today,
                isUrgent = false
            )
            repository.addAnnouncement(ann)
            cloudSync.pushAnnouncement(ann)
        }
    }

    fun sendHomeworkNotification(groupName: String, date: String, details: String) {
        viewModelScope.launch {
            AppNotificationManager.notifyNewHomework(
                context = getApplication(),
                groupName = groupName,
                date = date,
                homeworkDetails = details
            )

            val ann = Announcement(
                title = "📝 واجب جديد لمجموعة $groupName",
                content = "تاريخ الحصة: $date\nالمطلوب: $details",
                groupName = groupName,
                date = date,
                isUrgent = false
            )
            repository.addAnnouncement(ann)
            cloudSync.pushAnnouncement(ann)
        }
    }

    // --- Parent Notes (Written + Optional Voice Note) ---
    fun addParentNote(
        studentId: Long,
        title: String,
        content: String,
        audioFilePath: String = "",
        audioDurationSeconds: Int = 0
    ) {
        viewModelScope.launch {
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date())
            val note = ParentNote(
                studentId = studentId,
                title = title.trim().ifBlank { if (audioFilePath.isNotBlank()) "ملاحظة صوتية لولي الأمر" else "ملاحظة أسبوعية لولي الأمر" },
                content = content.trim(),
                date = today,
                audioFilePath = audioFilePath.trim(),
                audioDurationSeconds = audioDurationSeconds
            )
            repository.addParentNote(note)
            cloudSync.pushParentNote(studentId, note)
        }
    }

    fun deleteParentNote(note: ParentNote) {
        viewModelScope.launch {
            repository.deleteParentNote(note)
        }
    }

    // --- Ask the Teacher (ركن اسأل المعلم) ---
    fun askTeacherQuestion(
        student: Student,
        subject: String,
        questionText: String,
        imagePath: String = "",
        isPublicToGroup: Boolean = true
    ) {
        if (questionText.isBlank() && imagePath.isBlank()) return
        viewModelScope.launch {
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date())
            val q = StudentQuestion(
                studentId = student.id,
                studentName = student.name,
                studentCode = student.code,
                groupName = student.groupName,
                subject = subject.trim().ifBlank { "عام" },
                questionText = questionText.trim().ifBlank { "سؤال مرفق بصورة" },
                questionImagePath = imagePath.trim(),
                isPublicToGroup = isPublicToGroup,
                createdDate = today
            )
            val insertedQId = repository.insertQuestion(q)
            cloudSync.pushQuestion(q.copy(id = insertedQId), _currentUserRole.value == UserRole.TEACHER)
            AppNotificationManager.notifyNewStudentQuestion(
                context = getApplication(),
                studentName = student.name,
                groupName = student.groupName,
                questionPreview = q.questionText
            )
        }
    }

    fun answerStudentQuestion(
        question: StudentQuestion,
        answerText: String,
        answerAudioPath: String = "",
        answerAudioDuration: Int = 0
    ) {
        if (answerText.isBlank() && answerAudioPath.isBlank()) return
        viewModelScope.launch {
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date())
            val updated = question.copy(
                answerText = answerText.trim(),
                answerAudioPath = answerAudioPath.trim(),
                answerAudioDuration = answerAudioDuration,
                isAnswered = true,
                answeredDate = today
            )
            repository.updateQuestion(updated)
            cloudSync.pushQuestion(updated, true)
            AppNotificationManager.notifyQuestionAnswered(
                context = getApplication(),
                studentName = question.studentName,
                subject = question.subject,
                hasVoiceAnswer = answerAudioPath.isNotBlank()
            )
        }
    }

    fun togglePinQuestion(question: StudentQuestion) {
        viewModelScope.launch {
            val updated = question.copy(isPinned = !question.isPinned)
            repository.updateQuestion(updated)
            cloudSync.pushQuestion(updated, true)
        }
    }

    fun deleteStudentQuestion(question: StudentQuestion) {
        viewModelScope.launch {
            repository.deleteQuestion(question)
            cloudSync.removeQuestion(question)
        }
    }

    // --- Educational Resources ---
    fun addEducationalResource(
        title: String,
        subject: String,
        groupName: String,
        description: String,
        fileType: String,
        content: String,
        localFilePath: String = "",
        externalUrl: String = ""
    ) {
        viewModelScope.launch {
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date())
            val res = EducationalResource(
                title = title.trim(),
                subject = subject.trim(),
                groupName = groupName.trim().ifBlank { "الكل" },
                description = description.trim(),
                fileType = fileType.trim(),
                resourceContent = content.trim(),
                localFilePath = localFilePath.trim(),
                externalUrl = externalUrl.trim(),
                addedDate = today
            )
            val savedId = repository.addResource(res)
            cloudSync.pushResource(res.copy(id = savedId))
        }
    }

    fun deleteResource(resource: EducationalResource) {
        viewModelScope.launch {
            repository.deleteResource(resource)
            cloudSync.removeResource(resource)
        }
    }

    // --- Announcements & Alerts ---
    fun postAnnouncement(title: String, content: String, groupName: String, isUrgent: Boolean) {
        viewModelScope.launch {
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date())
            val ann = Announcement(
                title = title.trim(),
                content = content.trim(),
                groupName = groupName.trim(),
                date = today,
                isUrgent = isUrgent
            )
            repository.addAnnouncement(ann)
            cloudSync.pushAnnouncement(ann)
        }
    }

    fun deleteAnnouncement(announcement: Announcement) {
        viewModelScope.launch {
            repository.deleteAnnouncement(announcement)
            cloudSync.removeAnnouncement(announcement)
        }
    }
}
