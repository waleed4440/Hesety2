package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SwitchAccount
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AttendanceRecord
import com.example.data.HomeworkRecord
import com.example.data.remote.CloudSyncStatus
import com.example.ui.TeacherTab
import com.example.ui.TeacherViewModel
import com.example.ui.components.QuickParentContactDialog
import com.example.ui.components.QuickParentPickerDialog
import com.example.ui.components.StatMetricCard
import com.example.ui.theme.AcademicBlueContainer
import com.example.ui.theme.AcademicBluePrimary
import com.example.ui.theme.AcademicBlueSecondary
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusDangerContainer
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessContainer
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningContainer
import com.example.util.ParentCommunicationHelper
import com.example.util.ParentMessageTemplate
import com.example.util.StudentGuardianSnapshot

@Composable
fun TeacherDashboardScreen(
    viewModel: TeacherViewModel,
    onNavigateToTab: (TeacherTab) -> Unit,
    onAddNewStudent: () -> Unit,
    onCreateExam: () -> Unit,
    modifier: Modifier = Modifier
) {
    val students by viewModel.allStudents.collectAsState()
    val todayAttendance by viewModel.currentSessionAttendance.collectAsState()
    val todayHomework by viewModel.currentSessionHomework.collectAsState()
    val allAttendances by viewModel.allAttendances.collectAsState()
    val allHomework by viewModel.allHomework.collectAsState()
    val allPayments by viewModel.allPayments.collectAsState()
    val allSubmissions by viewModel.allSubmissions.collectAsState()
    val allNotes by viewModel.allNotes.collectAsState()
    val sessionDate by viewModel.selectedSessionDate.collectAsState()
    val announcements by viewModel.allAnnouncements.collectAsState()
    val exams by viewModel.allExams.collectAsState()
    val schedules by viewModel.allSchedules.collectAsState()
    val allQuestions by viewModel.allQuestions.collectAsState()
    val allMistakes by viewModel.allMistakes.collectAsState()
    val savedAccounts by viewModel.savedAccounts.collectAsState()
    val currentAccountId by viewModel.currentAccountId.collectAsState()
    val cloudSyncStatus by viewModel.cloudSyncStatus.collectAsState()
    var showAccountSwitcher by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }
    var showParentPicker by remember { mutableStateOf(false) }
    var quickContactState by remember { mutableStateOf<Pair<StudentGuardianSnapshot, ParentMessageTemplate>?>(null) }

    val activeStudentIds = remember(students) { students.map { it.id }.toSet() }
    val unansweredQuestionsCount = allQuestions.count { !it.isAnswered && it.studentId in activeStudentIds }
    val unmasteredMistakesCount = allMistakes.count { !it.isMastered && it.studentId in activeStudentIds }
    val registeredPhonesCount = remember(students) {
        students.count { ParentCommunicationHelper.normalizeDialPhone(it.parentPhone) != null }
    }

    val totalStudentsCount = students.size
    val presentTodayCount = todayAttendance.count {
        it.studentId in activeStudentIds && it.status == AttendanceRecord.STATUS_PRESENT
    }
    val completedHomeworkCount = todayHomework.count {
        it.studentId in activeStudentIds && it.status == HomeworkRecord.STATUS_COMPLETED
    }
    val paidCount = students.count { st ->
        allPayments.firstOrNull { it.studentId == st.id }?.isPaid == true
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Teacher Hero Welcome Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = AcademicBluePrimary),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                listOf(AcademicBluePrimary, AcademicBlueSecondary)
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "لوحة تحكم الأستاذ (المعلم)",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 20.sp
                                    ),
                                    color = Color.White
                                )
                                Text(
                                    text = "إدارة الطلاب، الحضور والغياب، الواجبات والامتحانات",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AcademicBlueContainer
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color.White.copy(alpha = 0.16f)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        Icon(
                                            imageVector = when (cloudSyncStatus) {
                                                CloudSyncStatus.SYNCED -> Icons.Default.CloudDone
                                                CloudSyncStatus.CONNECTING -> Icons.Default.CloudSync
                                                CloudSyncStatus.OFFLINE_LOCAL -> Icons.Default.CloudOff
                                            },
                                            contentDescription = "حالة الاتصال بالسيرفر",
                                            tint = Color.White,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(5.dp))
                                        Text(
                                            text = when (cloudSyncStatus) {
                                                CloudSyncStatus.SYNCED -> "السيرفر متصل • حفظ تلقائي"
                                                CloudSyncStatus.CONNECTING -> "جاري الاتصال بالسيرفر..."
                                                CloudSyncStatus.OFFLINE_LOCAL -> "وضع محلي"
                                            },
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White
                                        )
                                    }
                                }
                            }

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    onClick = { showAccountSwitcher = true },
                                    shape = RoundedCornerShape(20.dp),
                                    color = Color.White.copy(alpha = 0.2f),
                                    modifier = Modifier
                                        .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                                        .testTag("btn_teacher_accounts")
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.SwitchAccount,
                                            contentDescription = "تبديل الحساب",
                                            tint = Color.White,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "${savedAccounts.size}",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }
                                }

                                IconButton(
                                    onClick = { showAboutDialog = true },
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.2f))
                                        .testTag("btn_about_app_top")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Info,
                                        contentDescription = "حول التطبيق",
                                        tint = Color.White
                                    )
                                }

                                IconButton(
                                    onClick = { viewModel.logout() },
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.2f))
                                        .testTag("btn_teacher_logout")
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.Logout,
                                        contentDescription = "تسجيل خروج",
                                        tint = Color.White
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Fast Session Launch button
                        Button(
                            onClick = { onNavigateToTab(TeacherTab.SESSION_LOG) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White,
                                contentColor = AcademicBluePrimary
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("btn_quick_session_log")
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StatusSuccess)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "تسجيل حضور وواجبات حصة اليوم",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Summary Metric Tiles Grid
        item {
            Text(
                text = "الإحصائيات ونظرة عامة سريعة",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatMetricCard(
                    title = "إجمالي الطلاب",
                    value = "$totalStudentsCount طالب",
                    icon = Icons.Default.Group,
                    tintColor = AcademicBluePrimary,
                    containerColor = AcademicBlueContainer,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateToTab(TeacherTab.STUDENTS) }
                )
                StatMetricCard(
                    title = "حضور اليوم",
                    value = "$presentTodayCount حاضر",
                    icon = Icons.Default.CheckCircle,
                    tintColor = StatusSuccess,
                    containerColor = StatusSuccessContainer,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateToTab(TeacherTab.SESSION_LOG) }
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatMetricCard(
                    title = "حلوا الواجب",
                    value = "$completedHomeworkCount طالب",
                    icon = Icons.AutoMirrored.Filled.Assignment,
                    tintColor = StatusWarning,
                    containerColor = StatusWarningContainer,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateToTab(TeacherTab.SESSION_LOG) }
                )
                StatMetricCard(
                    title = "سددوا المصروفات",
                    value = "$paidCount مسدد",
                    icon = Icons.Default.CreditCard,
                    tintColor = StatusSuccess,
                    containerColor = StatusSuccessContainer,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateToTab(TeacherTab.REPORTS) }
                )
            }
        }

        // Quick Operations Bar
        item {
            Text(
                text = "إجراءات المعلم السريعة",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onAddNewStudent,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_action_add_student"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("إضافة طالب", fontSize = 11.sp, maxLines = 1)
                }

                OutlinedButton(
                    onClick = onCreateExam,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_action_create_exam"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Quiz, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("إضافة امتحان", fontSize = 11.sp, maxLines = 1)
                }

                OutlinedButton(
                    onClick = { onNavigateToTab(TeacherTab.ANNOUNCEMENTS) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_action_add_announcement"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Campaign, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("نشر تنبيه", fontSize = 11.sp, maxLines = 1)
                }
            }
        }

        // Weekly Schedule & QR Quick Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    onClick = { onNavigateToTab(TeacherTab.SCHEDULE) },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = AcademicBlueContainer),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_action_schedule")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = null,
                            tint = AcademicBluePrimary,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "جدول الحصص الأسبوعي",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = AcademicBluePrimary
                            )
                            Text(
                                text = "${schedules.size} حصص مجدولة",
                                style = MaterialTheme.typography.bodySmall,
                                color = AcademicBluePrimary.copy(alpha = 0.8f)
                            )
                        }
                    }
                }

                Card(
                    onClick = { onNavigateToTab(TeacherTab.SESSION_LOG) },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = StatusSuccessContainer),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_action_qr_attendance")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = null,
                            tint = StatusSuccess,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "حضور QR والغياب",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = StatusSuccess
                            )
                            Text(
                                text = "مسح سريع + متابعة",
                                style = MaterialTheme.typography.bodySmall,
                                color = StatusSuccess.copy(alpha = 0.8f)
                            )
                        }
                    }
                }
            }
        }

        // Ask the Teacher Q&A Corner Quick Card
        item {
            Card(
                onClick = { onNavigateToTab(TeacherTab.QA_CORNER) },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (unansweredQuestionsCount > 0) StatusWarningContainer else AcademicBlueContainer.copy(alpha = 0.7f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("btn_action_qa_corner")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.85f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Chat,
                                contentDescription = null,
                                tint = if (unansweredQuestionsCount > 0) StatusWarning else AcademicBluePrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "ركن اسأل المعلم",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = if (unansweredQuestionsCount > 0) Color(0xFF92400E) else AcademicBluePrimary
                            )
                            Text(
                                text = if (unansweredQuestionsCount > 0) {
                                    "يوجد $unansweredQuestionsCount سؤال بانتظار ردك (نصي أو صوتي)"
                                } else {
                                    "متابعة أسئلة الطلاب والإجابات المثبتة (${allQuestions.size})"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = if (unansweredQuestionsCount > 0) Color(0xFF92400E) else AcademicBluePrimary.copy(alpha = 0.85f)
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "فتح ركن اسأل المعلم",
                        tint = if (unansweredQuestionsCount > 0) StatusWarning else AcademicBluePrimary
                    )
                }
            }
        }

        // Mistake Bank Quick Card
        item {
            Card(
                onClick = { onNavigateToTab(TeacherTab.MISTAKE_BANK) },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (unmasteredMistakesCount > 0) StatusDangerContainer.copy(alpha = 0.6f) else AcademicBlueContainer.copy(alpha = 0.55f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("btn_action_mistake_bank")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.85f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Quiz,
                                contentDescription = null,
                                tint = if (unmasteredMistakesCount > 0) StatusDanger else AcademicBluePrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "بنك الأخطاء والامتحانات العلاجية",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = if (unmasteredMistakesCount > 0) StatusDanger else AcademicBluePrimary
                            )
                            Text(
                                text = if (unmasteredMistakesCount > 0) {
                                    "يوجد $unmasteredMistakesCount خطأ متكرر غير متقن — اضغط للتحليل والعلاج"
                                } else {
                                    "تتبع الأخطاء الشائعة وإنشاء امتحانات علاجية بضغطة واحدة"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = if (unmasteredMistakesCount > 0) StatusDanger.copy(alpha = 0.9f) else AcademicBluePrimary.copy(alpha = 0.85f)
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "فتح بنك الأخطاء",
                        tint = if (unmasteredMistakesCount > 0) StatusDanger else AcademicBluePrimary
                    )
                }
            }
        }

        // Quick Parent Communication Hub Card
        item {
            Card(
                onClick = { showParentPicker = true },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = StatusSuccessContainer.copy(alpha = 0.75f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("btn_action_quick_parent_contact")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.9f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhoneInTalk,
                                contentDescription = null,
                                tint = StatusSuccess,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "التواصل السريع مع أولياء الأمور",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = StatusSuccess
                            )
                            Text(
                                text = "$registeredPhonesCount رقم مسجل • اتصال وواتساب وSMS بقوالب جاهزة",
                                style = MaterialTheme.typography.bodySmall,
                                color = StatusSuccess.copy(alpha = 0.9f)
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "فتح التواصل السريع مع أولياء الأمور",
                        tint = StatusSuccess
                    )
                }
            }
        }

        // Groups Summary
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "مجموعات الدروس والحصص",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "عرض الكل",
                            color = AcademicBluePrimary,
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            modifier = Modifier.clickable { onNavigateToTab(TeacherTab.STUDENTS) }
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    val groups = students.map { it.groupName }.distinct()
                    groups.forEach { groupName ->
                        val groupStudents = students.filter { it.groupName == groupName }
                        val schedule = groupStudents.firstOrNull()?.scheduleTime ?: ""

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = groupName,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "الموعد: $schedule",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = AcademicBlueContainer
                                ) {
                                    Text(
                                        text = "${groupStudents.size} طلاب",
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = AcademicBluePrimary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // About App Card
        item {
            Card(
                onClick = { showAboutDialog = true },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 48.dp)
                    .testTag("btn_about_app")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(AcademicBlueContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = AcademicBluePrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "حول التطبيق",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "معلومات برنامج حصتي والإصدار الحالي",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "فتح حول التطبيق",
                        tint = AcademicBluePrimary
                    )
                }
            }
        }
    }

    if (showAccountSwitcher) {
        com.example.ui.components.AccountSwitcherDialog(
            savedAccounts = savedAccounts,
            currentAccountId = currentAccountId,
            onSwitchAccount = { acc -> viewModel.switchToSavedAccount(acc) },
            onLoginExistingAccount = { isTeacher, id, pass, cb ->
                viewModel.switchWithCredentials(isTeacher, id, pass, cb)
            },
            onRemoveAccount = { accId -> viewModel.removeSavedAccount(accId) },
            onDismiss = { showAccountSwitcher = false }
        )
    }

    if (showAboutDialog) {
        com.example.ui.components.AboutAppDialog(
            onDismiss = { showAboutDialog = false }
        )
    }

    if (showParentPicker) {
        QuickParentPickerDialog(
            students = students,
            allAttendances = allAttendances,
            allHomework = allHomework,
            allPayments = allPayments,
            allSubmissions = allSubmissions,
            allExams = exams,
            allNotes = allNotes,
            sessionDate = sessionDate,
            onSelectStudent = { snapshot, template ->
                showParentPicker = false
                quickContactState = snapshot to template
            },
            onDismiss = { showParentPicker = false }
        )
    }

    if (quickContactState != null) {
        QuickParentContactDialog(
            snapshot = quickContactState!!.first,
            initialTemplate = quickContactState!!.second,
            onDismiss = { quickContactState = null }
        )
    }
}
