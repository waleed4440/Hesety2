package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.SwitchAccount
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SavedAccount
import com.example.data.SessionManager
import com.example.ui.theme.AcademicBlueContainer
import com.example.ui.theme.AcademicBluePrimary
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessContainer

@Composable
fun AccountSwitcherDialog(
    savedAccounts: List<SavedAccount>,
    currentAccountId: String?,
    onSwitchAccount: (SavedAccount) -> Unit,
    onLoginExistingAccount: (isTeacher: Boolean, identifier: String, password: String, onResult: (Boolean, String?) -> Unit) -> Unit,
    onRemoveAccount: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var showSwitchLoginForm by remember { mutableStateOf(false) }
    var isTeacherLogin by remember { mutableStateOf(false) }
    var identifier by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var formError by remember { mutableStateOf<String?>(null) }

    SafeAlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.SwitchAccount, contentDescription = null, tint = AcademicBluePrimary)
                Column {
                    Text(
                        text = "تبديل الحساب",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "التبديل السريع بين الحسابات المسجلة على هذا الجهاز",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        text = {
            val dismissInput = rememberActiveInputDismisser()
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (!showSwitchLoginForm) {
                    if (savedAccounts.isEmpty()) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "لا توجد حسابات محفوظة بعد. سجل الدخول بحساب معلم أو طالب ليتم حفظه هنا للتبديل السريع.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(14.dp)
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 250.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(savedAccounts, key = { it.id }) { account ->
                                val isCurrent = account.id == currentAccountId
                                val isTeacher = account.role == SessionManager.ROLE_TEACHER

                                Card(
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isCurrent) AcademicBlueContainer.copy(alpha = 0.55f)
                                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable(enabled = !isCurrent) {
                                            onSwitchAccount(account)
                                            onDismiss()
                                        }
                                        .testTag("switch_account_${account.id}")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(40.dp)
                                                    .clip(CircleShape)
                                                    .background(if (isTeacher) AcademicBluePrimary else StatusSuccessContainer),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = if (isTeacher) Icons.Default.Person else Icons.Default.School,
                                                    contentDescription = null,
                                                    tint = if (isTeacher) MaterialTheme.colorScheme.onPrimary else StatusSuccess,
                                                    modifier = Modifier.size(22.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column {
                                                Text(
                                                    text = account.displayName,
                                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                                Text(
                                                    text = if (isTeacher) "معلم • ${account.code}" else "طالب • ${account.code} • ${account.subtitle}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }

                                        if (isCurrent) {
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = StatusSuccessContainer
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                ) {
                                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StatusSuccess, modifier = Modifier.size(14.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("الحالي", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = StatusSuccess)
                                                }
                                            }
                                        } else {
                                            IconButton(
                                                onClick = { onRemoveAccount(account.id) },
                                                modifier = Modifier.testTag("btn_remove_saved_${account.id}")
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.DeleteOutline,
                                                    contentDescription = "إزالة من القائمة",
                                                    tint = StatusDanger
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    HorizontalDivider()

                    OutlinedButton(
                        onClick = {
                            formError = null
                            showSwitchLoginForm = true
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_switch_to_other_login")
                    ) {
                        Icon(Icons.Default.Login, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("التبديل إلى حساب آخر مسجل", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Text("اختر نوع الحساب:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = !isTeacherLogin,
                            onClick = {
                                dismissInput()
                                isTeacherLogin = false
                                formError = null
                            },
                            label = { Text("حساب طالب") },
                            modifier = Modifier.testTag("chip_switch_student")
                        )
                        FilterChip(
                            selected = isTeacherLogin,
                            onClick = {
                                dismissInput()
                                isTeacherLogin = true
                                formError = null
                            },
                            label = { Text("حساب معلم") },
                            modifier = Modifier.testTag("chip_switch_teacher")
                        )
                    }

                    OutlinedTextField(
                        value = identifier,
                        onValueChange = { identifier = it },
                        label = { Text(if (isTeacherLogin) "اسم مستخدم المعلم" else "كود الطالب") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_switch_identifier")
                    )

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("كلمة المرور") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_switch_password")
                    )

                    if (!formError.isNullOrBlank()) {
                        Text(
                            text = formError!!,
                            color = StatusDanger,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                dismissInput()
                                showSwitchLoginForm = false
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("رجوع")
                        }
                        Button(
                            onClick = {
                                dismissInput()
                                onLoginExistingAccount(isTeacherLogin, identifier, password) { ok, err ->
                                    if (ok) {
                                        showSwitchLoginForm = false
                                        onDismiss()
                                    } else {
                                        formError = err ?: "بيانات الدخول غير صحيحة"
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_confirm_switch_login")
                        ) {
                            Text("دخول وتبديل")
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (!showSwitchLoginForm) {
                val dismissInput = rememberActiveInputDismisser()
                Button(
                    onClick = {
                        dismissInput()
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary)
                ) {
                    Text("إغلاق")
                }
            }
        }
    )
}
