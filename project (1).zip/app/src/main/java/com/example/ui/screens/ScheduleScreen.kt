package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ClassSchedule
import com.example.ui.TeacherTab
import com.example.ui.TeacherViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.EmptyStateView
import com.example.ui.components.SafeAlertDialog
import com.example.ui.components.rememberActiveInputDismisser
import com.example.ui.theme.AcademicBlueContainer
import com.example.ui.theme.AcademicBluePrimary
import com.example.ui.theme.StatusDanger

@Composable
fun TeacherScheduleScreen(
    viewModel: TeacherViewModel,
    modifier: Modifier = Modifier
) {
    val schedules by viewModel.allSchedules.collectAsState()
    val groups by viewModel.allGroups.collectAsState()
    val context = LocalContext.current

    var selectedDayFilter by remember { mutableIntStateOf(0) } // 0 = All days
    var showFormDialog by remember { mutableStateOf(false) }
    var editingSchedule by remember { mutableStateOf<ClassSchedule?>(null) }

    val visibleSchedules = remember(schedules, selectedDayFilter) {
        if (selectedDayFilter == 0) schedules else schedules.filter { it.dayOfWeek == selectedDayFilter }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingSchedule = null
                    showFormDialog = true
                },
                containerColor = AcademicBluePrimary,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("fab_add_schedule")
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة موعد حصة")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AppHeader(
                title = "جدول الحصص الأسبوعي (${schedules.size})",
                subtitle = "تنظيم مواعيد المجموعات وإرسال تذكير تلقائي قبل الحصة",
                onBack = { viewModel.setTeacherTab(TeacherTab.DASHBOARD) }
            )

            // Day Filter Row
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = selectedDayFilter == 0,
                        onClick = { selectedDayFilter = 0 },
                        label = { Text("كل الأسبوع") },
                        modifier = Modifier.testTag("filter_day_all")
                    )
                }
                items(ClassSchedule.DAYS) { (dayNum, dayLabel) ->
                    FilterChip(
                        selected = selectedDayFilter == dayNum,
                        onClick = { selectedDayFilter = dayNum },
                        label = { Text(dayLabel) },
                        modifier = Modifier.testTag("filter_day_$dayNum")
                    )
                }
            }

            if (visibleSchedules.isEmpty()) {
                EmptyStateView(
                    title = "لا توجد حصص مجدولة",
                    description = "اضغط على زر (+) لإضافة مواعيد الحصص الأسبوعية للمجموعات",
                    icon = Icons.Default.CalendarMonth
                )
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(visibleSchedules, key = { it.id }) { item ->
                        ScheduleItemCard(
                            schedule = item,
                            onRemind = {
                                viewModel.sendScheduleReminder(item)
                                Toast.makeText(context, "تم إرسال تذكير الحصة لطلاب ${item.groupName}", Toast.LENGTH_SHORT).show()
                            },
                            onEdit = {
                                editingSchedule = item
                                showFormDialog = true
                            },
                            onDelete = {
                                viewModel.deleteClassSchedule(item)
                            }
                        )
                    }
                    item { Spacer(modifier = Modifier.height(72.dp)) }
                }
            }
        }
    }

    if (showFormDialog) {
        ScheduleFormDialog(
            initial = editingSchedule,
            existingGroups = groups,
            onDismiss = { showFormDialog = false },
            onSave = { dayOfWeek, groupName, subject, startTime, endTime, location, notes ->
                viewModel.saveClassSchedule(
                    id = editingSchedule?.id ?: 0,
                    dayOfWeek = dayOfWeek,
                    groupName = groupName,
                    subject = subject,
                    startTime = startTime,
                    endTime = endTime,
                    location = location,
                    notes = notes
                )
                showFormDialog = false
                Toast.makeText(context, "تم حفظ موعد الحصة في الجدول الأسبوعي", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

@Composable
private fun ScheduleItemCard(
    schedule: ClassSchedule,
    onRemind: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(AcademicBlueContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = schedule.dayName.take(3),
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.ExtraBold),
                            color = AcademicBluePrimary
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "${schedule.dayName} • ${schedule.groupName}",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        if (schedule.subject.isNotBlank()) {
                            Text(
                                text = schedule.subject,
                                style = MaterialTheme.typography.bodySmall,
                                color = AcademicBluePrimary
                            )
                        }
                    }
                }

                Row {
                    IconButton(onClick = onEdit, modifier = Modifier.testTag("btn_edit_schedule_${schedule.id}")) {
                        Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = AcademicBluePrimary)
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.testTag("btn_delete_schedule_${schedule.id}")) {
                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = StatusDanger)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AccessTime, contentDescription = null, modifier = Modifier.size(16.dp), tint = AcademicBluePrimary)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (schedule.endTime.isNotBlank()) "${schedule.startTime} - ${schedule.endTime}" else schedule.startTime,
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                    )
                }

                if (schedule.location.isNotBlank()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = schedule.location,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            if (schedule.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = schedule.notes,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedButton(
                onClick = onRemind,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("btn_remind_schedule_${schedule.id}")
            ) {
                Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("إرسال تذكير بموعد الحصة للطلاب", fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun ScheduleFormDialog(
    initial: ClassSchedule?,
    existingGroups: List<String>,
    onDismiss: () -> Unit,
    onSave: (dayOfWeek: Int, groupName: String, subject: String, startTime: String, endTime: String, location: String, notes: String) -> Unit
) {
    var selectedDay by remember { mutableIntStateOf(initial?.dayOfWeek ?: 1) }
    var groupName by remember { mutableStateOf(initial?.groupName ?: existingGroups.firstOrNull() ?: "الكل") }
    var subject by remember { mutableStateOf(initial?.subject ?: "") }
    var startTime by remember { mutableStateOf(initial?.startTime ?: "04:00 عصراً") }
    var endTime by remember { mutableStateOf(initial?.endTime ?: "05:30 عصراً") }
    var location by remember { mutableStateOf(initial?.location ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }

    SafeAlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial != null) "تعديل موعد الحصة" else "إضافة حصة للجدول الأسبوعي") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("اختر اليوم:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(ClassSchedule.DAYS) { (dayNum, dayLabel) ->
                        FilterChip(
                            selected = selectedDay == dayNum,
                            onClick = { selectedDay = dayNum },
                            label = { Text(dayLabel, fontSize = 11.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = groupName,
                    onValueChange = { groupName = it },
                    label = { Text("اسم المجموعة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (existingGroups.isNotEmpty()) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(existingGroups) { grp ->
                            FilterChip(
                                selected = groupName == grp,
                                onClick = { groupName = grp },
                                label = { Text(grp, fontSize = 10.sp) }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("المادة / موضوع الحصة (اختياري)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = startTime,
                        onValueChange = { startTime = it },
                        label = { Text("وقت البدء") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = endTime,
                        onValueChange = { endTime = it },
                        label = { Text("وقت الانتهاء") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("المكان / القاعة / رابط أونلاين") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات إضافية (اختياري)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            val dismissInput = rememberActiveInputDismisser()
            Button(
                onClick = {
                    if (startTime.isNotBlank()) {
                        dismissInput()
                        onSave(selectedDay, groupName, subject, startTime, endTime, location, notes)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary)
            ) {
                Text("حفظ الموعد")
            }
        },
        dismissButton = {
            val dismissInput = rememberActiveInputDismisser()
            OutlinedButton(onClick = {
                dismissInput()
                onDismiss()
            }) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
fun StudentWeeklyScheduleDialog(
    schedules: List<ClassSchedule>,
    studentGroupName: String,
    onDismiss: () -> Unit
) {
    val mySchedules = remember(schedules, studentGroupName) {
        schedules.filter {
            it.groupName == "الكل" || it.groupName.equals(studentGroupName, ignoreCase = true)
        }
    }

    SafeAlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = AcademicBluePrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("جدول حصصي الأسبوعي", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            if (mySchedules.isEmpty()) {
                Text(
                    text = "لم يقم المعلم بإضافة جدول أسبوعي لمجموعتك ($studentGroupName) بعد.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 340.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(mySchedules, key = { it.id }) { item ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = AcademicBlueContainer.copy(alpha = 0.45f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = item.dayName,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = AcademicBluePrimary
                                    )
                                    Text(
                                        text = if (item.endTime.isNotBlank()) "${item.startTime} - ${item.endTime}" else item.startTime,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                if (item.subject.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(item.subject, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                }
                                if (item.location.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "المكان: ${item.location}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary)
            ) {
                Text("إغلاق")
            }
        }
    )
}
