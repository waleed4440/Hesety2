package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.theme.AcademicBlueContainer
import com.example.ui.theme.AcademicBluePrimary
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusDangerContainer
import com.example.ui.theme.StatusSuccess
import com.example.util.AudioNoteHelper
import com.example.util.AudioPlaybackCoordinator
import com.example.util.VoiceRecorderManager
import kotlinx.coroutines.delay

@Composable
fun VoiceNoteRecorderBox(
    recordedAudioPath: String,
    recordedDurationSec: Int,
    onAudioChanged: (path: String, durationSec: Int) -> Unit,
    modifier: Modifier = Modifier,
    title: String = "ملاحظة صوتية للمعلم (اختياري)",
    prefix: String = "note"
) {
    val context = LocalContext.current
    val recorder = remember { VoiceRecorderManager(context) }
    var isRecording by remember { mutableStateOf(false) }
    var elapsedSec by remember { mutableIntStateOf(0) }

    fun beginRecording() {
        AudioPlaybackCoordinator.stop()
        recorder.startRecording(
            prefix = prefix,
            onStarted = {
                elapsedSec = 0
                isRecording = true
            },
            onError = { err ->
                isRecording = false
                Toast.makeText(context, err, Toast.LENGTH_LONG).show()
            }
        )
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            beginRecording()
        } else {
            Toast.makeText(
                context,
                "يجب السماح بصلاحية الميكروفون لتسجيل الملاحظة الصوتية",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    LaunchedEffect(isRecording) {
        while (isRecording) {
            delay(1000L)
            elapsedSec += 1
            if (elapsedSec >= 180) {
                val res = recorder.stopRecording()
                isRecording = false
                if (res != null) {
                    onAudioChanged(res.first, res.second)
                    Toast.makeText(context, "تم إيقاف التسجيل عند الحد الأقصى (3 دقائق)", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            if (isRecording) {
                recorder.cancelRecording()
            }
            AudioPlaybackCoordinator.stop()
        }
    }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (isRecording) StatusDangerContainer.copy(alpha = 0.55f) else AcademicBlueContainer.copy(alpha = 0.45f),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = null,
                        tint = if (isRecording) StatusDanger else AcademicBluePrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = title,
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                        color = if (isRecording) StatusDanger else AcademicBluePrimary
                    )
                }

                if (isRecording) {
                    val pulse = rememberInfiniteTransition(label = "rec_pulse")
                    val alpha by pulse.animateFloat(
                        initialValue = 1f,
                        targetValue = 0.25f,
                        animationSpec = infiniteRepeatable(tween(550), RepeatMode.Reverse),
                        label = "rec_alpha"
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .alpha(alpha)
                                .clip(CircleShape)
                                .background(StatusDanger)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = AudioNoteHelper.formatDuration(elapsedSec),
                            fontWeight = FontWeight.ExtraBold,
                            color = StatusDanger,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            if (isRecording) {
                Button(
                    onClick = {
                        val result = recorder.stopRecording()
                        isRecording = false
                        if (result != null) {
                            onAudioChanged(result.first, result.second)
                            Toast.makeText(context, "تم حفظ التسجيل الصوتي", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "التسجيل قصير جداً، حاول مرة أخرى", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDanger),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("btn_stop_voice_recording")
                ) {
                    Icon(Icons.Default.Stop, contentDescription = "إيقاف التسجيل", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("إيقاف وحفظ التسجيل", fontWeight = FontWeight.Bold)
                }
            } else if (recordedAudioPath.isNotBlank()) {
                VoiceNotePlayerBar(
                    audioPath = recordedAudioPath,
                    durationSeconds = recordedDurationSec,
                    label = "معاينة التسجيل الصوتي",
                    showShareButton = false
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            AudioPlaybackCoordinator.stop()
                            AudioNoteHelper.deleteAudioFileIfExists(recordedAudioPath)
                            onAudioChanged("", 0)
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_delete_voice_recording")
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, tint = StatusDanger, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("حذف الصوت", color = StatusDanger, fontSize = 12.sp)
                    }

                    Button(
                        onClick = {
                            AudioNoteHelper.deleteAudioFileIfExists(recordedAudioPath)
                            onAudioChanged("", 0)
                            val hasPerm = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED
                            if (hasPerm) beginRecording() else micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_rerecord_voice")
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("إعادة التسجيل", fontSize = 12.sp)
                    }
                }
            } else {
                OutlinedButton(
                    onClick = {
                        val hasPerm = ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED
                        if (hasPerm) {
                            beginRecording()
                        } else {
                            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("btn_start_voice_recording")
                ) {
                    Icon(Icons.Default.Mic, contentDescription = null, tint = AcademicBluePrimary, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("اضغط لتسجيل ملاحظة صوتية", color = AcademicBluePrimary, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun VoiceNotePlayerBar(
    audioPath: String,
    durationSeconds: Int,
    modifier: Modifier = Modifier,
    label: String = "ملاحظة صوتية من الأستاذ",
    showShareButton: Boolean = false,
    onShareClick: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val activePath by AudioPlaybackCoordinator.activePath.collectAsState()
    val isGlobalPlaying by AudioPlaybackCoordinator.isPlaying.collectAsState()
    val currentSec by AudioPlaybackCoordinator.currentPositionSec.collectAsState()
    val playerDurationSec by AudioPlaybackCoordinator.durationSec.collectAsState()

    val isThisActive = activePath == audioPath
    val isThisPlaying = isThisActive && isGlobalPlaying
    val effectiveDuration = if (isThisActive && playerDurationSec > 0) playerDurationSec else durationSeconds.coerceAtLeast(1)
    val effectivePos = if (isThisActive) currentSec.coerceIn(0, effectiveDuration) else 0
    val progress = (effectivePos.toFloat() / effectiveDuration.toFloat()).coerceIn(0f, 1f)

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = AcademicBlueContainer.copy(alpha = 0.7f),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    AudioPlaybackCoordinator.togglePlay(
                        context = context,
                        filePath = audioPath,
                        fallbackDurationSec = durationSeconds
                    )
                },
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(AcademicBluePrimary)
                    .testTag("btn_play_voice_note")
            ) {
                Icon(
                    imageVector = if (isThisPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isThisPlaying) "إيقاف مؤقت" else "تشغيل الملاحظة الصوتية",
                    tint = Color.White
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = null,
                            tint = if (isThisPlaying) StatusSuccess else AcademicBluePrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = AcademicBluePrimary
                        )
                    }
                    Text(
                        text = if (isThisActive) {
                            "${AudioNoteHelper.formatDuration(effectivePos)} / ${AudioNoteHelper.formatDuration(effectiveDuration)}"
                        } else {
                            AudioNoteHelper.formatDuration(durationSeconds)
                        },
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = if (isThisPlaying) StatusSuccess else AcademicBluePrimary,
                    trackColor = Color.White.copy(alpha = 0.8f)
                )
            }

            AnimatedVisibility(visible = showShareButton && onShareClick != null) {
                IconButton(
                    onClick = { onShareClick?.invoke() },
                    modifier = Modifier
                        .padding(start = 4.dp)
                        .size(48.dp)
                        .testTag("btn_share_voice_note")
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "مشاركة الصوت",
                        tint = AcademicBluePrimary
                    )
                }
            }
        }
    }
}
