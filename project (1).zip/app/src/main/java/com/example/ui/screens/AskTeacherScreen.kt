package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.Student
import com.example.data.StudentQuestion
import com.example.ui.TeacherViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.EmptyStateView
import com.example.ui.components.SafeAlertDialog
import com.example.ui.components.StatusBadge
import com.example.ui.components.VoiceNotePlayerBar
import com.example.ui.components.VoiceNoteRecorderBox
import com.example.ui.components.rememberActiveInputDismisser
import com.example.ui.theme.AcademicBlueContainer
import com.example.ui.theme.AcademicBluePrimary
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessContainer
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningContainer
import com.example.util.QrCodeHelper
import java.io.File

@Composable
fun AskTeacherScreen(
    viewModel: TeacherViewModel,
    isTeacher: Boolean,
    currentStudent: Student? = null,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val allQuestions by viewModel.allQuestions.collectAsState()
    val groups by viewModel.allGroups.collectAsState()
    val context = LocalContext.current

    var searchQuery by remember { mutableStateOf("") }
    var statusFilter by remember { mutableStateOf("الكل") } // الكل, بانتظار الرد, تمت الإجابة, المثبتة
    var groupFilter by remember { mutableStateOf("الكل") }
    var onlyMineFilter by remember { mutableStateOf(false) }

    var showAskDialog by remember { mutableStateOf(false) }
    var answeringQuestion by remember { mutableStateOf<StudentQuestion?>(null) }
    var enlargedImagePath by remember { mutableStateOf<String?>(null) }

    // Role-based visible questions
    val visibleQuestions = remember(allQuestions, isTeacher, currentStudent) {
        if (isTeacher) {
            allQuestions
        } else if (currentStudent != null) {
            allQuestions.filter { q ->
                q.studentId == currentStudent.id ||
                    (q.isPublicToGroup && (q.groupName.equals(currentStudent.groupName, ignoreCase = true) || q.groupName == "الكل"))
            }
        } else {
            emptyList()
        }
    }

    val pendingCount = remember(visibleQuestions) { visibleQuestions.count { !it.isAnswered } }
    val pinnedCount = remember(visibleQuestions) { visibleQuestions.count { it.isPinned } }

    val availableGroups = remember(groups, allQuestions) {
        (listOf("الكل") + groups + allQuestions.map { it.groupName }).distinct()
    }

    val filteredQuestions = remember(
        visibleQuestions,
        searchQuery,
        statusFilter,
        groupFilter,
        onlyMineFilter,
        isTeacher,
        currentStudent
    ) {
        visibleQuestions.filter { q ->
            val matchesSearch = searchQuery.isBlank() ||
                q.questionText.contains(searchQuery, ignoreCase = true) ||
                q.answerText.contains(searchQuery, ignoreCase = true) ||
                q.subject.contains(searchQuery, ignoreCase = true) ||
                q.studentName.contains(searchQuery, ignoreCase = true)
            val matchesStatus = when (statusFilter) {
                "بانتظار الرد" -> !q.isAnswered
                "تمت الإجابة" -> q.isAnswered
                "المثبتة" -> q.isPinned
                else -> true
            }
            val matchesGroup = if (isTeacher) {
                groupFilter == "الكل" || q.groupName == groupFilter
            } else {
                !onlyMineFilter || (currentStudent != null && q.studentId == currentStudent.id)
            }
            matchesSearch && matchesStatus && matchesGroup
        }
    }

    Scaffold(
        floatingActionButton = {
            if (!isTeacher && currentStudent != null) {
                FloatingActionButton(
                    onClick = { showAskDialog = true },
                    containerColor = AcademicBluePrimary,
                    contentColor = Color.White,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.testTag("fab_ask_teacher")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "اطرح سؤالاً")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("اسأل المعلم", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AppHeader(
                title = "ركن اسأل المعلم",
                subtitle = if (isTeacher) {
                    "أجب عن أسئلة الطلاب كتابةً أو صوتياً وثبّت الأسئلة المهمة"
                } else {
                    "اسأل الأستاذ في أي درس أو مسألة وتابع الأسئلة المثبتة لمجموعتك"
                },
                onBack = onBack
            )

            // Quick Stats Strip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = AcademicBlueContainer.copy(alpha = 0.7f),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("${visibleQuestions.size}", fontWeight = FontWeight.ExtraBold, color = AcademicBluePrimary)
                        Text("إجمالي الأسئلة", style = MaterialTheme.typography.labelSmall, color = AcademicBluePrimary)
                    }
                }
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = StatusWarningContainer.copy(alpha = 0.7f),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("$pendingCount", fontWeight = FontWeight.ExtraBold, color = StatusWarning)
                        Text("بانتظار الرد", style = MaterialTheme.typography.labelSmall, color = StatusWarning)
                    }
                }
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = StatusSuccessContainer.copy(alpha = 0.7f),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("$pinnedCount", fontWeight = FontWeight.ExtraBold, color = StatusSuccess)
                        Text("أسئلة مثبتة", style = MaterialTheme.typography.labelSmall, color = StatusSuccess)
                    }
                }
            }

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("ابحث في الأسئلة أو المواد...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .testTag("input_qa_search")
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Status Filter Chips
            val statusOptions = listOf("الكل", "بانتظار الرد", "تمت الإجابة", "المثبتة")
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(statusOptions) { opt ->
                    FilterChip(
                        selected = statusFilter == opt,
                        onClick = { statusFilter = opt },
                        label = { Text(opt, fontSize = 12.sp) },
                        modifier = Modifier.testTag("chip_qa_status_$opt")
                    )
                }
            }

            // Secondary filter row: Groups for teacher OR "My Questions" toggle for student
            if (isTeacher && availableGroups.size > 1) {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(availableGroups) { grp ->
                        FilterChip(
                            selected = groupFilter == grp,
                            onClick = { groupFilter = grp },
                            label = { Text(grp, fontSize = 11.sp) }
                        )
                    }
                }
            } else if (!isTeacher) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = !onlyMineFilter,
                        onClick = { onlyMineFilter = false },
                        label = { Text("أسئلة مجموعتي", fontSize = 12.sp) }
                    )
                    FilterChip(
                        selected = onlyMineFilter,
                        onClick = { onlyMineFilter = true },
                        label = { Text("أسئلتي فقط", fontSize = 12.sp) }
                    )
                }
            }

            if (filteredQuestions.isEmpty()) {
                EmptyStateView(
                    title = "لا توجد أسئلة مطابقة حالياً",
                    description = if (isTeacher) {
                        "عندما يطرح الطلاب أسئلة في دروسهم ستظهر هنا للرد عليها"
                    } else {
                        "اضغط على زر (اسأل المعلم) بالأسفل لطرح سؤالك أو إرفاق صورة مسألة"
                    },
                    icon = Icons.AutoMirrored.Filled.Chat
                )
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredQuestions, key = { it.id }) { q ->
                        QuestionCardItem(
                            question = q,
                            isTeacher = isTeacher,
                            isOwner = currentStudent?.id == q.studentId,
                            onAnswerClick = { answeringQuestion = q },
                            onTogglePin = { viewModel.togglePinQuestion(q) },
                            onDelete = {
                                viewModel.deleteStudentQuestion(q)
                                Toast.makeText(context, "تم حذف السؤال", Toast.LENGTH_SHORT).show()
                            },
                            onImageClick = { path -> enlargedImagePath = path }
                        )
                    }
                    item { Spacer(modifier = Modifier.height(72.dp)) }
                }
            }
        }
    }

    if (showAskDialog && currentStudent != null) {
        AskQuestionDialog(
            student = currentStudent,
            onDismiss = { showAskDialog = false },
            onSubmit = { subject, text, imagePath, isPublic ->
                viewModel.askTeacherQuestion(
                    student = currentStudent,
                    subject = subject,
                    questionText = text,
                    imagePath = imagePath,
                    isPublicToGroup = isPublic
                )
                showAskDialog = false
                Toast.makeText(context, "تم إرسال سؤالك للأستاذ بنجاح", Toast.LENGTH_SHORT).show()
            }
        )
    }

    if (answeringQuestion != null) {
        AnswerQuestionDialog(
            question = answeringQuestion!!,
            onDismiss = { answeringQuestion = null },
            onSave = { answerText, audioPath, audioDur ->
                viewModel.answerStudentQuestion(
                    question = answeringQuestion!!,
                    answerText = answerText,
                    answerAudioPath = audioPath,
                    answerAudioDuration = audioDur
                )
                answeringQuestion = null
                Toast.makeText(context, "تم إرسال الإجابة بنجاح", Toast.LENGTH_SHORT).show()
            }
        )
    }

    if (enlargedImagePath != null) {
        SafeAlertDialog(
            onDismissRequest = { enlargedImagePath = null },
            text = {
                AsyncImage(
                    model = File(enlargedImagePath!!),
                    contentDescription = "صورة السؤال",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(340.dp)
                )
            },
            confirmButton = {
                Button(onClick = { enlargedImagePath = null }) {
                    Text("إغلاق")
                }
            }
        )
    }
}

@Composable
private fun QuestionCardItem(
    question: StudentQuestion,
    isTeacher: Boolean,
    isOwner: Boolean,
    onAnswerClick: () -> Unit,
    onTogglePin: () -> Unit,
    onDelete: () -> Unit,
    onImageClick: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (question.isPinned) Color(0xFFFFFBEB) else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (question.isPinned) 3.dp else 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("qa_card_${question.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(AcademicBlueContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.HelpOutline,
                            contentDescription = null,
                            tint = AcademicBluePrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = question.studentName,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${question.subject} • ${question.groupName} • ${question.createdDate}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (question.isPinned) {
                        StatusBadge(
                            text = "مثبت",
                            color = StatusWarning,
                            bgColor = StatusWarningContainer,
                            icon = Icons.Default.PushPin
                        )
                    }
                    if (!question.isPublicToGroup) {
                        StatusBadge(
                            text = "خاص",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            bgColor = MaterialTheme.colorScheme.surfaceVariant,
                            icon = Icons.Default.Lock
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Question Body
            Text(
                text = question.questionText,
                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium),
                color = MaterialTheme.colorScheme.onSurface
            )

            if (question.questionImagePath.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(170.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable { onImageClick(question.questionImagePath) }
                ) {
                    AsyncImage(
                        model = File(question.questionImagePath),
                        contentDescription = "صورة مرفقة بالسؤال",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Answer Section or Waiting Badge
            if (question.isAnswered) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = StatusSuccessContainer.copy(alpha = 0.45f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = StatusSuccess,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "إجابة الأستاذ",
                                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                    color = StatusSuccess
                                )
                            }
                            if (question.answeredDate.isNotBlank()) {
                                Text(
                                    text = question.answeredDate,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        if (question.answerText.isNotBlank()) {
                            Text(
                                text = question.answerText,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        if (question.answerAudioPath.isNotBlank()) {
                            VoiceNotePlayerBar(
                                audioPath = question.answerAudioPath,
                                durationSeconds = question.answerAudioDuration,
                                label = "شرح صوتي من الأستاذ",
                                showShareButton = false
                            )
                        }
                    }
                }
            } else {
                StatusBadge(
                    text = "بانتظار رد الأستاذ",
                    color = StatusWarning,
                    bgColor = StatusWarningContainer,
                    icon = Icons.Default.HourglassTop
                )
            }

            // Action Buttons
            if (isTeacher || isOwner) {
                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (isTeacher) {
                        Button(
                            onClick = onAnswerClick,
                            colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("btn_answer_qa_${question.id}")
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (question.isAnswered) "تعديل الإجابة" else "إجابة الطالب", fontSize = 12.sp)
                        }

                        Row {
                            IconButton(
                                onClick = onTogglePin,
                                modifier = Modifier.testTag("btn_pin_qa_${question.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PushPin,
                                    contentDescription = if (question.isPinned) "إلغاء التثبيت" else "تثبيت السؤال",
                                    tint = if (question.isPinned) StatusWarning else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(
                                onClick = onDelete,
                                modifier = Modifier.testTag("btn_delete_qa_${question.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "حذف السؤال",
                                    tint = StatusDanger
                                )
                            }
                        }
                    } else if (isOwner) {
                        Text(
                            text = if (question.isAnswered) "تم الرد على سؤالك" else "سؤالك قيد المراجعة",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        IconButton(
                            onClick = onDelete,
                            modifier = Modifier.testTag("btn_delete_own_qa_${question.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "حذف سؤالي",
                                tint = StatusDanger
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AskQuestionDialog(
    student: Student,
    onDismiss: () -> Unit,
    onSubmit: (subject: String, questionText: String, imagePath: String, isPublic: Boolean) -> Unit
) {
    val context = LocalContext.current
    var subject by remember { mutableStateOf("") }
    var questionText by remember { mutableStateOf("") }
    var imagePath by remember { mutableStateOf("") }
    var isPublic by remember { mutableStateOf(true) }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val copied = QrCodeHelper.copyPickedImageToInternal(context, uri)
            if (copied != null) {
                imagePath = copied
                Toast.makeText(context, "تم إرفاق صورة المسألة", Toast.LENGTH_SHORT).show()
            }
        }
    }

    SafeAlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("طرح سؤال جديد في ركن اسأل المعلم", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "المجموعة: ${student.groupName}",
                    style = MaterialTheme.typography.bodySmall,
                    color = AcademicBluePrimary,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("المادة أو اسم الدرس (مثال: الجبر)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_qa_subject")
                )

                OutlinedTextField(
                    value = questionText,
                    onValueChange = { questionText = it },
                    label = { Text("اكتب سؤالك للأستاذ بالتفصيل") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_qa_question_text")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = {
                            imagePicker.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_attach_qa_image")
                    ) {
                        Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (imagePath.isBlank()) "إرفاق صورة مسألة" else "تغيير الصورة", fontSize = 12.sp)
                    }

                    if (imagePath.isNotBlank()) {
                        IconButton(onClick = { imagePath = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "إزالة الصورة", tint = StatusDanger)
                        }
                    }
                }

                if (imagePath.isNotBlank()) {
                    AsyncImage(
                        model = File(imagePath),
                        contentDescription = "معاينة الصورة",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .clip(RoundedCornerShape(10.dp))
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "مشاركة السؤال مع المجموعة",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
                        )
                        Text(
                            text = if (isPublic) "يظهر لزملاء مجموعتك للاستفادة من الرد" else "سؤال خاص بينك وبين الأستاذ فقط",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = isPublic, onCheckedChange = { isPublic = it })
                }
            }
        },
        confirmButton = {
            val dismissInput = rememberActiveInputDismisser()
            Button(
                onClick = {
                    if (questionText.isNotBlank() || imagePath.isNotBlank()) {
                        dismissInput()
                        onSubmit(subject, questionText, imagePath, isPublic)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary),
                modifier = Modifier.testTag("btn_submit_qa_question")
            ) {
                Text("إرسال السؤال")
            }
        },
        dismissButton = {
            val dismissInput = rememberActiveInputDismisser()
            OutlinedButton(onClick = {
                dismissInput()
                onDismiss()
            }) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
private fun AnswerQuestionDialog(
    question: StudentQuestion,
    onDismiss: () -> Unit,
    onSave: (answerText: String, audioPath: String, audioDuration: Int) -> Unit
) {
    var answerText by remember { mutableStateOf(question.answerText) }
    var audioPath by remember { mutableStateOf(question.answerAudioPath) }
    var audioDuration by remember { mutableIntStateOf(question.answerAudioDuration) }

    SafeAlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("الإجابة على سؤال الطالب", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "${question.studentName} • ${question.subject}",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = AcademicBluePrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = question.questionText,
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 4
                        )
                    }
                }

                OutlinedTextField(
                    value = answerText,
                    onValueChange = { answerText = it },
                    label = { Text("الإجابة الكتابية (اختياري مع الصوت)") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_qa_answer_text")
                )

                VoiceNoteRecorderBox(
                    recordedAudioPath = audioPath,
                    recordedDurationSec = audioDuration,
                    onAudioChanged = { path, dur ->
                        audioPath = path
                        audioDuration = dur
                    },
                    title = "شرح صوتي للإجابة (اختياري)",
                    prefix = "qa_ans"
                )
            }
        },
        confirmButton = {
            val dismissInput = rememberActiveInputDismisser()
            Button(
                onClick = {
                    if (answerText.isNotBlank() || audioPath.isNotBlank()) {
                        dismissInput()
                        onSave(answerText, audioPath, audioDuration)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary),
                modifier = Modifier.testTag("btn_save_qa_answer")
            ) {
                Text("حفظ وإرسال الرد")
            }
        },
        dismissButton = {
            val dismissInput = rememberActiveInputDismisser()
            OutlinedButton(onClick = {
                dismissInput()
                onDismiss()
            }) {
                Text("إلغاء")
            }
        }
    )
}
