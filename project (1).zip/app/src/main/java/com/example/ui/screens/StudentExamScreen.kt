package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.OutlinedFlag
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch
import com.example.data.Announcement
import com.example.data.EducationalResource
import com.example.data.Exam
import com.example.data.ExamQuestion
import com.example.data.ExamSubmission
import com.example.data.Student
import com.example.ui.StudentTab
import com.example.ui.TeacherViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.EmptyStateView
import com.example.ui.components.SafeAlertDialog
import com.example.ui.components.StatusBadge
import com.example.ui.components.rememberActiveInputDismisser
import com.example.ui.theme.AcademicBlueContainer
import com.example.ui.theme.AcademicBluePrimary
import com.example.ui.theme.AcademicBlueSecondary
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusDangerContainer
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessContainer
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningContainer
import com.example.ui.theme.calmAnnouncementPalette
import com.example.util.QrCodeHelper
import kotlinx.coroutines.delay
import org.json.JSONObject

@Composable
fun StudentExamsTab(
    viewModel: TeacherViewModel,
    student: Student
) {
    val exams by viewModel.allExams.collectAsState()
    val submissions by viewModel.studentSubmissions.collectAsState()
    val studentMistakes by viewModel.studentMistakes.collectAsState()
    val todayDate = remember { SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date()) }
    val visibleExams = remember(exams, student.groupName) {
        exams.filter { it.groupName == "الكل" || it.groupName.equals(student.groupName, ignoreCase = true) }
    }
    val unmasteredMistakesCount = remember(studentMistakes, exams) {
        studentMistakes.count { m ->
            !m.isMastered && (m.examId == 0L || exams.firstOrNull { it.id == m.examId }?.let { it.showResultImmediately || !it.isActive } != false)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        AppHeader(
            title = "الامتحانات الأونلاين",
            subtitle = "اختبارات التقييم الدوري والمراجعة الذكية للأخطاء"
        )

        OutlinedButton(
            onClick = { viewModel.setStudentTab(StudentTab.MISTAKE_BANK) },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .testTag("btn_student_mistake_bank")
        ) {
            Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = AcademicBluePrimary, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (unmasteredMistakesCount > 0) {
                    "بنك أخطائي ($unmasteredMistakesCount سؤال بحاجة للمراجعة)"
                } else {
                    "فتح بنك أخطائي والتدريب"
                },
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }

        if (visibleExams.isEmpty()) {
            EmptyStateView(
                title = "لا توجد امتحانات متاحة",
                description = "سيقوم الأستاذ بإضافة اختبارات جديدة قريباً",
                icon = Icons.Default.Quiz
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(visibleExams) { exam ->
                    val submission = submissions.firstOrNull { it.examId == exam.id }
                    ExamItemCard(
                        exam = exam,
                        submission = submission,
                        todayDate = todayDate,
                        onStartExam = {
                            viewModel.startTakingExam(exam, retake = false)
                        },
                        onRetakeExam = {
                            viewModel.startTakingExam(exam, retake = true)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun ExamItemCard(
    exam: Exam,
    submission: ExamSubmission?,
    todayDate: String,
    onStartExam: () -> Unit,
    onRetakeExam: () -> Unit
) {
    val questions = remember(exam.questionsJson) { exam.parseQuestions() }
    val isExpired = remember(exam.deadlineDate, todayDate) { exam.isExpired(todayDate) }
    val canTakeExam = exam.isActive && !isExpired
    val canRevealScore = submission != null && (exam.showResultImmediately || !exam.isActive)

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = exam.title,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "المادة: ${exam.subject} • حد النجاح: ${exam.passingPercentage}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = AcademicBluePrimary
                    )
                    if (exam.description.isNotBlank()) {
                        Text(
                            text = exam.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (exam.deadlineDate.isNotBlank()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Event,
                                contentDescription = null,
                                tint = if (isExpired) StatusDanger else StatusWarning,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "آخر موعد: ${exam.deadlineDate}",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isExpired) StatusDanger else StatusWarning,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                when {
                    canRevealScore && submission != null -> {
                        val passed = exam.isPassing(submission.score, submission.maxScore)
                        StatusBadge(
                            text = "${submission.score} / ${submission.maxScore} (${if (passed) "ناجح" else "دون الحد"})",
                            color = if (passed) StatusSuccess else StatusDanger,
                            bgColor = if (passed) StatusSuccessContainer else StatusDangerContainer,
                            icon = if (passed) Icons.Default.CheckCircle else Icons.Default.ErrorOutline
                        )
                    }
                    submission != null -> {
                        StatusBadge(
                            text = "تم التسليم",
                            color = AcademicBluePrimary,
                            bgColor = AcademicBlueContainer,
                            icon = Icons.Default.CheckCircle
                        )
                    }
                    isExpired -> {
                        StatusBadge(
                            text = "منتهي الصلاحية",
                            color = StatusDanger,
                            bgColor = StatusDangerContainer,
                            icon = Icons.Default.Lock
                        )
                    }
                    !exam.isActive -> {
                        StatusBadge(
                            text = "مغلق",
                            color = StatusDanger,
                            bgColor = StatusDangerContainer,
                            icon = Icons.Default.Lock
                        )
                    }
                    else -> {
                        StatusBadge(
                            text = "متاح للحل",
                            color = AcademicBluePrimary,
                            bgColor = AcademicBlueContainer
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AccessTime,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${exam.durationMinutes} دقيقة",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Quiz,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${questions.size} أسئلة",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${exam.totalMarks} درجة",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (submission != null) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (canRevealScore) "تم تقديم الاختبار واعتماد النتيجة بنجاح" else "تم استلام إجاباتك وبانتظار إتاحة النتائج",
                        style = MaterialTheme.typography.bodySmall,
                        color = StatusSuccess,
                        fontWeight = FontWeight.Medium
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (canRevealScore) {
                            OutlinedButton(
                                onClick = onStartExam,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_review_exam_${exam.id}")
                            ) {
                                Text("مراجعة الإجابات", fontSize = 12.sp)
                            }
                        }

                        if (exam.allowRetake && canTakeExam) {
                            Button(
                                onClick = onRetakeExam,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_retake_exam_${exam.id}")
                            ) {
                                Icon(Icons.Default.Replay, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("إعادة المحاولة", fontSize = 12.sp)
                            }
                        }
                    }
                }
            } else {
                Button(
                    onClick = onStartExam,
                    enabled = canTakeExam,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_start_exam_${exam.id}")
                ) {
                    Icon(
                        imageVector = if (canTakeExam) Icons.Default.PlayArrow else Icons.Default.Lock,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        when {
                            isExpired -> "انتهى موعد تسليم الامتحان"
                            !exam.isActive -> "الامتحان مغلق حالياً من المعلم"
                            else -> "بدء حل الامتحان الآن"
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun StudentExamTakerScreen(
    exam: Exam,
    student: Student,
    existingSubmission: ExamSubmission? = null,
    onFinish: (score: Int, maxScore: Int, answersJson: String) -> Unit,
    onCancel: () -> Unit,
    onOpenMistakeBank: () -> Unit = {}
) {
    BackHandler { onCancel() }

    val questions = remember(exam.id, exam.questionsJson, existingSubmission != null) {
        val parsed = exam.parseQuestions()
        if (exam.shuffleQuestions && existingSubmission == null) parsed.shuffled() else parsed
    }
    val displayOptionsMap = remember(exam.id, questions, exam.shuffleOptions, existingSubmission != null) {
        questions.associate { q ->
            val pairs = if (q.questionType == ExamQuestion.TYPE_MCQ && exam.shuffleOptions && existingSubmission == null) {
                q.shuffledForDisplay()
            } else {
                q.options.mapIndexed { idx, txt -> idx to txt }
            }
            q.id to pairs
        }
    }
    val flaggedQuestions = remember(exam.id) { mutableStateMapOf<Int, Boolean>() }
    val selectedAnswers = remember(exam.id, existingSubmission?.submittedAt) {
        mutableStateMapOf<Int, Int>().apply {
            if (existingSubmission != null) {
                try {
                    val obj = JSONObject(existingSubmission.answersJson)
                    val keys = obj.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        val qId = k.toIntOrNull()
                        if (qId != null) {
                            val ans = obj.optInt(k, -1)
                            if (ans >= 0) {
                                put(qId, ans)
                            }
                        }
                    }
                } catch (_: Exception) {}
            }
        }
    }
    val textAnswers = remember(exam.id, existingSubmission?.submittedAt) {
        mutableStateMapOf<Int, String>().apply {
            if (existingSubmission != null) {
                try {
                    val obj = JSONObject(existingSubmission.answersJson)
                    val keys = obj.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        if (k.startsWith("text_")) {
                            val qId = k.removePrefix("text_").toIntOrNull()
                            if (qId != null) {
                                put(qId, obj.optString(k, ""))
                            }
                        }
                    }
                } catch (_: Exception) {}
            }
        }
    }
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    var showConfirmDialog by remember { mutableStateOf(false) }
    var enlargedImagePath by remember { mutableStateOf<String?>(null) }
    var isSubmitted by remember(existingSubmission?.submittedAt) { mutableStateOf(existingSubmission != null) }
    var finalScore by remember(existingSubmission?.submittedAt) { mutableIntStateOf(existingSubmission?.score ?: 0) }
    val showFeedbackNow = isSubmitted && (exam.showResultImmediately || !exam.isActive)

    // Countdown Timer in seconds
    var remainingSeconds by remember { mutableIntStateOf(exam.durationMinutes * 60) }

    LaunchedEffect(isSubmitted) {
        if (!isSubmitted) {
            while (remainingSeconds > 0) {
                delay(1000)
                remainingSeconds -= 1
            }
            if (remainingSeconds <= 0 && !isSubmitted) {
                // Auto submit when time runs out
                calculateAndSubmit(questions, selectedAnswers, textAnswers) { score, maxScore, json ->
                    finalScore = score
                    isSubmitted = true
                    onFinish(score, maxScore, json)
                }
            }
        }
    }

    fun isQuestionAnswered(q: ExamQuestion): Boolean {
        return if (q.questionType == ExamQuestion.TYPE_SHORT_ANSWER) {
            !textAnswers[q.id].isNullOrBlank()
        } else {
            selectedAnswers.containsKey(q.id)
        }
    }

    fun isQuestionCorrect(q: ExamQuestion): Boolean {
        return if (q.questionType == ExamQuestion.TYPE_SHORT_ANSWER) {
            val typed = textAnswers[q.id].orEmpty()
            q.correctTextAnswer.isNotBlank() &&
                ExamQuestion.normalizeShortAnswer(typed) == ExamQuestion.normalizeShortAnswer(q.correctTextAnswer)
        } else {
            selectedAnswers[q.id] == q.correctOptionIndex
        }
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = exam.title,
                subtitle = "الدرجة الكلية: ${exam.totalMarks} درجة",
                onBack = { if (!isSubmitted) showConfirmDialog = true else onCancel() },
                actions = {
                    val minutes = remainingSeconds / 60
                    val seconds = remainingSeconds % 60
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (remainingSeconds < 120) StatusDangerContainer else AcademicBlueContainer
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccessTime,
                                contentDescription = null,
                                tint = if (remainingSeconds < 120) StatusDanger else AcademicBluePrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = String.format("%02d:%02d", minutes, seconds),
                                fontWeight = FontWeight.Bold,
                                color = if (remainingSeconds < 120) StatusDanger else AcademicBluePrimary
                            )
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .consumeWindowInsets(innerPadding)
                .imePadding()
                .padding(16.dp)
        ) {
            if (isSubmitted) {
                val passed = exam.isPassing(finalScore, exam.totalMarks)
                val wrongCount = questions.count { !isQuestionCorrect(it) }
                // Result Card
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (!showFeedbackNow || passed) StatusSuccessContainer else StatusDangerContainer
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = if (!showFeedbackNow || passed) Icons.Default.CheckCircle else Icons.Default.ErrorOutline,
                            contentDescription = null,
                            tint = if (!showFeedbackNow || passed) StatusSuccess else StatusDanger,
                            modifier = Modifier.size(54.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = when {
                                !showFeedbackNow -> "تم استلام إجاباتك بنجاح!"
                                passed -> "مبارك! اجتزت الامتحان بنجاح ✓"
                                else -> "انتهى الامتحان (دون درجة النجاح ${exam.passingPercentage}%)"
                            },
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = if (!showFeedbackNow || passed) StatusSuccess else StatusDanger
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (showFeedbackNow) {
                                "درجتك في هذا الاختبار: $finalScore من ${exam.totalMarks}"
                            } else {
                                "سيتم إتاحة النتيجة ومراجعة الإجابات بعد اعتماد المعلم."
                            },
                            style = if (showFeedbackNow) MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold) else MaterialTheme.typography.bodyMedium,
                            color = AcademicBluePrimary
                        )
                        if (showFeedbackNow && wrongCount > 0) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "تم حفظ $wrongCount أخطاء تلقائياً في بنك أخطائك لمراجعتها.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = onCancel,
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary)
                            ) {
                                Text("صفحة الامتحانات")
                            }
                            if (showFeedbackNow && wrongCount > 0) {
                                OutlinedButton(
                                    onClick = onOpenMistakeBank,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.testTag("btn_practice_exam_mistakes")
                                ) {
                                    Text("تدرب على أخطائك ($wrongCount)")
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
            }

            // Question Progress & Navigator Strip
            if (questions.isNotEmpty()) {
                val answeredCount = questions.count { isQuestionAnswered(it) }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "تمت الإجابة على $answeredCount من ${questions.size}",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = AcademicBluePrimary
                    )
                    Text(
                        text = "${(answeredCount * 100) / questions.size}%",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = StatusSuccess
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { answeredCount.toFloat() / questions.size.coerceAtLeast(1).toFloat() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = AcademicBluePrimary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(questions.size) { idx ->
                        val qItem = questions[idx]
                        val isAns = isQuestionAnswered(qItem)
                        val isCorrect = isQuestionCorrect(qItem)
                        val isFlagged = flaggedQuestions[qItem.id] == true
                        val pillBg = when {
                            showFeedbackNow && isCorrect -> StatusSuccessContainer
                            showFeedbackNow && !isCorrect -> StatusDangerContainer
                            isFlagged -> StatusWarningContainer
                            isAns -> AcademicBlueContainer
                            else -> MaterialTheme.colorScheme.surfaceVariant
                        }
                        val pillFg = when {
                            showFeedbackNow && isCorrect -> StatusSuccess
                            showFeedbackNow && !isCorrect -> StatusDanger
                            isFlagged -> Color(0xFF92400E)
                            isAns -> AcademicBluePrimary
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                        Surface(
                            shape = CircleShape,
                            color = pillBg,
                            border = if (isFlagged && !isSubmitted) BorderStroke(1.5.dp, StatusWarning) else null,
                            modifier = Modifier
                                .size(36.dp)
                                .clickable {
                                    coroutineScope.launch { listState.animateScrollToItem(idx) }
                                }
                                .testTag("nav_q_${idx + 1}")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = if (isFlagged && !isSubmitted) "${idx + 1}⚑" else "${idx + 1}",
                                    fontWeight = FontWeight.Bold,
                                    color = pillFg,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(questions.size) { index ->
                    val q = questions[index]
                    val selected = selectedAnswers[q.id]
                    val isFlagged = flaggedQuestions[q.id] == true

                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val typeHint = when (q.questionType) {
                                    ExamQuestion.TYPE_TRUE_FALSE -> "صح وخطأ"
                                    ExamQuestion.TYPE_SHORT_ANSWER -> "إجابة قصيرة"
                                    else -> "اختيار من متعدد"
                                }
                                Text(
                                    text = "السؤال ${index + 1} • $typeHint (${q.points} درجات) • ${ExamQuestion.difficultyLabel(q.difficulty)}",
                                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                    color = AcademicBluePrimary,
                                    modifier = Modifier.weight(1f)
                                )

                                if (!isSubmitted) {
                                    IconButton(
                                        onClick = { flaggedQuestions[q.id] = !isFlagged },
                                        modifier = Modifier.testTag("btn_flag_q_${q.id}")
                                    ) {
                                        Icon(
                                            imageVector = if (isFlagged) Icons.Default.Flag else Icons.Default.OutlinedFlag,
                                            contentDescription = if (isFlagged) "إلغاء علامة المراجعة" else "تعليم للمراجعة",
                                            tint = if (isFlagged) StatusWarning else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                } else if (showFeedbackNow) {
                                    if (isQuestionCorrect(q)) {
                                        Text("إجابة صحيحة ✓", color = StatusSuccess, fontWeight = FontWeight.Bold)
                                    } else {
                                        Text("إجابة خاطئة ✗", color = StatusDanger, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = q.questionText,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Medium),
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            if (q.imageUri.isNotBlank()) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(170.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable { enlargedImagePath = q.imageUri }
                                ) {
                                    AsyncImage(
                                        model = File(q.imageUri),
                                        contentDescription = "صورة توضيحية للسؤال ${index + 1}",
                                        contentScale = ContentScale.Fit,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            when (q.questionType) {
                                ExamQuestion.TYPE_SHORT_ANSWER -> {
                                    val typedValue = textAnswers[q.id].orEmpty()
                                    OutlinedTextField(
                                        value = typedValue,
                                        onValueChange = { if (!isSubmitted) textAnswers[q.id] = it },
                                        readOnly = isSubmitted,
                                        label = { Text("اكتب إجابتك هنا") },
                                        singleLine = true,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("input_short_answer_${q.id}")
                                    )
                                    if (showFeedbackNow && q.correctTextAnswer.isNotBlank()) {
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Surface(
                                            shape = RoundedCornerShape(10.dp),
                                            color = StatusSuccessContainer.copy(alpha = 0.6f),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text(
                                                text = "الإجابة النموذجية: ${q.correctTextAnswer}",
                                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                                color = StatusSuccess,
                                                modifier = Modifier.padding(10.dp)
                                            )
                                        }
                                    }
                                }

                                ExamQuestion.TYPE_TRUE_FALSE -> {
                                    val tfOptions = if (q.options.size >= 2) q.options else listOf("صح", "خطأ")
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        tfOptions.forEachIndexed { optIndex, optionText ->
                                            val isChoiceSelected = selected == optIndex
                                            val isCorrectOption = optIndex == q.correctOptionIndex
                                            val borderColor = when {
                                                showFeedbackNow && isCorrectOption -> StatusSuccess
                                                showFeedbackNow && isChoiceSelected && !isCorrectOption -> StatusDanger
                                                isChoiceSelected -> AcademicBluePrimary
                                                else -> MaterialTheme.colorScheme.outline
                                            }
                                            val bgColor = when {
                                                showFeedbackNow && isCorrectOption -> StatusSuccessContainer.copy(alpha = 0.5f)
                                                showFeedbackNow && isChoiceSelected && !isCorrectOption -> StatusDangerContainer.copy(alpha = 0.5f)
                                                isChoiceSelected -> AcademicBlueContainer.copy(alpha = 0.45f)
                                                else -> MaterialTheme.colorScheme.surface
                                            }
                                            Surface(
                                                shape = RoundedCornerShape(12.dp),
                                                color = bgColor,
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .border(1.5.dp, borderColor, RoundedCornerShape(12.dp))
                                                    .clickable(enabled = !isSubmitted) {
                                                        selectedAnswers[q.id] = optIndex
                                                    }
                                                    .testTag("option_${q.id}_$optIndex")
                                            ) {
                                                Box(
                                                    modifier = Modifier.padding(vertical = 14.dp),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = optionText,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (isChoiceSelected) AcademicBluePrimary else MaterialTheme.colorScheme.onSurface
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                else -> {
                                    // MCQ Options (respects exam.shuffleOptions while preserving canonical origIdx)
                                    val optionPairs = displayOptionsMap[q.id]
                                        ?: q.options.mapIndexed { idx, txt -> idx to txt }
                                    optionPairs.forEach { (origIdx, optionText) ->
                                        val isChoiceSelected = selected == origIdx
                                        val isCorrectOption = origIdx == q.correctOptionIndex

                                        val optionBorderColor = when {
                                            showFeedbackNow && isCorrectOption -> StatusSuccess
                                            showFeedbackNow && isChoiceSelected && !isCorrectOption -> StatusDanger
                                            isChoiceSelected -> AcademicBluePrimary
                                            else -> MaterialTheme.colorScheme.outline
                                        }

                                        val optionBgColor = when {
                                            showFeedbackNow && isCorrectOption -> StatusSuccessContainer.copy(alpha = 0.5f)
                                            showFeedbackNow && isChoiceSelected && !isCorrectOption -> StatusDangerContainer.copy(alpha = 0.5f)
                                            isChoiceSelected -> AcademicBlueContainer.copy(alpha = 0.4f)
                                            else -> MaterialTheme.colorScheme.surface
                                        }

                                        Surface(
                                            shape = RoundedCornerShape(12.dp),
                                            color = optionBgColor,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 4.dp)
                                                .border(1.5.dp, optionBorderColor, RoundedCornerShape(12.dp))
                                                .clickable(enabled = !isSubmitted) {
                                                    selectedAnswers[q.id] = origIdx
                                                }
                                                .testTag("option_${q.id}_$origIdx")
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(12.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(22.dp)
                                                        .clip(CircleShape)
                                                        .border(2.dp, optionBorderColor, CircleShape)
                                                        .background(if (isChoiceSelected) AcademicBluePrimary else Color.Transparent),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    if (isChoiceSelected) {
                                                        Box(
                                                            modifier = Modifier
                                                                .size(10.dp)
                                                                .clip(CircleShape)
                                                                .background(Color.White)
                                                        )
                                                    }
                                                }
                                                Spacer(modifier = Modifier.width(10.dp))
                                                Text(
                                                    text = optionText,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            if (showFeedbackNow && q.explanation.isNotBlank()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "التوضيح النموذجي: ${q.explanation}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            if (!isSubmitted) {
                val dismissInput = rememberActiveInputDismisser()
                Spacer(modifier = Modifier.height(14.dp))
                Button(
                    onClick = {
                        dismissInput()
                        calculateAndSubmit(questions, selectedAnswers, textAnswers) { score, maxScore, json ->
                            finalScore = score
                            isSubmitted = true
                            onFinish(score, maxScore, json)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("btn_submit_exam"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary)
                ) {
                    Text(
                        text = "تسليم الإجابات وإنهاء الامتحان",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }

    if (enlargedImagePath != null) {
        SafeAlertDialog(
            onDismissRequest = { enlargedImagePath = null },
            text = {
                AsyncImage(
                    model = File(enlargedImagePath!!),
                    contentDescription = "عرض الصورة",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(340.dp)
                )
            },
            confirmButton = {
                Button(onClick = { enlargedImagePath = null }) {
                    Text("إغلاق")
                }
            }
        )
    }

    if (showConfirmDialog) {
        SafeAlertDialog(
            onDismissRequest = { showConfirmDialog = false },
            title = { Text("تأكيد الخروج من الامتحان") },
            text = { Text("هل أنت متأكد من الخروج؟ لن يتم حفظ إجاباتك ما لم تقم بتسليم الامتحان.") },
            confirmButton = {
                val dismissInput = rememberActiveInputDismisser()
                Button(
                    onClick = {
                        dismissInput()
                        showConfirmDialog = false
                        onCancel()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDanger)
                ) {
                    Text("نعم، اخرج")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showConfirmDialog = false }) {
                    Text("متابعة الحل")
                }
            }
        )
    }
}

private fun calculateAndSubmit(
    questions: List<ExamQuestion>,
    answers: Map<Int, Int>,
    textAnswers: Map<Int, String>,
    onCalculated: (score: Int, maxScore: Int, answersJson: String) -> Unit
) {
    var score = 0
    var maxScore = 0
    val json = JSONObject()

    questions.forEach { q ->
        maxScore += q.points
        if (q.questionType == ExamQuestion.TYPE_SHORT_ANSWER) {
            val typed = textAnswers[q.id].orEmpty().trim()
            json.put("text_${q.id}", typed)
            if (typed.isNotBlank() && q.correctTextAnswer.isNotBlank() &&
                ExamQuestion.normalizeShortAnswer(typed) == ExamQuestion.normalizeShortAnswer(q.correctTextAnswer)
            ) {
                score += q.points
            }
        } else {
            val selectedOpt = answers[q.id]
            if (selectedOpt != null) {
                json.put(q.id.toString(), selectedOpt)
                if (selectedOpt == q.correctOptionIndex) {
                    score += q.points
                }
            } else {
                json.put(q.id.toString(), -1)
            }
        }
    }

    onCalculated(score, maxScore, json.toString())
}

@Composable
fun StudentResourcesTab(
    viewModel: TeacherViewModel,
    student: Student
) {
    val resources by viewModel.allResources.collectAsState()
    val context = LocalContext.current

    var searchQuery by remember { mutableStateOf("") }
    var selectedTypeFilter by remember { mutableStateOf("الكل") }
    var readingResource by remember { mutableStateOf<EducationalResource?>(null) }

    val typeFilters = listOf("الكل", "PDF", "ملخص مراجعة", "فيديو شرح", "بنك أسئلة")

    val filteredResources = remember(resources, student.groupName, searchQuery, selectedTypeFilter) {
        resources.filter { res ->
            val groupMatch = res.groupName == "الكل" || res.groupName.equals(student.groupName, ignoreCase = true)
            val typeMatch = selectedTypeFilter == "الكل" || res.fileType.contains(selectedTypeFilter, ignoreCase = true)
            val queryMatch = searchQuery.isBlank() ||
                res.title.contains(searchQuery, ignoreCase = true) ||
                res.subject.contains(searchQuery, ignoreCase = true) ||
                res.description.contains(searchQuery, ignoreCase = true)
            groupMatch && typeMatch && queryMatch
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        AppHeader(
            title = "المذكرات والمصادر التعليمية",
            subtitle = "ملخصات، كتب PDF، بنوك أسئلة وروابط الشرح"
        )

        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("ابحث في المذكرات والمواد...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_student_resource_search")
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(typeFilters) { typeLabel ->
                    FilterChip(
                        selected = selectedTypeFilter == typeLabel,
                        onClick = { selectedTypeFilter = typeLabel },
                        label = { Text(typeLabel, fontSize = 11.sp) }
                    )
                }
            }
        }

        if (filteredResources.isEmpty()) {
            EmptyStateView(
                title = "لا توجد مذكرات مطابقة",
                description = if (resources.isEmpty()) "سيقوم الأستاذ بإضافة ملخصات وملفات دراسية هنا" else "جرب تغيير كلمات البحث أو نوع الملف",
                icon = Icons.Default.Description
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(filteredResources) { res ->
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .background(AcademicBlueContainer),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Description,
                                            contentDescription = null,
                                            tint = AcademicBluePrimary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = res.title,
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = "${res.subject} • ${res.groupName} • ${res.addedDate}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = AcademicBluePrimary
                                        )
                                    }
                                }
                                StatusBadge(
                                    text = res.fileType,
                                    color = AcademicBluePrimary,
                                    bgColor = AcademicBlueContainer
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = res.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            if (res.resourceContent.isNotBlank()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = res.resourceContent,
                                        maxLines = 3,
                                        style = MaterialTheme.typography.bodySmall,
                                        modifier = Modifier.padding(10.dp),
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (res.localFilePath.isNotBlank()) {
                                    Button(
                                        onClick = { QrCodeHelper.openLocalResourceFile(context, res.localFilePath) },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("btn_open_res_file_${res.id}")
                                    ) {
                                        Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("فتح الملف", fontSize = 12.sp)
                                    }
                                    IconButton(
                                        onClick = { QrCodeHelper.shareResourceFile(context, res.localFilePath, res.title) },
                                        modifier = Modifier.testTag("btn_share_res_file_${res.id}")
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = "مشاركة الملف", tint = AcademicBluePrimary)
                                    }
                                }

                                if (res.externalUrl.isNotBlank()) {
                                    Button(
                                        onClick = { QrCodeHelper.openExternalUrl(context, res.externalUrl) },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = AcademicBlueSecondary),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("btn_open_res_url_${res.id}")
                                    ) {
                                        Icon(Icons.Default.Link, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("فتح الرابط", fontSize = 12.sp)
                                    }
                                }

                                if (res.resourceContent.isNotBlank()) {
                                    OutlinedButton(
                                        onClick = { readingResource = res },
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("btn_read_res_${res.id}")
                                    ) {
                                        Icon(Icons.Default.MenuBook, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("قراءة المحتوى", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (readingResource != null) {
        val currentRes = readingResource!!
        SafeAlertDialog(
            onDismissRequest = { readingResource = null },
            title = {
                Column {
                    Text(currentRes.title, fontWeight = FontWeight.Bold)
                    Text(
                        text = "${currentRes.subject} • ${currentRes.fileType}",
                        style = MaterialTheme.typography.labelSmall,
                        color = AcademicBluePrimary
                    )
                }
            },
            text = {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 320.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (currentRes.description.isNotBlank()) {
                        item {
                            Text(
                                text = currentRes.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            HorizontalDivider(modifier = Modifier.padding(top = 6.dp))
                        }
                    }
                    item {
                        Text(
                            text = currentRes.resourceContent,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = { readingResource = null }) {
                    Text("إغلاق")
                }
            }
        )
    }
}

@Composable
fun StudentAnnouncementsTab(viewModel: TeacherViewModel) {
    val announcements by viewModel.allAnnouncements.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        AppHeader(
            title = "التنبيهات والإشعارات",
            subtitle = "إعلانات الحصص ومواعيد الاختبارات المباشرة"
        )

        if (announcements.isEmpty()) {
            EmptyStateView(
                title = "لا توجد تنبيهات جديدة",
                description = "كل التحديثات الخاصة بالحصة والواجبات ستظهر هنا فور نشرها",
                icon = Icons.Default.Campaign
            )
        } else {
            val isDark = isSystemInDarkTheme()
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(announcements) { notice ->
                    val palette = calmAnnouncementPalette(isUrgent = notice.isUrgent, isDarkTheme = isDark)
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = palette.container),
                        border = BorderStroke(1.dp, palette.border),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("card_student_announcement_${notice.id}")
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Campaign,
                                        contentDescription = null,
                                        tint = palette.iconTint,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = notice.title,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = palette.title
                                    )
                                    if (notice.isUrgent) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        StatusBadge(
                                            text = "عاجل وهام",
                                            color = palette.badgeText,
                                            bgColor = palette.badgeBg
                                        )
                                    }
                                }
                                Text(
                                    text = notice.date,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = palette.meta
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = notice.content,
                                style = MaterialTheme.typography.bodyMedium,
                                color = palette.body
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StudentReportCardTab(
    viewModel: TeacherViewModel,
    student: Student
) {
    val attendanceList by viewModel.studentAttendance.collectAsState()
    val homeworkList by viewModel.studentHomework.collectAsState()
    val submissions by viewModel.studentSubmissions.collectAsState()

    val totalAttendanceSessions = attendanceList.size
    val presentCount = attendanceList.count { it.status == com.example.data.AttendanceRecord.STATUS_PRESENT }
    val attendanceRate = if (totalAttendanceSessions > 0) (presentCount * 100) / totalAttendanceSessions else 100

    val totalHomeworkSessions = homeworkList.size
    val completedHomework = homeworkList.count { it.status == com.example.data.HomeworkRecord.STATUS_COMPLETED }
    val homeworkRate = if (totalHomeworkSessions > 0) (completedHomework * 100) / totalHomeworkSessions else 100

    val averageScore = if (submissions.isNotEmpty()) {
        submissions.sumOf { it.score } / submissions.size
    } else 18

    Column(modifier = Modifier.fillMaxSize()) {
        AppHeader(
            title = "تقرير مستوى الطالب التحليلي",
            subtitle = "نظرة تفصيلية على أداء الطالب في الحصص والاختبارات"
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Overall Rating Card
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = AcademicBluePrimary),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "التقييم العام للأداء",
                            style = MaterialTheme.typography.titleMedium,
                            color = AcademicBlueContainer
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "طالب متميز (ممتاز) ★",
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "$attendanceRate%",
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White
                                )
                                Text("نسبة الحضور", style = MaterialTheme.typography.bodySmall, color = AcademicBlueContainer)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "$homeworkRate%",
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White
                                )
                                Text("إنجاز الواجبات", style = MaterialTheme.typography.bodySmall, color = AcademicBlueContainer)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "$averageScore / 20",
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White
                                )
                                Text("متوسط الاختبارات", style = MaterialTheme.typography.bodySmall, color = AcademicBlueContainer)
                            }
                        }
                    }
                }
            }

            // Attendance Progress
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("معدل الالتزام بالحضور", fontWeight = FontWeight.Bold)
                            Text("$attendanceRate%", color = StatusSuccess, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { attendanceRate / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = StatusSuccess,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "حضر $presentCount من إجمالي $totalAttendanceSessions حصة مسجلة",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Homework Progress
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("معدل تسليم الواجبات المنزلية", fontWeight = FontWeight.Bold)
                            Text("$homeworkRate%", color = AcademicBluePrimary, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { homeworkRate / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = AcademicBluePrimary,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "تم تسليم $completedHomework من إجمالي $totalHomeworkSessions واجب",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
