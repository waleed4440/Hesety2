package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AttendanceRecord
import com.example.data.Exam
import com.example.data.ExamSubmission
import com.example.data.HomeworkRecord
import com.example.data.ParentNote
import com.example.data.PaymentRecord
import com.example.data.Student
import com.example.ui.TeacherViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.EmptyStateView
import com.example.ui.components.PaymentBadge
import com.example.ui.components.QuickParentContactDialog
import com.example.ui.components.SafeAlertDialog
import com.example.ui.components.VoiceNotePlayerBar
import com.example.ui.theme.AcademicBlueContainer
import com.example.ui.theme.AcademicBluePrimary
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusDangerContainer
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessContainer
import com.example.ui.theme.StatusWarning
import com.example.util.AudioNoteHelper
import com.example.util.ParentCommunicationHelper
import com.example.util.ParentMessageTemplate
import com.example.util.PdfReportExporter
import com.example.util.StudentGuardianSnapshot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private sealed class PdfExportTarget {
    data class SingleStudent(val student: Student) : PdfExportTarget()
    data class GroupSummary(val groupName: String, val students: List<Student>) : PdfExportTarget()
}

@Composable
fun TeacherReportsScreen(
    viewModel: TeacherViewModel,
    modifier: Modifier = Modifier
) {
    val students by viewModel.allStudents.collectAsState()
    val allPayments by viewModel.allPayments.collectAsState()
    val allNotes by viewModel.allNotes.collectAsState()
    val allAttendances by viewModel.allAttendances.collectAsState()
    val allHomework by viewModel.allHomework.collectAsState()
    val allSubmissions by viewModel.allSubmissions.collectAsState()
    val allExams by viewModel.allExams.collectAsState()
    val sessionDate by viewModel.selectedSessionDate.collectAsState()
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var searchQuery by remember { mutableStateOf("") }
    var selectedGroupFilter by remember { mutableStateOf("الكل") }
    var noteTargetStudent by remember { mutableStateOf<Student?>(null) }
    var pdfExportTarget by remember { mutableStateOf<PdfExportTarget?>(null) }
    var historyPreviewStudent by remember { mutableStateOf<Student?>(null) }
    var pendingSaveTarget by remember { mutableStateOf<PdfExportTarget?>(null) }
    var isExportingPdf by remember { mutableStateOf(false) }
    var quickContactSnapshot by remember { mutableStateOf<StudentGuardianSnapshot?>(null) }

    val distinctGroups = listOf("الكل") + students.map { it.groupName }.distinct()
    val filteredStudents = students.filter { s ->
        val matchesSearch = s.name.contains(searchQuery, ignoreCase = true) || s.code.contains(searchQuery, ignoreCase = true)
        val matchesGroup = selectedGroupFilter == "الكل" || s.groupName == selectedGroupFilter
        matchesSearch && matchesGroup
    }

    val createPdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        val target = pendingSaveTarget
        pendingSaveTarget = null
        if (uri != null && target != null) {
            isExportingPdf = true
            coroutineScope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        context.contentResolver.openOutputStream(uri)?.use { out ->
                            when (target) {
                                is PdfExportTarget.SingleStudent -> {
                                    val st = target.student
                                    PdfReportExporter.exportStudentReportPdf(
                                        outputStream = out,
                                        student = st,
                                        attendances = allAttendances.filter { it.studentId == st.id },
                                        homework = allHomework.filter { it.studentId == st.id },
                                        submissions = allSubmissions.filter { it.studentId == st.id },
                                        exams = allExams,
                                        payments = allPayments.filter { it.studentId == st.id },
                                        notes = allNotes.filter { it.studentId == st.id }
                                    )
                                }
                                is PdfExportTarget.GroupSummary -> {
                                    PdfReportExporter.exportGroupReportPdf(
                                        outputStream = out,
                                        groupName = target.groupName,
                                        students = target.students,
                                        allAttendances = allAttendances,
                                        allHomework = allHomework,
                                        allSubmissions = allSubmissions,
                                        allExams = allExams,
                                        allPayments = allPayments,
                                        allNotes = allNotes
                                    )
                                }
                            }
                        } ?: error("تعذر فتح مسار الحفظ المحدد")
                    }
                }
                isExportingPdf = false
                if (result.isSuccess) {
                    Toast.makeText(context, "تم حفظ ملف PDF بنجاح", Toast.LENGTH_LONG).show()
                    pdfExportTarget = null
                } else {
                    Toast.makeText(
                        context,
                        "فشل حفظ ملف PDF: ${result.exceptionOrNull()?.localizedMessage ?: "خطأ غير معروف"}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
    ) {
        AppHeader(
            title = "تقارير الأداء وملاحظات أولياء الأمور",
            subtitle = "تحليلات الحضور، الواجبات، درجات الاختبارات، وتصدير PDF"
        )

        // Search Bar
        Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("بحث عن طالب لإنشاء أو تصدير تقرير...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_reports_input")
            )
        }

        // Group Filter + Export Group PDF Button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            LazyRow(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(distinctGroups) { grp ->
                    FilterChip(
                        selected = selectedGroupFilter == grp,
                        onClick = { selectedGroupFilter = grp },
                        label = { Text(grp) }
                    )
                }
            }

            if (filteredStudents.isNotEmpty()) {
                Button(
                    onClick = {
                        pdfExportTarget = PdfExportTarget.GroupSummary(
                            groupName = selectedGroupFilter,
                            students = filteredStudents
                        )
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB91C1C)),
                    modifier = Modifier.testTag("btn_export_group_pdf")
                ) {
                    Icon(
                        imageVector = Icons.Default.PictureAsPdf,
                        contentDescription = "تصدير الكل PDF",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("تصدير PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (filteredStudents.isEmpty()) {
            EmptyStateView(
                title = "لا توجد نتائج مطابقة",
                description = "جرب البحث باسم آخر",
                icon = Icons.Default.Person
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(filteredStudents) { student ->
                    val studentNotes = allNotes.filter { it.studentId == student.id }
                    val latestNote = studentNotes.firstOrNull()

                    val isPaid = allPayments.firstOrNull { it.studentId == student.id }?.isPaid ?: false
                    val studentSubmissions = allSubmissions.filter { it.studentId == student.id }
                    val latestSubmission = studentSubmissions.firstOrNull()
                    val examGrade = if (latestSubmission != null) "${latestSubmission.score}/${latestSubmission.maxScore}" else "لم ترصد بعد"

                    val studentAttendances = allAttendances.filter { it.studentId == student.id }
                    val attendancePercent = if (studentAttendances.isNotEmpty()) {
                        val presentCount = studentAttendances.count {
                            it.status == AttendanceRecord.STATUS_PRESENT || it.status == AttendanceRecord.STATUS_LATE
                        }
                        "${(presentCount * 100) / studentAttendances.size}%"
                    } else {
                        "100%"
                    }
                    val studentHomework = allHomework.filter { it.studentId == student.id }
                    val homeworkPercent = if (studentHomework.isNotEmpty()) {
                        val hwDoneCount = studentHomework.count {
                            it.status == HomeworkRecord.STATUS_COMPLETED || it.status == HomeworkRecord.STATUS_PARTIAL
                        }
                        "${(hwDoneCount * 100) / studentHomework.size}%"
                    } else {
                        "100%"
                    }

                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(CircleShape)
                                            .background(AcademicBlueContainer),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Person,
                                            contentDescription = null,
                                            tint = AcademicBluePrimary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = student.name,
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Text(
                                            text = "${student.code} • ${student.groupName}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                PaymentBadge(isPaid = isPaid)
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Analytical Metrics Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = StatusSuccessContainer.copy(alpha = 0.5f),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text("نسبة الحضور", style = MaterialTheme.typography.labelSmall, color = StatusSuccess)
                                        Text(attendancePercent, fontWeight = FontWeight.Bold, color = StatusSuccess)
                                    }
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = AcademicBlueContainer.copy(alpha = 0.5f),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text("حل الواجب", style = MaterialTheme.typography.labelSmall, color = AcademicBluePrimary)
                                        Text(homeworkPercent, fontWeight = FontWeight.Bold, color = AcademicBluePrimary)
                                    }
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = Color(0xFFFEF3C7),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text("آخر امتحان", style = MaterialTheme.typography.labelSmall, color = Color(0xFF92400E))
                                        Text(examGrade, fontWeight = FontWeight.Bold, color = Color(0xFF92400E))
                                    }
                                }
                            }

                            // Guardian Note Card (Written + Voice Note)
                            Spacer(modifier = Modifier.height(10.dp))
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = "ملاحظة المعلم لولي الأمر:",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = AcademicBluePrimary
                                    )
                                    if (latestNote == null) {
                                        Text(
                                            text = "لا توجد ملاحظة حالية، أداء الطالب مستقر وجيد.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    } else {
                                        if (latestNote.content.isNotBlank()) {
                                            Text(
                                                text = latestNote.content,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                        if (latestNote.hasAudio()) {
                                            VoiceNotePlayerBar(
                                                audioPath = latestNote.audioFilePath,
                                                durationSeconds = latestNote.audioDurationSeconds,
                                                label = "ملاحظة صوتية لولي الأمر",
                                                showShareButton = true,
                                                onShareClick = {
                                                    AudioNoteHelper.shareVoiceNote(
                                                        context = context,
                                                        audioPath = latestNote.audioFilePath,
                                                        studentName = student.name,
                                                        writtenText = latestNote.content
                                                    )
                                                }
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Action Row 1: Note + Attendance History Preview
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { noteTargetStudent = student },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("btn_note_report_${student.id}"),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Default.NoteAdd, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("تعديل الملاحظة", fontSize = 11.sp)
                                }

                                OutlinedButton(
                                    onClick = { historyPreviewStudent = student },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("btn_history_${student.id}"),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("سجل الحضور (${studentAttendances.size})", fontSize = 11.sp)
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Action Row 2: Share Text + Export PDF
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        quickContactSnapshot = ParentCommunicationHelper.buildSnapshot(
                                            student = student,
                                            allAttendances = allAttendances,
                                            allHomework = allHomework,
                                            allPayments = allPayments,
                                            allSubmissions = allSubmissions,
                                            allExams = allExams,
                                            allNotes = allNotes,
                                            sessionDate = sessionDate
                                        )
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("btn_share_report_${student.id}"),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("إرسال لولي الأمر", fontSize = 11.sp)
                                }

                                Button(
                                    onClick = { pdfExportTarget = PdfExportTarget.SingleStudent(student) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("btn_export_pdf_${student.id}"),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB91C1C))
                                ) {
                                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("تصدير PDF", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (noteTargetStudent != null) {
        AddParentNoteDialog(
            student = noteTargetStudent!!,
            onDismiss = { noteTargetStudent = null },
            onSave = { title, content, audioPath, audioDuration ->
                viewModel.addParentNote(
                    studentId = noteTargetStudent!!.id,
                    title = title,
                    content = content,
                    audioFilePath = audioPath,
                    audioDurationSeconds = audioDuration
                )
                noteTargetStudent = null
                Toast.makeText(context, "تم حفظ الملاحظة بنجاح", Toast.LENGTH_SHORT).show()
            }
        )
    }

    if (quickContactSnapshot != null) {
        QuickParentContactDialog(
            snapshot = quickContactSnapshot!!,
            initialTemplate = ParentMessageTemplate.FULL_REPORT,
            onDismiss = { quickContactSnapshot = null }
        )
    }

    if (historyPreviewStudent != null) {
        val st = historyPreviewStudent!!
        val stAttendances = allAttendances.filter { it.studentId == st.id }.sortedByDescending { it.date }
        val stHomework = allHomework.filter { it.studentId == st.id }.associateBy { it.date }
        AttendanceHistoryDialog(
            student = st,
            attendances = stAttendances,
            homeworkByDate = stHomework,
            onExportPdf = {
                historyPreviewStudent = null
                pdfExportTarget = PdfExportTarget.SingleStudent(st)
            },
            onDismiss = { historyPreviewStudent = null }
        )
    }

    if (pdfExportTarget != null) {
        val target = pdfExportTarget!!
        PdfExportOptionsDialog(
            target = target,
            allAttendances = allAttendances,
            allHomework = allHomework,
            allSubmissions = allSubmissions,
            allExams = allExams,
            allPayments = allPayments,
            allNotes = allNotes,
            isExporting = isExportingPdf,
            onSaveToDevice = { suggestedFileName ->
                pendingSaveTarget = target
                createPdfLauncher.launch(suggestedFileName)
            },
            onSharePdf = {
                isExportingPdf = true
                coroutineScope.launch {
                    val fileResult = withContext(Dispatchers.IO) {
                        runCatching {
                            generateCachePdf(
                                context = context,
                                target = target,
                                allAttendances = allAttendances,
                                allHomework = allHomework,
                                allSubmissions = allSubmissions,
                                allExams = allExams,
                                allPayments = allPayments,
                                allNotes = allNotes
                            )
                        }
                    }
                    isExportingPdf = false
                    fileResult.onSuccess { file ->
                        PdfReportExporter.sharePdfFile(context, file, "مشاركة تقرير PDF")
                        pdfExportTarget = null
                    }.onFailure { err ->
                        Toast.makeText(context, "تعذر إنشاء PDF: ${err.localizedMessage}", Toast.LENGTH_LONG).show()
                    }
                }
            },
            onOpenPdf = {
                isExportingPdf = true
                coroutineScope.launch {
                    val fileResult = withContext(Dispatchers.IO) {
                        runCatching {
                            generateCachePdf(
                                context = context,
                                target = target,
                                allAttendances = allAttendances,
                                allHomework = allHomework,
                                allSubmissions = allSubmissions,
                                allExams = allExams,
                                allPayments = allPayments,
                                allNotes = allNotes
                            )
                        }
                    }
                    isExportingPdf = false
                    fileResult.onSuccess { file ->
                        PdfReportExporter.openPdfFile(context, file)
                    }.onFailure { err ->
                        Toast.makeText(context, "تعذر فتح PDF: ${err.localizedMessage}", Toast.LENGTH_LONG).show()
                    }
                }
            },
            onDismiss = { if (!isExportingPdf) pdfExportTarget = null }
        )
    }
}

private fun generateCachePdf(
    context: android.content.Context,
    target: PdfExportTarget,
    allAttendances: List<AttendanceRecord>,
    allHomework: List<HomeworkRecord>,
    allSubmissions: List<ExamSubmission>,
    allExams: List<Exam>,
    allPayments: List<PaymentRecord>,
    allNotes: List<ParentNote>
) = when (target) {
    is PdfExportTarget.SingleStudent -> {
        val st = target.student
        PdfReportExporter.createStudentReportPdfFile(
            context = context,
            student = st,
            attendances = allAttendances.filter { it.studentId == st.id },
            homework = allHomework.filter { it.studentId == st.id },
            submissions = allSubmissions.filter { it.studentId == st.id },
            exams = allExams,
            payments = allPayments.filter { it.studentId == st.id },
            notes = allNotes.filter { it.studentId == st.id }
        )
    }
    is PdfExportTarget.GroupSummary -> {
        PdfReportExporter.createGroupReportPdfFile(
            context = context,
            groupName = target.groupName,
            students = target.students,
            allAttendances = allAttendances,
            allHomework = allHomework,
            allSubmissions = allSubmissions,
            allExams = allExams,
            allPayments = allPayments,
            allNotes = allNotes
        )
    }
}

@Composable
private fun AttendanceHistoryDialog(
    student: Student,
    attendances: List<AttendanceRecord>,
    homeworkByDate: Map<String, HomeworkRecord>,
    onExportPdf: () -> Unit,
    onDismiss: () -> Unit
) {
    SafeAlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("سجل الحضور والواجبات", fontWeight = FontWeight.Bold)
                Text(
                    text = "${student.name} (${student.code})",
                    style = MaterialTheme.typography.bodySmall,
                    color = AcademicBluePrimary
                )
            }
        },
        text = {
            if (attendances.isEmpty()) {
                Text(
                    text = "لا توجد سجلات حضور مسجلة لهذا الطالب حتى الآن.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 300.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(attendances) { att ->
                        val hw = homeworkByDate[att.date]
                        val attLabel = when (att.status) {
                            AttendanceRecord.STATUS_PRESENT -> "حاضر"
                            AttendanceRecord.STATUS_ABSENT -> "غائب"
                            AttendanceRecord.STATUS_LATE -> "متأخر"
                            AttendanceRecord.STATUS_EXCUSED -> "بعذر"
                            else -> att.status
                        }
                        val attColor = when (att.status) {
                            AttendanceRecord.STATUS_PRESENT -> StatusSuccess
                            AttendanceRecord.STATUS_ABSENT -> StatusDanger
                            else -> StatusWarning
                        }
                        val hwLabel = when (hw?.status) {
                            HomeworkRecord.STATUS_COMPLETED -> "الواجب: تم الحل"
                            HomeworkRecord.STATUS_NOT_COMPLETED -> "الواجب: لم يُحل"
                            HomeworkRecord.STATUS_PARTIAL -> "الواجب: جزئي"
                            else -> "الواجب: غير مسجل"
                        }

                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "📅 ${att.date}",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = attColor.copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = attLabel,
                                            color = attColor,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = hwLabel,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (att.notes.isNotBlank()) {
                                    Text(
                                        text = "ملاحظة: ${att.notes}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onExportPdf,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB91C1C))
            ) {
                Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("تصدير كـ PDF")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("إغلاق")
            }
        }
    )
}

@Composable
private fun PdfExportOptionsDialog(
    target: PdfExportTarget,
    allAttendances: List<AttendanceRecord>,
    allHomework: List<HomeworkRecord>,
    allSubmissions: List<ExamSubmission>,
    allExams: List<Exam>,
    allPayments: List<PaymentRecord>,
    allNotes: List<ParentNote>,
    isExporting: Boolean,
    onSaveToDevice: (String) -> Unit,
    onSharePdf: () -> Unit,
    onOpenPdf: () -> Unit,
    onDismiss: () -> Unit
) {
    val titleText: String
    val subtitleText: String
    val summaryDetails: String
    val suggestedFileName: String

    when (target) {
        is PdfExportTarget.SingleStudent -> {
            val st = target.student
            val attCount = allAttendances.count { it.studentId == st.id }
            val hwCount = allHomework.count { it.studentId == st.id }
            val examCount = allSubmissions.count { it.studentId == st.id }
            val noteCount = allNotes.count { it.studentId == st.id }
            titleText = "تصدير تقرير الطالب PDF"
            subtitleText = "${st.name} (${st.code})"
            summaryDetails = "يتضمن التقرير:\n• ملخص الأداء والمصروفات\n• سجل الحضور الكامل ($attCount حصة) والواجبات ($hwCount)\n• درجات الامتحانات ($examCount) وملاحظات ولي الأمر ($noteCount)"
            suggestedFileName = "تقرير_${st.name}_${st.code}.pdf"
        }
        is PdfExportTarget.GroupSummary -> {
            titleText = "تصدير التقرير الشامل PDF"
            subtitleText = "المجموعة: ${target.groupName} (${target.students.size} طالب)"
            summaryDetails = "يتضمن التقرير ملخصاً كاملاً لجميع الطلاب المصفّين: نسب الحضور، تسليم الواجبات، درجات آخر امتحان، حالة المصروفات، والملاحظات."
            suggestedFileName = "تقرير_الطلاب_${target.groupName}.pdf"
        }
    }

    SafeAlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(StatusDangerContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PictureAsPdf,
                        contentDescription = null,
                        tint = Color(0xFFB91C1C),
                        modifier = Modifier.size(20.dp)
                    )
                }
                Column {
                    Text(titleText, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Text(subtitleText, style = MaterialTheme.typography.bodySmall, color = AcademicBluePrimary)
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = summaryDetails,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(12.dp)
                    )
                }

                HorizontalDivider()

                Button(
                    onClick = { onSaveToDevice(suggestedFileName) },
                    enabled = !isExporting,
                    colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_pdf_save_device")
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("حفظ ملف PDF على الجهاز")
                }

                Button(
                    onClick = onSharePdf,
                    enabled = !isExporting,
                    colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_pdf_share")
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("مشاركة ملف PDF (واتساب / بريد)")
                }

                OutlinedButton(
                    onClick = onOpenPdf,
                    enabled = !isExporting,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_pdf_preview")
                ) {
                    Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("معاينة وفتح ملف PDF")
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            OutlinedButton(onClick = onDismiss, enabled = !isExporting) {
                Text("إغلاق")
            }
        }
    )
}
