package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AttendanceRecord
import com.example.data.Exam
import com.example.data.ExamSubmission
import com.example.data.HomeworkRecord
import com.example.data.ParentNote
import com.example.data.PaymentRecord
import com.example.data.Student
import com.example.ui.theme.AcademicBlueContainer
import com.example.ui.theme.AcademicBluePrimary
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusDangerContainer
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessContainer
import com.example.ui.theme.StatusWarningContainer
import com.example.util.ParentCommunicationHelper
import com.example.util.ParentMessageTemplate
import com.example.util.StudentGuardianSnapshot

private val WhatsAppGreen = Color(0xFF15803D)

@Composable
fun QuickParentContactDialog(
    snapshot: StudentGuardianSnapshot,
    initialTemplate: ParentMessageTemplate = ParentMessageTemplate.FULL_REPORT,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val student = snapshot.student
    val hasValidPhone = remember(student.parentPhone) {
        ParentCommunicationHelper.normalizeDialPhone(student.parentPhone) != null
    }

    var selectedTemplate by remember(student.id, initialTemplate) {
        mutableStateOf(initialTemplate)
    }
    var messageText by remember(student.id, initialTemplate) {
        mutableStateOf(ParentCommunicationHelper.buildTemplateMessage(initialTemplate, snapshot))
    }

    SafeAlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("dialog_quick_parent_contact"),
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "التواصل السريع مع ولي الأمر",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "${student.name} • ${student.groupName}",
                    style = MaterialTheme.typography.bodySmall,
                    color = AcademicBluePrimary,
                    fontWeight = FontWeight.SemiBold
                )
            }
        },
        text = {
            val dismissInput = rememberActiveInputDismisser()
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (hasValidPhone) AcademicBlueContainer.copy(alpha = 0.7f) else StatusWarningContainer
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (hasValidPhone) Icons.Default.Phone else Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (hasValidPhone) AcademicBluePrimary else Color(0xFF92400E),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (hasValidPhone) {
                                "رقم ولي الأمر: ${student.parentPhone}"
                            } else {
                                "لا يوجد رقم هاتف صحيح مسجل — يمكنك التعديل أو المشاركة عبر التطبيقات"
                            },
                            style = MaterialTheme.typography.labelMedium,
                            color = if (hasValidPhone) AcademicBluePrimary else Color(0xFF92400E)
                        )
                    }
                }

                Text(
                    text = "اختر قالب الرسالة الجاهز:",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(ParentMessageTemplate.entries) { template ->
                        FilterChip(
                            selected = selectedTemplate == template,
                            onClick = {
                                selectedTemplate = template
                                messageText = ParentCommunicationHelper.buildTemplateMessage(template, snapshot)
                            },
                            label = { Text(template.label, fontSize = 11.sp) },
                            modifier = Modifier.testTag("chip_template_${template.name}")
                        )
                    }
                }

                OutlinedTextField(
                    value = messageText,
                    onValueChange = { messageText = it },
                    label = { Text("نص الرسالة (قابل للتعديل)") },
                    minLines = 5,
                    maxLines = 9,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_parent_message")
                )

                // Direct communication actions
                Button(
                    onClick = {
                        dismissInput()
                        ParentCommunicationHelper.openWhatsApp(context, student.parentPhone, messageText)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("btn_send_whatsapp_direct")
                ) {
                    Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("إرسال مباشر عبر واتساب", fontWeight = FontWeight.Bold)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            dismissInput()
                            ParentCommunicationHelper.dialParent(context, student.parentPhone)
                        },
                        enabled = hasValidPhone,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("btn_dial_parent")
                    ) {
                        Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("اتصال", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            dismissInput()
                            ParentCommunicationHelper.sendSms(context, student.parentPhone, messageText)
                        },
                        enabled = hasValidPhone,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("btn_send_sms_parent")
                    ) {
                        Icon(Icons.Default.Sms, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("SMS", fontSize = 12.sp)
                    }
                }

                TextButton(
                    onClick = {
                        dismissInput()
                        ParentCommunicationHelper.shareViaOtherApps(context, messageText)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("btn_share_other_parent")
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("مشاركة عبر تطبيق آخر", fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            val dismissInput = rememberActiveInputDismisser()
            OutlinedButton(onClick = {
                dismissInput()
                onDismiss()
            }) {
                Text("إغلاق")
            }
        }
    )
}

private enum class QuickPickerFilter(val label: String) {
    ALL("الكل"),
    ABSENT_TODAY("غائب اليوم"),
    UNPAID("لم يسدد")
}

@Composable
fun QuickParentPickerDialog(
    students: List<Student>,
    allAttendances: List<AttendanceRecord>,
    allHomework: List<HomeworkRecord>,
    allPayments: List<PaymentRecord>,
    allSubmissions: List<ExamSubmission>,
    allExams: List<Exam>,
    allNotes: List<ParentNote>,
    sessionDate: String,
    onSelectStudent: (StudentGuardianSnapshot, ParentMessageTemplate) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var activeFilter by remember { mutableStateOf(QuickPickerFilter.ALL) }

    val todayAbsentIds = remember(allAttendances, sessionDate) {
        allAttendances
            .filter { it.date == sessionDate && it.status == AttendanceRecord.STATUS_ABSENT }
            .map { it.studentId }
            .toSet()
    }
    val paidIds = remember(allPayments) {
        allPayments.filter { it.isPaid }.map { it.studentId }.toSet()
    }

    val filtered = remember(students, searchQuery, activeFilter, todayAbsentIds, paidIds) {
        students.filter { st ->
            val matchesQuery = searchQuery.isBlank() ||
                st.name.contains(searchQuery, ignoreCase = true) ||
                st.code.contains(searchQuery, ignoreCase = true) ||
                st.parentPhone.contains(searchQuery, ignoreCase = true)
            val matchesFilter = when (activeFilter) {
                QuickPickerFilter.ALL -> true
                QuickPickerFilter.ABSENT_TODAY -> st.id in todayAbsentIds
                QuickPickerFilter.UNPAID -> st.id !in paidIds
            }
            matchesQuery && matchesFilter
        }
    }

    SafeAlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("dialog_quick_parent_picker"),
        title = {
            Column {
                Text(
                    text = "مركز التواصل السريع مع أولياء الأمور",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "اتصال مباشر أو رسالة واتساب جاهزة ببيانات الطالب الفعلية",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("ابحث بالاسم أو الكود أو الهاتف...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "مسح البحث")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_search_parent_picker")
                )

                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(QuickPickerFilter.entries) { filter ->
                        val count = when (filter) {
                            QuickPickerFilter.ALL -> students.size
                            QuickPickerFilter.ABSENT_TODAY -> students.count { it.id in todayAbsentIds }
                            QuickPickerFilter.UNPAID -> students.count { it.id !in paidIds }
                        }
                        FilterChip(
                            selected = activeFilter == filter,
                            onClick = { activeFilter = filter },
                            label = { Text("${filter.label} ($count)", fontSize = 11.sp) }
                        )
                    }
                }

                if (filtered.isEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "لا يوجد طلاب مطابقون للبحث أو التصفية الحالية.",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 340.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filtered, key = { it.id }) { student ->
                            val isAbsentToday = student.id in todayAbsentIds
                            val isPaid = student.id in paidIds
                            val hasPhone = ParentCommunicationHelper.normalizeDialPhone(student.parentPhone) != null
                            val defaultTemplate = when {
                                activeFilter == QuickPickerFilter.ABSENT_TODAY || isAbsentToday ->
                                    ParentMessageTemplate.ABSENCE_ALERT
                                activeFilter == QuickPickerFilter.UNPAID || !isPaid ->
                                    ParentMessageTemplate.PAYMENT_REMINDER
                                else -> ParentMessageTemplate.FULL_REPORT
                            }

                            val snapshot = remember(student, allAttendances, allHomework, allPayments, allSubmissions, allExams, allNotes, sessionDate) {
                                ParentCommunicationHelper.buildSnapshot(
                                    student = student,
                                    allAttendances = allAttendances,
                                    allHomework = allHomework,
                                    allPayments = allPayments,
                                    allSubmissions = allSubmissions,
                                    allExams = allExams,
                                    allNotes = allNotes,
                                    sessionDate = sessionDate
                                )
                            }

                            Card(
                                onClick = { onSelectStudent(snapshot, defaultTemplate) },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("picker_parent_item_${student.id}")
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    if (isAbsentToday) StatusDangerContainer else AcademicBlueContainer
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Person,
                                                contentDescription = null,
                                                tint = if (isAbsentToday) StatusDanger else AcademicBluePrimary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(
                                                text = student.name,
                                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                            )
                                            Text(
                                                text = student.parentPhone.ifBlank { "بدون رقم مسجل" },
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        if (hasPhone) {
                                            IconButton(
                                                onClick = {
                                                    ParentCommunicationHelper.dialParent(context, student.parentPhone)
                                                },
                                                modifier = Modifier.size(48.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Call,
                                                    contentDescription = "اتصال بولي أمر ${student.name}",
                                                    tint = AcademicBluePrimary,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                        }
                                        IconButton(
                                            onClick = { onSelectStudent(snapshot, defaultTemplate) },
                                            modifier = Modifier.size(48.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.Send,
                                                contentDescription = "إرسال رسالة لولي أمر ${student.name}",
                                                tint = WhatsAppGreen,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            val dismissInput = rememberActiveInputDismisser()
            Button(
                onClick = {
                    dismissInput()
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary)
            ) {
                Text("إغلاق")
            }
        }
    )
}
