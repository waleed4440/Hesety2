package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.TeacherTab
import com.example.ui.TeacherViewModel
import com.example.ui.components.ClearInputFocusEffect
import com.example.ui.components.rememberActiveInputDismisser

@Composable
fun TeacherMainScreen(
    viewModel: TeacherViewModel,
    modifier: Modifier = Modifier
) {
    val currentTab by viewModel.teacherTab.collectAsState()
    val dismissInput = rememberActiveInputDismisser()

    ClearInputFocusEffect(currentTab)

    BackHandler(enabled = currentTab != TeacherTab.DASHBOARD) {
        dismissInput()
        viewModel.setTeacherTab(TeacherTab.DASHBOARD)
    }

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                NavigationBarItem(
                    selected = currentTab == TeacherTab.DASHBOARD,
                    onClick = {
                        dismissInput()
                        viewModel.setTeacherTab(TeacherTab.DASHBOARD)
                    },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = "الرئيسية") },
                    label = { Text("الرئيسية") },
                    modifier = Modifier.testTag("nav_teacher_dash")
                )
                NavigationBarItem(
                    selected = currentTab == TeacherTab.STUDENTS,
                    onClick = {
                        dismissInput()
                        viewModel.setTeacherTab(TeacherTab.STUDENTS)
                    },
                    icon = { Icon(Icons.Default.Group, contentDescription = "الطلاب") },
                    label = { Text("الطلاب") },
                    modifier = Modifier.testTag("nav_teacher_students")
                )
                NavigationBarItem(
                    selected = currentTab == TeacherTab.SESSION_LOG,
                    onClick = {
                        dismissInput()
                        viewModel.setTeacherTab(TeacherTab.SESSION_LOG)
                    },
                    icon = { Icon(Icons.Default.CheckCircle, contentDescription = "تسجيل الحصة") },
                    label = { Text("الحصة") },
                    modifier = Modifier.testTag("nav_teacher_session")
                )
                NavigationBarItem(
                    selected = currentTab == TeacherTab.EXAMS,
                    onClick = {
                        dismissInput()
                        viewModel.setTeacherTab(TeacherTab.EXAMS)
                    },
                    icon = { Icon(Icons.Default.Quiz, contentDescription = "الامتحانات") },
                    label = { Text("الامتحانات") },
                    modifier = Modifier.testTag("nav_teacher_exams")
                )
                NavigationBarItem(
                    selected = currentTab == TeacherTab.RESOURCES,
                    onClick = {
                        dismissInput()
                        viewModel.setTeacherTab(TeacherTab.RESOURCES)
                    },
                    icon = { Icon(Icons.Default.Description, contentDescription = "المصادر") },
                    label = { Text("المصادر") },
                    modifier = Modifier.testTag("nav_teacher_resources")
                )
                NavigationBarItem(
                    selected = currentTab == TeacherTab.REPORTS,
                    onClick = {
                        dismissInput()
                        viewModel.setTeacherTab(TeacherTab.REPORTS)
                    },
                    icon = { Icon(Icons.Default.Star, contentDescription = "التقارير") },
                    label = { Text("التقارير") },
                    modifier = Modifier.testTag("nav_teacher_reports")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .consumeWindowInsets(innerPadding)
                .imePadding()
        ) {
            when (currentTab) {
                TeacherTab.DASHBOARD -> TeacherDashboardScreen(
                    viewModel = viewModel,
                    onNavigateToTab = { tab -> viewModel.setTeacherTab(tab) },
                    onAddNewStudent = {
                        viewModel.setTeacherTab(TeacherTab.STUDENTS)
                    },
                    onCreateExam = {
                        viewModel.setTeacherTab(TeacherTab.EXAMS)
                    }
                )
                TeacherTab.STUDENTS -> TeacherStudentsScreen(viewModel = viewModel)
                TeacherTab.SESSION_LOG -> TeacherAttendanceScreen(viewModel = viewModel)
                TeacherTab.SCHEDULE -> TeacherScheduleScreen(viewModel = viewModel)
                TeacherTab.EXAMS -> TeacherExamsScreen(viewModel = viewModel)
                TeacherTab.MISTAKE_BANK -> MistakeBankScreen(
                    viewModel = viewModel,
                    isTeacher = true,
                    onBack = { viewModel.setTeacherTab(TeacherTab.EXAMS) },
                    onRemedialExamCreated = { viewModel.setTeacherTab(TeacherTab.EXAMS) }
                )
                TeacherTab.RESOURCES -> TeacherResourcesScreen(viewModel = viewModel)
                TeacherTab.ANNOUNCEMENTS -> TeacherAnnouncementsScreen(viewModel = viewModel)
                TeacherTab.REPORTS -> TeacherReportsScreen(viewModel = viewModel)
                TeacherTab.QA_CORNER -> AskTeacherScreen(
                    viewModel = viewModel,
                    isTeacher = true,
                    onBack = { viewModel.setTeacherTab(TeacherTab.DASHBOARD) }
                )
            }
        }
    }
}
