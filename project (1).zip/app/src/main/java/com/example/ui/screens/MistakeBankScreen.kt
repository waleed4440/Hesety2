package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.BookmarkAdded
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ExamQuestion
import com.example.data.MistakeRecord
import com.example.data.Student
import com.example.ui.TeacherViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.EmptyStateView
import com.example.ui.components.SafeAlertDialog
import com.example.ui.components.StatusBadge
import com.example.ui.components.rememberActiveInputDismisser
import com.example.ui.theme.AcademicBlueContainer
import com.example.ui.theme.AcademicBluePrimary
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusDangerContainer
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessContainer
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningContainer

@Composable
fun MistakeBankScreen(
    viewModel: TeacherViewModel,
    isTeacher: Boolean,
    currentStudent: Student? = null,
    initialExamFilterId: Long? = null,
    onBack: () -> Unit,
    onRemedialExamCreated: () -> Unit = {}
) {
    BackHandler { onBack() }

    val context = LocalContext.current
    val allStudents by viewModel.allStudents.collectAsState()
    val allExams by viewModel.allExams.collectAsState()
    val allMistakes by viewModel.allMistakes.collectAsState()
    val studentMistakes by viewModel.studentMistakes.collectAsState()
    val groups by viewModel.allGroups.collectAsState()

    val rawMistakes = if (isTeacher) {
        val activeIds = remember(allStudents) { allStudents.map { it.id }.toSet() }
        allMistakes.filter { it.studentId in activeIds }
    } else {
        // Respect unreleased exam results so students cannot peek at answers before teacher releases them
        studentMistakes.filter { m ->
            if (m.examId == 0L) true
            else {
                val exam = allExams.firstOrNull { it.id == m.examId }
                exam == null || exam.showResultImmediately || !exam.isActive
            }
        }
    }

    var masteryFilter by remember { mutableStateOf("الكل") } // "الكل", "غير متقن", "تم الإتقان"
    var subjectFilter by remember { mutableStateOf("الكل") }
    var searchQuery by remember { mutableStateOf("") }
    var examFilterId by remember(initialExamFilterId) { mutableStateOf(initialExamFilterId) }

    var showAddDialog by remember { mutableStateOf(false) }
    var practiceQueue by remember { mutableStateOf<List<MistakeRecord>>(emptyList()) }
    var editingNoteTarget by remember { mutableStateOf<MistakeRecord?>(null) }
    var showRemedialDialog by remember { mutableStateOf(false) }

    val availableSubjects = remember(rawMistakes) {
        listOf("الكل") + rawMistakes.map { it.subject.ifBlank { "عام" } }.distinct().sorted()
    }

    val filteredMistakes = remember(rawMistakes, masteryFilter, subjectFilter, searchQuery, examFilterId) {
        rawMistakes.filter { m ->
            val masteryOk = when (masteryFilter) {
                "غير متقن" -> !m.isMastered
                "تم الإتقان" -> m.isMastered
                else -> true
            }
            val subjectOk = subjectFilter == "الكل" || m.subject.equals(subjectFilter, ignoreCase = true)
            val examOk = examFilterId == null || m.examId == examFilterId
            val queryOk = searchQuery.isBlank() ||
                m.questionText.contains(searchQuery, ignoreCase = true) ||
                m.subject.contains(searchQuery, ignoreCase = true) ||
                m.examTitle.contains(searchQuery, ignoreCase = true) ||
                m.studentName.contains(searchQuery, ignoreCase = true) ||
                m.personalNote.contains(searchQuery, ignoreCase = true)
            masteryOk && subjectOk && examOk && queryOk
        }
    }

    val totalCount = rawMistakes.size
    val masteredCount = rawMistakes.count { it.isMastered }
    val unmasteredList = remember(filteredMistakes) { filteredMistakes.filter { !it.isMastered } }
    val masteryPercent = if (totalCount > 0) (masteredCount * 100) / totalCount else 100

    // Top recurring mistakes for Teacher insights
    val topRecurringQuestions = remember(rawMistakes) {
        rawMistakes.filter { !it.isMastered }
            .groupBy { it.questionText.trim() }
            .map { (qText, records) ->
                Triple(qText, records.sumOf { it.mistakeCount }, records.first())
            }
            .sortedByDescending { it.second }
            .take(5)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        AppHeader(
            title = if (isTeacher) "بنك أخطاء الطلاب والتحليلات" else "بنك أخطائي والمراجعة الذكية",
            subtitle = if (isTeacher) {
                "متابعة الأخطاء المتكررة وبناء امتحانات علاجية بنقرة واحدة"
            } else {
                "تجميع تلقائي لأخطائك في الامتحانات للتدرب وإتقانها"
            },
            onBack = onBack
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Mastery & Progress Summary Card
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = AcademicBluePrimary),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isTeacher) "مؤشر علاج الأخطاء العام" else "مستوى إتقان أخطائك",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White
                                )
                                Text(
                                    text = "إجمالي المسجل: $totalCount • متقن: $masteredCount • قيد المراجعة: ${totalCount - masteredCount}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AcademicBlueContainer
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color.White.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = "$masteryPercent%",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = { (masteryPercent / 100f).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = StatusSuccessContainer,
                            trackColor = Color.White.copy(alpha = 0.25f)
                        )
                    }
                }
            }

            // Action Buttons Bar
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (!isTeacher) {
                        Button(
                            onClick = {
                                val target = unmasteredList.ifEmpty { filteredMistakes }
                                if (target.isNotEmpty()) {
                                    practiceQueue = target
                                } else {
                                    Toast.makeText(context, "لا توجد أسئلة للتدرب عليها حالياً", Toast.LENGTH_SHORT).show()
                                }
                            },
                            enabled = filteredMistakes.isNotEmpty(),
                            colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1.2f)
                                .height(48.dp)
                                .testTag("btn_practice_mistakes")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (unmasteredList.isNotEmpty()) "تدرب الآن (${unmasteredList.size})" else "مراجعة الكل",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else {
                        Button(
                            onClick = {
                                if (filteredMistakes.isNotEmpty()) {
                                    showRemedialDialog = true
                                } else {
                                    Toast.makeText(context, "لا توجد أخطاء لبناء امتحان علاجي", Toast.LENGTH_SHORT).show()
                                }
                            },
                            enabled = filteredMistakes.isNotEmpty(),
                            colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1.3f)
                                .height(48.dp)
                                .testTag("btn_create_remedial_exam")
                        ) {
                            Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("إنشاء امتحان علاجي", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            if (isTeacher && allStudents.isEmpty()) {
                                Toast.makeText(context, "أضف طالباً أولاً لتسجيل خطأ له", Toast.LENGTH_SHORT).show()
                            } else {
                                showAddDialog = true
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("btn_add_manual_mistake")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("إضافة خطأ", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Teacher Top Recurring Mistakes Insight Card
            if (isTeacher && topRecurringQuestions.isNotEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = StatusWarningContainer.copy(alpha = 0.55f)),
                        border = BorderStroke(1.dp, StatusWarning.copy(alpha = 0.35f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Psychology, contentDescription = null, tint = StatusWarning, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "أكثر الأسئلة التي يخطئ فيها الطلاب:",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color(0xFF92400E)
                                )
                            }
                            topRecurringQuestions.forEachIndexed { idx, (qText, count, _) ->
                                Text(
                                    text = "${idx + 1}. $qText (تكرر $count مرة)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF78350F),
                                    maxLines = 2
                                )
                            }
                        }
                    }
                }
            }

            // Search & Filter Chips
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    label = { Text(if (isTeacher) "ابحث باسم الطالب أو السؤال أو المادة..." else "ابحث في أخطائك أو ملاحظاتك...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_mistake_search")
                )
                Spacer(modifier = Modifier.height(8.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf("الكل", "غير متقن", "تم الإتقان")) { status ->
                        FilterChip(
                            selected = masteryFilter == status,
                            onClick = { masteryFilter = status },
                            label = { Text(status, fontSize = 11.sp) }
                        )
                    }
                    if (examFilterId != null) {
                        item {
                            FilterChip(
                                selected = true,
                                onClick = { examFilterId = null },
                                label = { Text("إلغاء فلتر الامتحان ✕", fontSize = 11.sp) }
                            )
                        }
                    }
                }

                if (availableSubjects.size > 2) {
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(availableSubjects) { subj ->
                            FilterChip(
                                selected = subjectFilter == subj,
                                onClick = { subjectFilter = subj },
                                label = { Text(subj, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            }

            if (filteredMistakes.isEmpty()) {
                item {
                    EmptyStateView(
                        title = if (rawMistakes.isEmpty()) "سجل الأخطاء نظيف تماماً" else "لا توجد نتائج مطابقة",
                        description = if (rawMistakes.isEmpty()) {
                            "أي سؤال تخطئ فيه في الامتحانات الأونلاين سيُحفظ هنا تلقائياً لتتمكن من مراجعته وإتقانه."
                        } else {
                            "جرّب تغيير الفلاتر أو كلمات البحث."
                        },
                        icon = Icons.Default.BookmarkAdded
                    )
                }
            } else {
                items(filteredMistakes, key = { it.id }) { mistake ->
                    MistakeItemCard(
                        mistake = mistake,
                        isTeacher = isTeacher,
                        onPracticeSingle = { practiceQueue = listOf(mistake) },
                        onToggleMastered = { viewModel.toggleMistakeMastered(mistake) },
                        onEditNote = { editingNoteTarget = mistake },
                        onDelete = { viewModel.deleteMistake(mistake) }
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }

    if (practiceQueue.isNotEmpty()) {
        MistakePracticeDialog(
            mistakes = practiceQueue,
            onRecordAttempt = { mistake, isCorrect ->
                viewModel.recordMistakePracticeAttempt(mistake, isCorrect)
            },
            onDismiss = { practiceQueue = emptyList() }
        )
    }

    if (editingNoteTarget != null) {
        val target = editingNoteTarget!!
        var noteText by remember(target.id) { mutableStateOf(target.personalNote) }
        var expText by remember(target.id) { mutableStateOf(target.explanation) }
        val dismissInput = rememberActiveInputDismisser()

        SafeAlertDialog(
            onDismissRequest = { editingNoteTarget = null },
            title = { Text("ملاحظة وتوضيح السؤال", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = target.questionText,
                        style = MaterialTheme.typography.bodySmall,
                        color = AcademicBluePrimary,
                        maxLines = 3
                    )
                    OutlinedTextField(
                        value = noteText,
                        onValueChange = { noteText = it },
                        label = { Text(if (isTeacher) "توجيه المعلم للطالب" else "ملاحظتك الشخصية (لماذا أخطأت؟)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_mistake_note")
                    )
                    if (isTeacher) {
                        OutlinedTextField(
                            value = expText,
                            onValueChange = { expText = it },
                            label = { Text("التوضيح النموذجي للإجابة") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        dismissInput()
                        viewModel.updateMistakeNote(target, noteText, expText)
                        editingNoteTarget = null
                        Toast.makeText(context, "تم حفظ الملاحظة", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary)
                ) {
                    Text("حفظ")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = {
                    dismissInput()
                    editingNoteTarget = null
                }) {
                    Text("إلغاء")
                }
            }
        )
    }

    if (showAddDialog) {
        AddManualMistakeDialog(
            isTeacher = isTeacher,
            students = allStudents,
            currentStudent = currentStudent,
            onDismiss = { showAddDialog = false },
            onSave = { studentId, subject, qText, qType, opts, correctIdx, correctText, studentAns, explanation, diff, note ->
                viewModel.addManualMistake(
                    studentId = studentId,
                    subject = subject,
                    questionText = qText,
                    questionType = qType,
                    options = opts,
                    correctOptionIndex = correctIdx,
                    correctTextAnswer = correctText,
                    studentAnswer = studentAns,
                    explanation = explanation,
                    difficulty = diff,
                    personalNote = note
                )
                showAddDialog = false
                Toast.makeText(context, "تمت إضافة السؤال إلى بنك الأخطاء", Toast.LENGTH_SHORT).show()
            }
        )
    }

    if (showRemedialDialog) {
        val defaultTargets = unmasteredList.ifEmpty { filteredMistakes }.distinctBy { it.questionText.trim() }
        var examTitle by remember { mutableStateOf("امتحان علاجي - مراجعة الأخطاء") }
        var examGroup by remember { mutableStateOf("الكل") }
        var durationStr by remember { mutableStateOf("20") }
        val dismissInput = rememberActiveInputDismisser()

        SafeAlertDialog(
            onDismissRequest = { showRemedialDialog = false },
            title = { Text("بناء امتحان علاجي تلقائياً", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "سيتم تحويل ${defaultTargets.size.coerceAtMost(30)} سؤالاً من أكثر الأخطاء إلى امتحان جديد تفاعلي مع خلط الأسئلة والخيارات.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = examTitle,
                        onValueChange = { examTitle = it },
                        label = { Text("عنوان الامتحان العلاجي") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = examGroup,
                            onValueChange = { examGroup = it },
                            label = { Text("المجموعة المستهدفة") },
                            singleLine = true,
                            modifier = Modifier.weight(1.3f)
                        )
                        OutlinedTextField(
                            value = durationStr,
                            onValueChange = { durationStr = it.filter { ch -> ch.isDigit() } },
                            label = { Text("المدة (د)") },
                            singleLine = true,
                            modifier = Modifier.weight(0.8f)
                        )
                    }
                    if (groups.isNotEmpty()) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            item {
                                FilterChip(selected = examGroup == "الكل", onClick = { examGroup = "الكل" }, label = { Text("الكل", fontSize = 10.sp) })
                            }
                            items(groups) { grp ->
                                FilterChip(selected = examGroup == grp, onClick = { examGroup = grp }, label = { Text(grp, fontSize = 10.sp) })
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        dismissInput()
                        viewModel.createRemedialExamFromMistakes(
                            title = examTitle,
                            groupName = examGroup,
                            durationMinutes = durationStr.toIntOrNull() ?: 20,
                            mistakes = defaultTargets
                        )
                        showRemedialDialog = false
                        Toast.makeText(context, "تم نشر الامتحان العلاجي بنجاح!", Toast.LENGTH_SHORT).show()
                        onRemedialExamCreated()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary)
                ) {
                    Text("نشر الامتحان الآن")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = {
                    dismissInput()
                    showRemedialDialog = false
                }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
private fun MistakeItemCard(
    mistake: MistakeRecord,
    isTeacher: Boolean,
    onPracticeSingle: () -> Unit,
    onToggleMastered: () -> Unit,
    onEditNote: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            width = 1.dp,
            color = if (mistake.isMastered) StatusSuccess.copy(alpha = 0.35f) else StatusDanger.copy(alpha = 0.25f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_mistake_${mistake.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    StatusBadge(
                        text = if (mistake.isMastered) "تم الإتقان ✓" else "تحتاج مراجعة",
                        color = if (mistake.isMastered) StatusSuccess else StatusDanger,
                        bgColor = if (mistake.isMastered) StatusSuccessContainer else StatusDangerContainer,
                        icon = if (mistake.isMastered) Icons.Default.CheckCircle else Icons.Default.ErrorOutline
                    )
                    Surface(shape = RoundedCornerShape(8.dp), color = AcademicBlueContainer) {
                        Text(
                            text = mistake.subject,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = AcademicBluePrimary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                    Surface(shape = RoundedCornerShape(8.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                        Text(
                            text = ExamQuestion.difficultyLabel(mistake.difficulty),
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }

                if (mistake.mistakeCount > 1) {
                    Surface(shape = RoundedCornerShape(8.dp), color = StatusWarningContainer) {
                        Text(
                            text = "تكرر ×${mistake.mistakeCount}",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF92400E),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            if (isTeacher) {
                Text(
                    text = "الطالب: ${mistake.studentName} (${mistake.studentCode}) • ${mistake.examTitle}",
                    style = MaterialTheme.typography.labelSmall,
                    color = AcademicBluePrimary,
                    fontWeight = FontWeight.Bold
                )
            } else {
                Text(
                    text = "المصدر: ${mistake.examTitle} • ${mistake.lastMistakeDate}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Text(
                text = mistake.questionText,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )

            // Wrong vs Correct comparison
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = StatusDangerContainer.copy(alpha = 0.55f),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("إجابتك المسجلة:", fontSize = 10.sp, color = StatusDanger, fontWeight = FontWeight.Bold)
                        Text(mistake.studentAnswer.ifBlank { "لم يتم الحل" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                    }
                }
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = StatusSuccessContainer.copy(alpha = 0.55f),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("الإجابة الصحيحة:", fontSize = 10.sp, color = StatusSuccess, fontWeight = FontWeight.Bold)
                        Text(mistake.correctAnswer, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                    }
                }
            }

            if (mistake.explanation.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = AcademicBlueContainer.copy(alpha = 0.35f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "التوضيح: ${mistake.explanation}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }

            if (mistake.personalNote.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = StatusWarningContainer.copy(alpha = 0.45f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "ملاحظة: ${mistake.personalNote}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onPracticeSingle,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.height(40.dp)
                ) {
                    Icon(Icons.Default.Quiz, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("اختبر نفسك", fontSize = 11.sp)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onEditNote) {
                        Icon(Icons.Default.Edit, contentDescription = "تعديل الملاحظة", tint = AcademicBluePrimary)
                    }
                    IconButton(onClick = onToggleMastered) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = if (mistake.isMastered) "إعادة للمراجعة" else "تحديد كمتقن",
                            tint = if (mistake.isMastered) StatusSuccess else MaterialTheme.colorScheme.outline
                        )
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, contentDescription = "حذف الخطأ", tint = StatusDanger)
                    }
                }
            }
        }
    }
}

@Composable
private fun MistakePracticeDialog(
    mistakes: List<MistakeRecord>,
    onRecordAttempt: (MistakeRecord, Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var currentIndex by remember { mutableIntStateOf(0) }
    var selectedOption by remember { mutableIntStateOf(-1) }
    var shortText by remember { mutableStateOf("") }
    var checkedResult by remember { mutableStateOf<Boolean?>(null) }
    var correctTotal by remember { mutableIntStateOf(0) }
    val dismissInput = rememberActiveInputDismisser()

    val item = mistakes.getOrNull(currentIndex)
    LaunchedEffect(item == null) {
        if (item == null) {
            onDismiss()
        }
    }
    if (item == null) {
        return
    }

    val options = remember(item.id, item.questionType, item.optionsJson) {
        when (item.questionType) {
            ExamQuestion.TYPE_TRUE_FALSE -> listOf("صح", "خطأ")
            ExamQuestion.TYPE_SHORT_ANSWER -> emptyList()
            else -> item.parseOptions()
        }
    }

    SafeAlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(
                    text = "جلسة تدريب على الأخطاء (${currentIndex + 1}/${mistakes.size})",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = "${item.subject} • ${ExamQuestion.difficultyLabel(item.difficulty)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = AcademicBluePrimary
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = item.questionText,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )

                if (item.questionType == ExamQuestion.TYPE_SHORT_ANSWER || options.isEmpty()) {
                    OutlinedTextField(
                        value = shortText,
                        onValueChange = { if (checkedResult == null) shortText = it },
                        readOnly = checkedResult != null,
                        label = { Text("اكتب الإجابة الصحيحة") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    options.forEachIndexed { idx, optText ->
                        val isSelected = selectedOption == idx
                        val isRightOpt = idx == item.correctOptionIndex
                        val borderColor = when {
                            checkedResult != null && isRightOpt -> StatusSuccess
                            checkedResult == false && isSelected && !isRightOpt -> StatusDanger
                            isSelected -> AcademicBluePrimary
                            else -> MaterialTheme.colorScheme.outline
                        }
                        val bgColor = when {
                            checkedResult != null && isRightOpt -> StatusSuccessContainer.copy(alpha = 0.6f)
                            checkedResult == false && isSelected && !isRightOpt -> StatusDangerContainer.copy(alpha = 0.6f)
                            isSelected -> AcademicBlueContainer.copy(alpha = 0.5f)
                            else -> MaterialTheme.colorScheme.surface
                        }
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = bgColor,
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.5.dp, borderColor, RoundedCornerShape(10.dp))
                                .clickable(enabled = checkedResult == null) { selectedOption = idx }
                        ) {
                            Text(
                                text = optText,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }

                if (checkedResult != null) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (checkedResult == true) StatusSuccessContainer else StatusDangerContainer,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = if (checkedResult == true) "أحسنت! تم إتقان هذا الخطأ ✓" else "حاول مرة أخرى لاحقاً — الإجابة الصحيحة: ${item.correctAnswer}",
                                fontWeight = FontWeight.Bold,
                                color = if (checkedResult == true) StatusSuccess else StatusDanger,
                                style = MaterialTheme.typography.bodySmall
                            )
                            if (item.explanation.isNotBlank()) {
                                Text(
                                    text = item.explanation,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (checkedResult == null) {
                Button(
                    onClick = {
                        dismissInput()
                        val isCorrect = if (item.questionType == ExamQuestion.TYPE_SHORT_ANSWER || options.isEmpty()) {
                            shortText.isNotBlank() &&
                                ExamQuestion.normalizeShortAnswer(shortText) == ExamQuestion.normalizeShortAnswer(item.correctAnswer)
                        } else {
                            selectedOption == item.correctOptionIndex
                        }
                        checkedResult = isCorrect
                        if (isCorrect) correctTotal += 1
                        onRecordAttempt(item, isCorrect)
                    },
                    enabled = (selectedOption >= 0) || shortText.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary)
                ) {
                    Text("تحقق من الإجابة")
                }
            } else {
                Button(
                    onClick = {
                        dismissInput()
                        if (currentIndex + 1 < mistakes.size) {
                            currentIndex += 1
                            selectedOption = -1
                            shortText = ""
                            checkedResult = null
                        } else {
                            onDismiss()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess)
                ) {
                    Text(if (currentIndex + 1 < mistakes.size) "السؤال التالي" else "إنهاء ($correctTotal/${mistakes.size})")
                }
            }
        },
        dismissButton = {
            OutlinedButton(onClick = {
                dismissInput()
                onDismiss()
            }) {
                Text("إغلاق")
            }
        }
    )
}

@Composable
private fun AddManualMistakeDialog(
    isTeacher: Boolean,
    students: List<Student>,
    currentStudent: Student?,
    onDismiss: () -> Unit,
    onSave: (
        studentId: Long,
        subject: String,
        questionText: String,
        questionType: String,
        options: List<String>,
        correctIdx: Int,
        correctText: String,
        studentAns: String,
        explanation: String,
        difficulty: String,
        note: String
    ) -> Unit
) {
    val context = LocalContext.current
    var selectedStudentId by remember { mutableStateOf(currentStudent?.id ?: students.firstOrNull()?.id ?: 0L) }
    var subject by remember { mutableStateOf("عام") }
    var qType by remember { mutableStateOf(ExamQuestion.TYPE_MCQ) }
    var difficulty by remember { mutableStateOf(ExamQuestion.DIFFICULTY_MEDIUM) }
    var questionText by remember { mutableStateOf("") }
    var o1 by remember { mutableStateOf("") }
    var o2 by remember { mutableStateOf("") }
    var o3 by remember { mutableStateOf("") }
    var o4 by remember { mutableStateOf("") }
    var correctIdx by remember { mutableIntStateOf(0) }
    var correctText by remember { mutableStateOf("") }
    var studentAns by remember { mutableStateOf("") }
    var explanation by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    val dismissInput = rememberActiveInputDismisser()

    SafeAlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة سؤال لبنك الأخطاء", fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 400.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (isTeacher && students.isNotEmpty()) {
                    item {
                        Text("اختر الطالب:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(students, key = { it.id }) { st ->
                                FilterChip(
                                    selected = selectedStudentId == st.id,
                                    onClick = { selectedStudentId = st.id },
                                    label = { Text(st.name, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                }
                item {
                    OutlinedTextField(
                        value = subject,
                        onValueChange = { subject = it },
                        label = { Text("المادة / الدرس") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        item {
                            FilterChip(
                                selected = qType == ExamQuestion.TYPE_MCQ,
                                onClick = { qType = ExamQuestion.TYPE_MCQ; correctIdx = 0 },
                                label = { Text("اختياري", fontSize = 10.sp) }
                            )
                        }
                        item {
                            FilterChip(
                                selected = qType == ExamQuestion.TYPE_TRUE_FALSE,
                                onClick = { qType = ExamQuestion.TYPE_TRUE_FALSE; correctIdx = 0 },
                                label = { Text("صح وخطأ", fontSize = 10.sp) }
                            )
                        }
                        item {
                            FilterChip(
                                selected = qType == ExamQuestion.TYPE_SHORT_ANSWER,
                                onClick = { qType = ExamQuestion.TYPE_SHORT_ANSWER },
                                label = { Text("إجابة قصيرة", fontSize = 10.sp) }
                            )
                        }
                    }
                }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(
                            ExamQuestion.DIFFICULTY_EASY,
                            ExamQuestion.DIFFICULTY_MEDIUM,
                            ExamQuestion.DIFFICULTY_HARD
                        ).forEach { diff ->
                            item {
                                FilterChip(
                                    selected = difficulty == diff,
                                    onClick = { difficulty = diff },
                                    label = { Text(ExamQuestion.difficultyLabel(diff), fontSize = 10.sp) }
                                )
                            }
                        }
                    }
                }
                item {
                    OutlinedTextField(
                        value = questionText,
                        onValueChange = { questionText = it },
                        label = { Text("نص السؤال") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    when (qType) {
                        ExamQuestion.TYPE_TRUE_FALSE -> {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("صح", "خطأ").forEachIndexed { idx, label ->
                                    FilterChip(
                                        selected = correctIdx == idx,
                                        onClick = { correctIdx = idx },
                                        label = { Text(label) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                        ExamQuestion.TYPE_SHORT_ANSWER -> {
                            OutlinedTextField(
                                value = correctText,
                                onValueChange = { correctText = it },
                                label = { Text("الإجابة الصحيحة") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        else -> {
                            val labels = listOf("أ", "ب", "ج", "د")
                            val vals = listOf(o1, o2, o3, o4)
                            val sets = listOf<(String) -> Unit>({ o1 = it }, { o2 = it }, { o3 = it }, { o4 = it })
                            vals.forEachIndexed { idx, v ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    RadioButton(selected = correctIdx == idx, onClick = { correctIdx = idx })
                                    OutlinedTextField(
                                        value = v,
                                        onValueChange = sets[idx],
                                        label = { Text("خيار ${labels[idx]}") },
                                        singleLine = true,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }
                item {
                    OutlinedTextField(
                        value = studentAns,
                        onValueChange = { studentAns = it },
                        label = { Text("الإجابة الخاطئة / سبب الحفظ (اختياري)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    OutlinedTextField(
                        value = explanation,
                        onValueChange = { explanation = it },
                        label = { Text("التوضيح (اختياري)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("ملاحظة للمراجعة (اختياري)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val targetId = selectedStudentId
                    val validShort = qType != ExamQuestion.TYPE_SHORT_ANSWER || correctText.isNotBlank()
                    if (targetId <= 0L || questionText.isBlank() || !validShort) {
                        Toast.makeText(context, "أكمل نص السؤال والإجابة الصحيحة", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    dismissInput()
                    val opts = when (qType) {
                        ExamQuestion.TYPE_TRUE_FALSE -> listOf("صح", "خطأ")
                        ExamQuestion.TYPE_SHORT_ANSWER -> emptyList()
                        else -> listOf(o1, o2, o3, o4).mapIndexed { i, s -> s.ifBlank { "خيار ${i + 1}" } }
                    }
                    onSave(
                        targetId,
                        subject,
                        questionText,
                        qType,
                        opts,
                        correctIdx,
                        correctText,
                        studentAns,
                        explanation,
                        difficulty,
                        note
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary)
            ) {
                Text("حفظ في بنك الأخطاء")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = {
                dismissInput()
                onDismiss()
            }) {
                Text("إلغاء")
            }
        }
    )
}
