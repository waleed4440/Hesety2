package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.TeacherViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.EmptyStateView
import com.example.ui.components.SafeAlertDialog
import com.example.ui.components.rememberActiveInputDismisser
import com.example.ui.theme.AcademicBlueContainer
import com.example.ui.theme.AcademicBluePrimary
import com.example.ui.theme.AcademicBlueSecondary
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessContainer
import com.example.util.QrCodeHelper
import java.io.File

@Composable
fun TeacherResourcesScreen(
    viewModel: TeacherViewModel,
    modifier: Modifier = Modifier
) {
    val resources by viewModel.allResources.collectAsState()
    val groups by viewModel.allGroups.collectAsState()
    val context = LocalContext.current

    var showAddDialog by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedGroupFilter by remember { mutableStateOf("الكل") }
    var selectedTypeFilter by remember { mutableStateOf("الكل") }

    val typeFilters = listOf("الكل", "PDF", "ملخص مراجعة", "فيديو شرح", "بنك أسئلة")

    val filteredResources = remember(resources, searchQuery, selectedGroupFilter, selectedTypeFilter) {
        resources.filter { res ->
            val groupMatch = selectedGroupFilter == "الكل" || res.groupName.equals(selectedGroupFilter, ignoreCase = true)
            val typeMatch = selectedTypeFilter == "الكل" || res.fileType.contains(selectedTypeFilter, ignoreCase = true)
            val queryMatch = searchQuery.isBlank() ||
                res.title.contains(searchQuery, ignoreCase = true) ||
                res.subject.contains(searchQuery, ignoreCase = true) ||
                res.description.contains(searchQuery, ignoreCase = true)
            groupMatch && typeMatch && queryMatch
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = AcademicBluePrimary,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("fab_add_resource")
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة مذكرة أو ملف")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AppHeader(
                title = "المذكرات والمصادر التعليمية (${resources.size})",
                subtitle = "رفع ملفات PDF، ملخصات، وروابط شروحات مخصصة للمجموعات"
            )

            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    label = { Text("ابحث بالعنوان أو المادة...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_teacher_resource_search")
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(typeFilters) { tFilter ->
                        FilterChip(
                            selected = selectedTypeFilter == tFilter,
                            onClick = { selectedTypeFilter = tFilter },
                            label = { Text(tFilter, fontSize = 11.sp) }
                        )
                    }
                }
                if (groups.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            FilterChip(
                                selected = selectedGroupFilter == "الكل",
                                onClick = { selectedGroupFilter = "الكل" },
                                label = { Text("كل المجموعات", fontSize = 11.sp) }
                            )
                        }
                        items(groups) { grp ->
                            FilterChip(
                                selected = selectedGroupFilter == grp,
                                onClick = { selectedGroupFilter = grp },
                                label = { Text(grp, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            }

            if (filteredResources.isEmpty()) {
                EmptyStateView(
                    title = if (resources.isEmpty()) "لا توجد مصادر مرفوعة" else "لا توجد مصادر مطابقة",
                    description = if (resources.isEmpty()) "اضغط على زر (+) لرفع مذكرة أو ملف تعليمي" else "جرب تغيير كلمات البحث أو التصفية",
                    icon = Icons.Default.Description
                )
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(filteredResources) { res ->
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = res.title,
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Text(
                                            text = "${res.subject} • ${res.fileType} • المجموعة: ${res.groupName} • ${res.addedDate}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    IconButton(
                                        onClick = {
                                            viewModel.deleteResource(res)
                                            Toast.makeText(context, "تم حذف الملف", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.testTag("btn_delete_res_${res.id}")
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = StatusDanger)
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = res.description,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                if (res.resourceContent.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = res.resourceContent,
                                            maxLines = 3,
                                            style = MaterialTheme.typography.bodySmall,
                                            modifier = Modifier.padding(10.dp)
                                        )
                                    }
                                }

                                if (res.localFilePath.isNotBlank() || res.externalUrl.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        if (res.localFilePath.isNotBlank()) {
                                            OutlinedButton(
                                                onClick = { QrCodeHelper.openLocalResourceFile(context, res.localFilePath) },
                                                shape = RoundedCornerShape(10.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("عرض الملف", fontSize = 11.sp)
                                            }
                                            IconButton(
                                                onClick = { QrCodeHelper.shareResourceFile(context, res.localFilePath, res.title) }
                                            ) {
                                                Icon(Icons.Default.Share, contentDescription = "مشاركة الملف", tint = AcademicBluePrimary)
                                            }
                                        }
                                        if (res.externalUrl.isNotBlank()) {
                                            OutlinedButton(
                                                onClick = { QrCodeHelper.openExternalUrl(context, res.externalUrl) },
                                                shape = RoundedCornerShape(10.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(Icons.Default.Link, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("فتح الرابط", fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    item { Spacer(modifier = Modifier.height(72.dp)) }
                }
            }
        }
    }

    if (showAddDialog) {
        var title by remember { mutableStateOf("") }
        var subject by remember { mutableStateOf("اللغة العربية") }
        var selectedGroup by remember { mutableStateOf("الكل") }
        var fileType by remember { mutableStateOf("PDF") }
        var desc by remember { mutableStateOf("") }
        var content by remember { mutableStateOf("") }
        var externalUrl by remember { mutableStateOf("") }
        var localFilePath by remember { mutableStateOf("") }

        val resourceTypes = listOf("PDF", "ملخص مراجعة", "فيديو شرح", "بنك أسئلة")

        val filePicker = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.OpenDocument()
        ) { uri ->
            if (uri != null) {
                val copied = QrCodeHelper.copyPickedResourceFileToInternal(context, uri)
                if (copied != null) {
                    localFilePath = copied
                    Toast.makeText(context, "تم إرفاق الملف بنجاح", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "تعذر قراءة الملف المحدد", Toast.LENGTH_SHORT).show()
                }
            }
        }

        SafeAlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("رفع ملف تعليمي أو مذكرة جديدة", fontWeight = FontWeight.Bold) },
            text = {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 410.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        OutlinedTextField(
                            value = title,
                            onValueChange = { title = it },
                            label = { Text("عنوان المذكرة أو الملف") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_resource_title")
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = subject,
                            onValueChange = { subject = it },
                            label = { Text("المادة الدراسية") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    item {
                        Text("نوع المصدر:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(resourceTypes) { typeOption ->
                                FilterChip(
                                    selected = fileType == typeOption,
                                    onClick = { fileType = typeOption },
                                    label = { Text(typeOption, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                    item {
                        Text("المجموعة المستهدفة:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            item {
                                FilterChip(
                                    selected = selectedGroup == "الكل",
                                    onClick = { selectedGroup = "الكل" },
                                    label = { Text("الكل", fontSize = 11.sp) }
                                )
                            }
                            items(groups) { grp ->
                                FilterChip(
                                    selected = selectedGroup == grp,
                                    onClick = { selectedGroup = grp },
                                    label = { Text(grp, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                    item {
                        OutlinedButton(
                            onClick = {
                                filePicker.launch(arrayOf("application/pdf", "image/*", "text/plain", "*/*"))
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_attach_resource_file")
                        ) {
                            Icon(Icons.Default.AttachFile, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (localFilePath.isNotBlank()) "تغيير الملف المرفق" else "إرفاق ملف من الجهاز (PDF / صورة / مستند)",
                                fontSize = 12.sp
                            )
                        }
                        if (localFilePath.isNotBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = StatusSuccessContainer,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "تم إرفاق: ${File(localFilePath).name}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StatusSuccess,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                    item {
                        OutlinedTextField(
                            value = externalUrl,
                            onValueChange = { externalUrl = it },
                            label = { Text("رابط خارجي (يوتيوب / Google Drive - اختياري)") },
                            singleLine = true,
                            leadingIcon = { Icon(Icons.Default.Link, contentDescription = null) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_resource_url")
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = desc,
                            onValueChange = { desc = it },
                            label = { Text("وصف محتوى الملف") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = content,
                            onValueChange = { content = it },
                            label = { Text("نص الملخص أو ملاحظات للمذاكرة (اختياري)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = {
                val dismissInput = rememberActiveInputDismisser()
                Button(
                    onClick = {
                        if (title.isNotBlank()) {
                            dismissInput()
                            viewModel.addEducationalResource(
                                title = title,
                                subject = subject,
                                groupName = selectedGroup,
                                description = desc.ifBlank { "ملف دراسي هام للتحميل والمذاكرة" },
                                fileType = fileType,
                                content = content.ifBlank {
                                    when {
                                        localFilePath.isNotBlank() || externalUrl.isNotBlank() -> ""
                                        else -> "متاح للقراءة والمراجعة عبر المنصة"
                                    }
                                },
                                localFilePath = localFilePath,
                                externalUrl = externalUrl
                            )
                            showAddDialog = false
                            Toast.makeText(context, "تمت إضافة المذكرة بنجاح", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "أدخل عنوان المذكرة أولاً", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary),
                    modifier = Modifier.testTag("btn_save_resource")
                ) {
                    Text("رفع الملف")
                }
            },
            dismissButton = {
                val dismissInput = rememberActiveInputDismisser()
                OutlinedButton(onClick = {
                    dismissInput()
                    showAddDialog = false
                }) {
                    Text("إلغاء")
                }
            }
        )
    }
}
