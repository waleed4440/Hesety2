package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Academic Navy / Blue
val AcademicBluePrimary = Color(0xFF1E3A8A)
val AcademicBlueSecondary = Color(0xFF2563EB)
val AcademicBlueTertiary = Color(0xFF3B82F6)
val AcademicBlueContainer = Color(0xFFDBEAFE)
val OnAcademicBlueContainer = Color(0xFF1E3A8A)

// Status Colors
val StatusSuccess = Color(0xFF059669)
val StatusSuccessContainer = Color(0xFFD1FAE5)
val StatusWarning = Color(0xFFD97706)
val StatusWarningContainer = Color(0xFFFEF3C7)
val StatusDanger = Color(0xFFDC2626)
val StatusDangerContainer = Color(0xFFFEE2E2)
val StatusInfo = Color(0xFF0284C7)
val StatusInfoContainer = Color(0xFFE0F2FE)

// Surfaces & Backgrounds
val SurfaceLight = Color(0xFFFFFFFF)
val BackgroundLight = Color(0xFFF8FAFC)
val CardBorderLight = Color(0xFFE2E8F0)
val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF475569)
val TextMuted = Color(0xFF94A3B8)

// Dark Theme Variants
val DarkBackground = Color(0xFF0B1329)
val DarkSurface = Color(0xFF131D38)
val DarkCardBorder = Color(0xFF1E293B)

// Calm, Eye-Friendly Announcement & Alert Palettes (High Contrast in Light & Dark Modes)
data class AnnouncementPalette(
    val container: Color,
    val border: Color,
    val title: Color,
    val body: Color,
    val meta: Color,
    val badgeBg: Color,
    val badgeText: Color,
    val iconTint: Color
)

fun calmAnnouncementPalette(isUrgent: Boolean, isDarkTheme: Boolean): AnnouncementPalette {
    return when {
        isUrgent && isDarkTheme -> AnnouncementPalette(
            container = Color(0xFF231F29),
            border = Color(0xFF4A3842),
            title = Color(0xFFFDBA74),
            body = Color(0xFFF1F5F9),
            meta = Color(0xFFCBD5E1),
            badgeBg = Color(0xFF3A2830),
            badgeText = Color(0xFFFDBA74),
            iconTint = Color(0xFFFDBA74)
        )
        isUrgent && !isDarkTheme -> AnnouncementPalette(
            container = Color(0xFFFDF5F0),
            border = Color(0xFFE7CFC3),
            title = Color(0xFF9A3412),
            body = Color(0xFF1E293B),
            meta = Color(0xFF475569),
            badgeBg = Color(0xFFF9E5DA),
            badgeText = Color(0xFF9A3412),
            iconTint = Color(0xFF9A3412)
        )
        !isUrgent && isDarkTheme -> AnnouncementPalette(
            container = Color(0xFF16213B),
            border = Color(0xFF283A61),
            title = Color(0xFF93C5FD),
            body = Color(0xFFF1F5F9),
            meta = Color(0xFFCBD5E1),
            badgeBg = Color(0xFF1E3259),
            badgeText = Color(0xFF93C5FD),
            iconTint = Color(0xFF93C5FD)
        )
        else -> AnnouncementPalette(
            container = Color(0xFFF4F8FC),
            border = Color(0xFFD7E3F1),
            title = Color(0xFF1E3A8A),
            body = Color(0xFF1E293B),
            meta = Color(0xFF475569),
            badgeBg = Color(0xFFE2ECF7),
            badgeText = Color(0xFF1E3A8A),
            iconTint = Color(0xFF1E3A8A)
        )
    }
}

