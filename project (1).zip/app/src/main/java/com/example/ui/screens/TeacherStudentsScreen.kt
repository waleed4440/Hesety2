package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Student
import com.example.ui.TeacherViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.EmptyStateView
import com.example.ui.components.QuickParentContactDialog
import com.example.ui.components.SafeAlertDialog
import com.example.ui.components.VoiceNoteRecorderBox
import com.example.ui.components.rememberActiveInputDismisser
import com.example.ui.theme.AcademicBlueContainer
import com.example.ui.theme.AcademicBluePrimary
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusDangerContainer
import com.example.ui.theme.StatusSuccess
import com.example.util.ParentCommunicationHelper
import com.example.util.ParentMessageTemplate
import com.example.util.StudentGuardianSnapshot

@Composable
fun TeacherStudentsScreen(
    viewModel: TeacherViewModel,
    modifier: Modifier = Modifier
) {
    val students by viewModel.allStudents.collectAsState()
    val allAttendances by viewModel.allAttendances.collectAsState()
    val allHomework by viewModel.allHomework.collectAsState()
    val allPayments by viewModel.allPayments.collectAsState()
    val allSubmissions by viewModel.allSubmissions.collectAsState()
    val allExams by viewModel.allExams.collectAsState()
    val allNotes by viewModel.allNotes.collectAsState()
    val sessionDate by viewModel.selectedSessionDate.collectAsState()
    val context = LocalContext.current

    var searchQuery by remember { mutableStateOf("") }
    var selectedGroupFilter by remember { mutableStateOf("الكل") }

    var showAddDialog by remember { mutableStateOf(false) }
    var editingStudent by remember { mutableStateOf<Student?>(null) }
    var noteTargetStudent by remember { mutableStateOf<Student?>(null) }
    var deleteConfirmStudent by remember { mutableStateOf<Student?>(null) }
    var qrTargetStudent by remember { mutableStateOf<Student?>(null) }
    var contactSnapshotTarget by remember { mutableStateOf<StudentGuardianSnapshot?>(null) }

    val distinctGroups = listOf("الكل") + students.map { it.groupName }.distinct()

    val filteredStudents = students.filter { s ->
        val matchesSearch = s.name.contains(searchQuery, ignoreCase = true) ||
                s.code.contains(searchQuery, ignoreCase = true)
        val matchesGroup = selectedGroupFilter == "الكل" || s.groupName == selectedGroupFilter
        matchesSearch && matchesGroup
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = AcademicBluePrimary,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("fab_add_student")
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة طالب جديد")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AppHeader(
                title = "إدارة الطلاب (${students.size})",
                subtitle = "عرض وتعديل بيانات الطلاب، الأكواد، وكلمات المرور"
            )

            // Search Bar
            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("ابحث باسم الطالب أو كود الطالب...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_students_input")
                )
            }

            // Group Filter Chips
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(distinctGroups) { grp ->
                    FilterChip(
                        selected = selectedGroupFilter == grp,
                        onClick = { selectedGroupFilter = grp },
                        label = { Text(grp) },
                        modifier = Modifier.testTag("chip_group_$grp")
                    )
                }
            }

            if (filteredStudents.isEmpty()) {
                EmptyStateView(
                    title = "لم يتم العثور على طلاب",
                    description = "تأكد من كتابة الاسم أو الكود بشكل صحيح أو أضف طالباً جديداً",
                    icon = Icons.Default.Person
                )
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredStudents) { student ->
                        StudentCardItem(
                            student = student,
                            onEdit = { editingStudent = student },
                            onShowQr = { qrTargetStudent = student },
                            onAddNote = { noteTargetStudent = student },
                            onQuickCall = {
                                ParentCommunicationHelper.dialParent(context, student.parentPhone)
                            },
                            onShare = {
                                contactSnapshotTarget = ParentCommunicationHelper.buildSnapshot(
                                    student = student,
                                    allAttendances = allAttendances,
                                    allHomework = allHomework,
                                    allPayments = allPayments,
                                    allSubmissions = allSubmissions,
                                    allExams = allExams,
                                    allNotes = allNotes,
                                    sessionDate = sessionDate
                                )
                            },
                            onDelete = { deleteConfirmStudent = student }
                        )
                    }
                }
            }
        }
    }

    // Add or Edit Student Dialog
    if (showAddDialog || editingStudent != null) {
        val isEditing = editingStudent != null
        val target = editingStudent

        StudentFormDialog(
            initialStudent = target,
            onDismiss = {
                showAddDialog = false
                editingStudent = null
            },
            onSave = { name, code, pass, group, schedule, phone, fee ->
                viewModel.saveStudent(
                    id = target?.id ?: 0,
                    name = name,
                    code = code,
                    password = pass,
                    groupName = group,
                    scheduleTime = schedule,
                    parentPhone = phone,
                    monthlyFee = fee
                )
                showAddDialog = false
                editingStudent = null
                Toast.makeText(context, if (isEditing) "تم تحديث بيانات الطالب بنجاح" else "تمت إضافة الطالب بنجاح", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Write or Record Parent Note Dialog
    if (noteTargetStudent != null) {
        AddParentNoteDialog(
            student = noteTargetStudent!!,
            onDismiss = { noteTargetStudent = null },
            onSave = { title, content, audioPath, audioDuration ->
                viewModel.addParentNote(
                    studentId = noteTargetStudent!!.id,
                    title = title,
                    content = content,
                    audioFilePath = audioPath,
                    audioDurationSeconds = audioDuration
                )
                noteTargetStudent = null
                Toast.makeText(context, "تم حفظ الملاحظة لولي الأمر بنجاح", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Delete Confirmation Dialog
    if (deleteConfirmStudent != null) {
        SafeAlertDialog(
            onDismissRequest = { deleteConfirmStudent = null },
            title = { Text("تأكيد حذف الطالب") },
            text = { Text("هل أنت متأكد من حذف الطالب ${deleteConfirmStudent?.name}؟ سيتم حذف كافة سجلات الحضور والدرجات.") },
            confirmButton = {
                Button(
                    onClick = {
                        deleteConfirmStudent?.let { viewModel.deleteStudent(it) }
                        deleteConfirmStudent = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDanger)
                ) {
                    Text("حذف نهائي")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { deleteConfirmStudent = null }) {
                    Text("إلغاء")
                }
            }
        )
    }
    // Student QR Pass Dialog
    if (qrTargetStudent != null) {
        com.example.ui.components.StudentQrPassDialog(
            student = qrTargetStudent!!,
            onDismiss = { qrTargetStudent = null }
        )
    }

    if (contactSnapshotTarget != null) {
        QuickParentContactDialog(
            snapshot = contactSnapshotTarget!!,
            initialTemplate = ParentMessageTemplate.FULL_REPORT,
            onDismiss = { contactSnapshotTarget = null }
        )
    }
}

@Composable
fun StudentCardItem(
    student: Student,
    onEdit: () -> Unit,
    onShowQr: () -> Unit,
    onAddNote: () -> Unit,
    onQuickCall: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(AcademicBlueContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = AcademicBluePrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = student.name,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = student.groupName,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row {
                    IconButton(onClick = onShowQr, modifier = Modifier.testTag("btn_qr_${student.id}")) {
                        Icon(Icons.Default.QrCode2, contentDescription = "بطاقة QR", tint = AcademicBluePrimary)
                    }
                    IconButton(onClick = onEdit, modifier = Modifier.testTag("btn_edit_${student.id}")) {
                        Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = AcademicBluePrimary)
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.testTag("btn_delete_${student.id}")) {
                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = StatusDanger)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            Spacer(modifier = Modifier.height(10.dp))

            // Student credentials display
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = AcademicBlueContainer
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("الكود: ", style = MaterialTheme.typography.labelSmall, color = AcademicBluePrimary)
                        Text(
                            text = student.code,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold),
                            color = AcademicBluePrimary
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFFEF3C7)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color(0xFF92400E))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "كلمة السر: ${student.password}",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = Color(0xFF92400E)
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        text = "${student.monthlyFee} ج.م/شهر",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Phone,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "هاتف ولي الأمر: ${student.parentPhone.ifBlank { "غير مسجل" }}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (ParentCommunicationHelper.normalizeDialPhone(student.parentPhone) != null) {
                    IconButton(
                        onClick = onQuickCall,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("btn_quick_call_${student.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Call,
                            contentDescription = "اتصال سريع بولي الأمر",
                            tint = StatusSuccess,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onAddNote,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_add_note_${student.id}"),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.NoteAdd, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ملاحظة لولي الأمر", fontSize = 11.sp)
                }

                Button(
                    onClick = onShare,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_share_${student.id}"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("تواصل سريع واتساب", fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun StudentFormDialog(
    initialStudent: Student?,
    onDismiss: () -> Unit,
    onSave: (name: String, code: String, pass: String, group: String, schedule: String, phone: String, fee: Double) -> Unit
) {
    val isEdit = initialStudent != null
    var name by remember { mutableStateOf(initialStudent?.name ?: "") }
    var code by remember { mutableStateOf(initialStudent?.code ?: "STU${(100..999).random()}") }
    var pass by remember { mutableStateOf(initialStudent?.password ?: Student.generateStrongPassword()) }
    var group by remember { mutableStateOf(initialStudent?.groupName ?: "الصف الأول الثانوي (مجموعة أ)") }
    var schedule by remember { mutableStateOf(initialStudent?.scheduleTime ?: "السبت والثلاثاء - 4:00 عصراً") }
    var phone by remember { mutableStateOf(initialStudent?.parentPhone ?: "010") }
    var feeStr by remember { mutableStateOf(initialStudent?.monthlyFee?.toInt()?.toString() ?: "250") }

    SafeAlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isEdit) "تعديل بيانات الطالب والكود" else "إضافة طالب جديد للمجموعة") },
        text = {
            val dismissInput = rememberActiveInputDismisser()
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم الطالب ثلاثي") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_student_name")
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = code,
                        onValueChange = { code = it },
                        label = { Text("كود الطالب") },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_student_code")
                    )
                    OutlinedTextField(
                        value = pass,
                        onValueChange = { pass = it },
                        label = { Text("كلمة المرور") },
                        singleLine = true,
                        trailingIcon = {
                            IconButton(
                                onClick = { pass = Student.generateStrongPassword() },
                                modifier = Modifier.testTag("btn_regenerate_student_password")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "توليد كلمة مرور عشوائية"
                                )
                            }
                        },
                        modifier = Modifier
                            .weight(1.2f)
                            .testTag("input_student_password")
                    )
                }

                OutlinedTextField(
                    value = group,
                    onValueChange = { group = it },
                    label = { Text("اسم المجموعة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = schedule,
                    onValueChange = { schedule = it },
                    label = { Text("موعد الحصة (الساعة والأيام)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("رقم ولي الأمر") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = feeStr,
                        onValueChange = { feeStr = it },
                        label = { Text("المصروفات") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        confirmButton = {
            val dismissInput = rememberActiveInputDismisser()
            Button(
                onClick = {
                    if (name.isNotBlank() && code.isNotBlank()) {
                        dismissInput()
                        val fee = feeStr.toDoubleOrNull() ?: 250.0
                        onSave(name, code, pass, group, schedule, phone, fee)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary)
            ) {
                Text(if (isEdit) "حفظ التعديلات" else "إضافة الطالب")
            }
        },
        dismissButton = {
            val dismissInput = rememberActiveInputDismisser()
            OutlinedButton(onClick = {
                dismissInput()
                onDismiss()
            }) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
fun AddParentNoteDialog(
    student: Student,
    onDismiss: () -> Unit,
    onSave: (title: String, content: String, audioPath: String, audioDurationSec: Int) -> Unit
) {
    var title by remember { mutableStateOf("ملاحظة أسبوعية لولي الأمر") }
    var content by remember { mutableStateOf("نحيطكم علماً بأن مستوى الطالب ${student.name} ممتاز وملتزم بالحضور والواجبات.") }
    var audioPath by remember { mutableStateOf("") }
    var audioDuration by remember { mutableIntStateOf(0) }

    SafeAlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إرسال ملاحظة لولي أمر الطالب") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "الطالب: ${student.name} (${student.groupName})",
                    style = MaterialTheme.typography.bodySmall,
                    color = AcademicBluePrimary,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان الملاحظة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("نص الملاحظة الكتابية (اختياري مع الصوت)") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_parent_note_content")
                )

                VoiceNoteRecorderBox(
                    recordedAudioPath = audioPath,
                    recordedDurationSec = audioDuration,
                    onAudioChanged = { path, dur ->
                        audioPath = path
                        audioDuration = dur
                    },
                    title = "إضافة ملاحظة صوتية لولي الأمر",
                    prefix = "parent_note"
                )
            }
        },
        confirmButton = {
            val dismissInput = rememberActiveInputDismisser()
            Button(
                onClick = {
                    if (content.isNotBlank() || audioPath.isNotBlank()) {
                        dismissInput()
                        onSave(title, content, audioPath, audioDuration)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary),
                modifier = Modifier.testTag("btn_save_parent_note")
            ) {
                Text("حفظ الملاحظة")
            }
        },
        dismissButton = {
            val dismissInput = rememberActiveInputDismisser()
            OutlinedButton(onClick = {
                dismissInput()
                onDismiss()
            }) {
                Text("إلغاء")
            }
        }
    )
}
