package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LibraryBooks
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Event
import com.example.data.Exam
import com.example.data.ExamQuestion
import com.example.data.QuestionBankItem
import com.example.ui.TeacherTab
import com.example.ui.TeacherViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.EmptyStateView
import com.example.ui.components.SafeAlertDialog
import com.example.ui.components.rememberActiveInputDismisser
import com.example.ui.theme.AcademicBlueContainer
import com.example.ui.theme.AcademicBluePrimary
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusDangerContainer
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessContainer
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningContainer
import com.example.util.ExamMistakeAnalyzer
import com.example.util.QrCodeHelper
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun TeacherExamsScreen(
    viewModel: TeacherViewModel,
    modifier: Modifier = Modifier
) {
    val exams by viewModel.allExams.collectAsState()
    val students by viewModel.allStudents.collectAsState()
    val groups by viewModel.allGroups.collectAsState()
    val bankQuestions by viewModel.allBankQuestions.collectAsState()
    val allMistakes by viewModel.allMistakes.collectAsState()
    val context = LocalContext.current

    val allSubmissions by viewModel.allSubmissions.collectAsState()
    val todayDate = remember { SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date()) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var editingExam by remember { mutableStateOf<Exam?>(null) }
    var showQuestionBankDialog by remember { mutableStateOf(false) }
    var examToDelete by remember { mutableStateOf<Exam?>(null) }
    var viewingSubmissionsExam by remember { mutableStateOf<Exam?>(null) }
    var gradingTarget by remember { mutableStateOf<Pair<Exam, com.example.data.Student>?>(null) }
    val activeStudentIds = remember(students) { students.map { it.id }.toSet() }
    val unmasteredMistakesCount = remember(allMistakes, activeStudentIds) {
        allMistakes.count { !it.isMastered && it.studentId in activeStudentIds }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingExam = null
                    showCreateDialog = true
                },
                containerColor = AcademicBluePrimary,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("fab_create_exam")
            ) {
                Icon(Icons.Default.Add, contentDescription = "إنشاء امتحان أونلاين")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AppHeader(
                title = "الامتحانات الأونلاين (${exams.size})",
                subtitle = "إنشاء وتحرير الامتحانات، تحليل الأداء وبنك الأخطاء"
            )

            // Quick Actions Bar for Question Bank, Mistake Bank & New Exam
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    OutlinedButton(
                        onClick = { viewModel.setTeacherTab(TeacherTab.MISTAKE_BANK) },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("btn_open_mistake_bank")
                    ) {
                        Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = StatusDanger, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("بنك الأخطاء ($unmasteredMistakesCount)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
                item {
                    OutlinedButton(
                        onClick = { showQuestionBankDialog = true },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("btn_open_question_bank")
                    ) {
                        Icon(Icons.Default.LibraryBooks, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("بنك الأسئلة (${bankQuestions.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
                item {
                    Button(
                        onClick = {
                            editingExam = null
                            showCreateDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("btn_new_exam_bar")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("امتحان جديد", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (exams.isEmpty()) {
                EmptyStateView(
                    title = "لا توجد امتحانات مسجلة",
                    description = "اضغط على زر (+) لإنشاء أول امتحان أونلاين للطلاب",
                    icon = Icons.Default.Quiz
                )
            } else {
                val activeStudentIds = remember(students) { students.map { it.id }.toSet() }
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(exams) { exam ->
                        val questions = remember(exam.questionsJson) { exam.parseQuestions() }
                        val examSubs = allSubmissions.filter { it.examId == exam.id && it.studentId in activeStudentIds }
                        val avgScore = if (examSubs.isNotEmpty()) {
                            examSubs.sumOf { it.score } / examSubs.size
                        } else 0
                        val highScore = examSubs.maxOfOrNull { it.score } ?: 0
                        val isExpired = exam.isExpired(todayDate)

                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(
                                                text = exam.title,
                                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                            )
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = when {
                                                    isExpired -> StatusDangerContainer
                                                    exam.isActive -> StatusSuccessContainer
                                                    else -> StatusDangerContainer
                                                }
                                            ) {
                                                Text(
                                                    text = when {
                                                        isExpired -> "منتهي الصلاحية"
                                                        exam.isActive -> "نشط"
                                                        else -> "مغلق"
                                                    },
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = when {
                                                        isExpired -> StatusDanger
                                                        exam.isActive -> StatusSuccess
                                                        else -> StatusDanger
                                                    },
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                        if (exam.description.isNotBlank()) {
                                            Text(
                                                text = exam.description,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Text(
                                            text = "المادة: ${exam.subject} • المجموعة: ${exam.groupName} • ${exam.durationMinutes} د • ${exam.totalMarks} درجة (النجاح ${exam.passingPercentage}%)",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        if (exam.deadlineDate.isNotBlank()) {
                                            Text(
                                                text = "آخر موعد للتسليم: ${exam.deadlineDate}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (isExpired) StatusDanger else StatusWarning,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                    }

                                    Row {
                                        IconButton(
                                            onClick = {
                                                editingExam = exam
                                                showCreateDialog = true
                                            },
                                            modifier = Modifier.testTag("btn_edit_exam_${exam.id}")
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = "تعديل الامتحان", tint = AcademicBluePrimary)
                                        }
                                        IconButton(
                                            onClick = {
                                                viewModel.duplicateExam(exam)
                                                Toast.makeText(context, "تم نسخ الامتحان بنجاح", Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier.testTag("btn_duplicate_exam_${exam.id}")
                                        ) {
                                            Icon(Icons.Default.ContentCopy, contentDescription = "نسخ الامتحان", tint = AcademicBluePrimary)
                                        }
                                        IconButton(
                                            onClick = { viewModel.toggleExamActive(exam) },
                                            modifier = Modifier.testTag("btn_toggle_exam_${exam.id}")
                                        ) {
                                            Icon(
                                                imageVector = if (exam.isActive) Icons.Default.LockOpen else Icons.Default.Lock,
                                                contentDescription = if (exam.isActive) "إغلاق الامتحان" else "فتح الامتحان",
                                                tint = if (exam.isActive) StatusSuccess else StatusDanger
                                            )
                                        }
                                        IconButton(
                                            onClick = { examToDelete = exam },
                                            modifier = Modifier.testTag("btn_delete_exam_${exam.id}")
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = StatusDanger)
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = AcademicBlueContainer
                                    ) {
                                        Text(
                                            text = "${questions.size} أسئلة",
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = AcademicBluePrimary,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }

                                    if (exam.shuffleQuestions) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = MaterialTheme.colorScheme.surfaceVariant
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                                            ) {
                                                Icon(Icons.Default.Shuffle, contentDescription = null, modifier = Modifier.size(12.dp))
                                                Spacer(modifier = Modifier.width(3.dp))
                                                Text("خلط", fontSize = 10.sp)
                                            }
                                        }
                                    }

                                    if (exam.allowRetake) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = StatusSuccessContainer
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                                            ) {
                                                Icon(Icons.Default.Replay, contentDescription = null, tint = StatusSuccess, modifier = Modifier.size(12.dp))
                                                Spacer(modifier = Modifier.width(3.dp))
                                                Text("إعادة مسموحة", fontSize = 10.sp, color = StatusSuccess, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }

                                    if (examSubs.isNotEmpty()) {
                                        Text(
                                            text = "${examSubs.size} تسليم • متوسط $avgScore/${exam.totalMarks} • أعلى $highScore",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = StatusSuccess,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Button(
                                    onClick = { viewingSubmissionsExam = exam },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("btn_view_submissions_${exam.id}")
                                ) {
                                    Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("عرض ورصد درجات الطلاب (${examSubs.size})", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                    item { Spacer(modifier = Modifier.height(72.dp)) }
                }
            }
        }
    }

    // Create / Edit Exam Dialog
    if (showCreateDialog) {
        CreateExamDialog(
            initialExam = editingExam,
            existingGroups = groups,
            bankQuestions = bankQuestions,
            onDismiss = {
                showCreateDialog = false
                editingExam = null
            },
            onSave = { title, description, subject, group, duration, marks, passingPercentage, questions, shuffle, shuffleOpts, showImmediate, saveToBank, deadlineDate, allowRetake ->
                val targetId = editingExam?.id ?: 0L
                viewModel.saveExam(
                    id = targetId,
                    title = title,
                    groupName = group,
                    durationMinutes = duration,
                    totalMarks = marks,
                    questions = questions,
                    shuffleQuestions = shuffle,
                    showResultImmediately = showImmediate,
                    description = description,
                    saveToBank = saveToBank,
                    bankSubject = subject,
                    deadlineDate = deadlineDate,
                    allowRetake = allowRetake,
                    subject = subject,
                    passingPercentage = passingPercentage,
                    shuffleOptions = shuffleOpts
                )
                showCreateDialog = false
                editingExam = null
                Toast.makeText(
                    context,
                    if (targetId == 0L) "تم نشر الامتحان بنجاح للطلاب" else "تم تحديث الامتحان بنجاح",
                    Toast.LENGTH_SHORT
                ).show()
            }
        )
    }

    // Question Bank Dialog
    if (showQuestionBankDialog) {
        QuestionBankDialog(
            bankQuestions = bankQuestions,
            onAddQuestion = { subject, text, opts, correctIdx, pts, explanation, imgUri, qType, correctText, difficulty ->
                viewModel.addQuestionToBank(subject, text, opts, correctIdx, pts, explanation, imgUri, qType, correctText, difficulty)
                Toast.makeText(context, "تمت إضافة السؤال إلى بنك الأسئلة", Toast.LENGTH_SHORT).show()
            },
            onDeleteQuestion = { viewModel.deleteQuestionFromBank(it) },
            onDismiss = { showQuestionBankDialog = false }
        )
    }

    // Delete confirmation
    if (examToDelete != null) {
        SafeAlertDialog(
            onDismissRequest = { examToDelete = null },
            title = { Text("حذف الامتحان") },
            text = { Text("هل أنت متأكد من حذف ${examToDelete?.title}؟") },
            confirmButton = {
                Button(
                    onClick = {
                        examToDelete?.let { viewModel.deleteExam(it) }
                        examToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDanger)
                ) {
                    Text("حذف")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { examToDelete = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Submissions View Dialog with Analytics Summary
    if (viewingSubmissionsExam != null) {
        val currentExam = viewingSubmissionsExam!!
        val currentExamSubs = remember(allSubmissions, currentExam.id, activeStudentIds) {
            allSubmissions.filter { it.examId == currentExam.id && it.studentId in activeStudentIds }
        }
        val analytics = remember(currentExam, currentExamSubs) {
            ExamMistakeAnalyzer.computeExamAnalytics(currentExam, currentExamSubs)
        }
        SafeAlertDialog(
            onDismissRequest = { viewingSubmissionsExam = null },
            title = {
                Text(
                    text = "تحليلات ودرجات: ${currentExam.title}",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                if (students.isEmpty()) {
                    Text(
                        text = "لا يوجد طلاب مسجلون حالياً. يمكنك إضافة طلاب من تبويب الطلاب.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 380.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (analytics.totalSubmissions > 0) {
                            item {
                                Card(
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = AcademicBlueContainer.copy(alpha = 0.5f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Analytics, contentDescription = null, tint = AcademicBluePrimary, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("ملخص التحليل (${analytics.totalSubmissions} تسليم)", fontWeight = FontWeight.Bold, color = AcademicBluePrimary, fontSize = 13.sp)
                                        }
                                        Text(
                                            text = "نسبة النجاح (≥ ${currentExam.passingPercentage}%): ${analytics.passRatePercent}% (${analytics.passedCount}/${analytics.totalSubmissions}) • متوسط النسبة: ${analytics.averagePercentage}%",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        val topHard = analytics.hardestQuestions.filter { it.wrongCount > 0 }.take(2)
                                        if (topHard.isNotEmpty()) {
                                            Text("أصعب الأسئلة:", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = StatusDanger)
                                            topHard.forEach { hq ->
                                                Text(
                                                    text = "• ${hq.question.questionText} (نسبة الخطأ ${hq.errorRatePercent}%)",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 2
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        items(students) { s ->
                            val sub = allSubmissions.firstOrNull { it.examId == currentExam.id && it.studentId == s.id }
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = s.name,
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.bodyMedium
                                            )
                                            Text(
                                                text = "الكود: ${s.code} • المجموعة: ${s.groupName}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }

                                        if (sub != null) {
                                            val passed = currentExam.isPassing(sub.score, sub.maxScore)
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = if (passed) StatusSuccessContainer else StatusDangerContainer
                                            ) {
                                                Text(
                                                    text = "${sub.score}/${sub.maxScore} (${if (passed) "ناجح" else "دون الحد"})",
                                                    color = if (passed) StatusSuccess else StatusDanger,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 11.sp,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                )
                                            }
                                        } else {
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = MaterialTheme.colorScheme.surfaceVariant
                                            ) {
                                                Text(
                                                    text = "لم ترصد بعد",
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    fontWeight = FontWeight.Normal,
                                                    fontSize = 11.sp,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Button(
                                        onClick = { gradingTarget = Pair(currentExam, s) },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(if (sub != null) "تعديل الدرجة" else "رصد الدرجة", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        viewingSubmissionsExam = null
                        viewModel.setTeacherTab(TeacherTab.MISTAKE_BANK)
                    }) {
                        Text("بنك الأخطاء")
                    }
                    Button(onClick = { viewingSubmissionsExam = null }) {
                        Text("إغلاق")
                    }
                }
            }
        )
    }

    // Assign / Edit Grade Dialog
    if (gradingTarget != null) {
        val targetExam = gradingTarget!!.first
        val targetStudent = gradingTarget!!.second
        val existingSub = allSubmissions.firstOrNull { it.examId == targetExam.id && it.studentId == targetStudent.id }

        var scoreInput by remember(targetExam.id, targetStudent.id) {
            mutableStateOf(existingSub?.score?.toString() ?: targetExam.totalMarks.toString())
        }
        var notesInput by remember(targetExam.id, targetStudent.id) {
            mutableStateOf("")
        }

        SafeAlertDialog(
            onDismissRequest = { gradingTarget = null },
            title = {
                Column {
                    Text("رصد درجة امتحان", fontWeight = FontWeight.Bold)
                    Text(
                        text = "الطالب: ${targetStudent.name} (${targetStudent.code})",
                        style = MaterialTheme.typography.bodySmall,
                        color = AcademicBluePrimary
                    )
                    Text(
                        text = "الامتحان: ${targetExam.title} (الدرجة النهائية: ${targetExam.totalMarks})",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = scoreInput,
                        onValueChange = { scoreInput = it.filter { ch -> ch.isDigit() } },
                        label = { Text("درجة الطالب (من ${targetExam.totalMarks})") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = notesInput,
                        onValueChange = { notesInput = it },
                        label = { Text("ملاحظة أو تقييم للطالب (اختياري)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                val dismissInput = rememberActiveInputDismisser()
                Button(
                    onClick = {
                        dismissInput()
                        val score = scoreInput.toIntOrNull() ?: 0
                        viewModel.assignStudentExamGrade(
                            examId = targetExam.id,
                            studentId = targetStudent.id,
                            score = score,
                            maxScore = targetExam.totalMarks,
                            notes = notesInput
                        )
                        Toast.makeText(context, "تم حفظ درجة ${targetStudent.name} بنجاح", Toast.LENGTH_SHORT).show()
                        gradingTarget = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary)
                ) {
                    Text("حفظ الدرجة")
                }
            },
            dismissButton = {
                val dismissInput = rememberActiveInputDismisser()
                OutlinedButton(onClick = {
                    dismissInput()
                    gradingTarget = null
                }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

private fun questionTypeLabel(qType: String): String {
    return when (qType) {
        ExamQuestion.TYPE_TRUE_FALSE -> "صح وخطأ"
        ExamQuestion.TYPE_SHORT_ANSWER -> "إجابة قصيرة"
        else -> "اختيار من متعدد"
    }
}

@Composable
fun CreateExamDialog(
    initialExam: Exam? = null,
    existingGroups: List<String>,
    bankQuestions: List<QuestionBankItem>,
    onDismiss: () -> Unit,
    onSave: (
        title: String,
        description: String,
        subject: String,
        group: String,
        duration: Int,
        marks: Int,
        passingPercentage: Int,
        questions: List<ExamQuestion>,
        shuffleQuestions: Boolean,
        shuffleOptions: Boolean,
        showResultImmediately: Boolean,
        saveToBank: Boolean,
        deadlineDate: String,
        allowRetake: Boolean
    ) -> Unit
) {
    val context = LocalContext.current
    var title by remember(initialExam?.id) { mutableStateOf(initialExam?.title ?: "") }
    var description by remember(initialExam?.id) { mutableStateOf(initialExam?.description ?: "") }
    var subject by remember(initialExam?.id) { mutableStateOf(initialExam?.subject ?: "عام") }
    var group by remember(initialExam?.id) { mutableStateOf(initialExam?.groupName ?: "الكل") }
    var durationStr by remember(initialExam?.id) { mutableStateOf((initialExam?.durationMinutes ?: 25).toString()) }
    var passingStr by remember(initialExam?.id) { mutableStateOf((initialExam?.passingPercentage ?: 50).toString()) }
    var deadlineDate by remember(initialExam?.id) { mutableStateOf(initialExam?.deadlineDate ?: "") }
    var allowRetake by remember(initialExam?.id) { mutableStateOf(initialExam?.allowRetake ?: false) }
    var shuffleQuestions by remember(initialExam?.id) { mutableStateOf(initialExam?.shuffleQuestions ?: false) }
    var shuffleOptions by remember(initialExam?.id) { mutableStateOf(initialExam?.shuffleOptions ?: false) }
    var showResultImmediately by remember(initialExam?.id) { mutableStateOf(initialExam?.showResultImmediately ?: true) }
    var saveToBank by remember(initialExam?.id) { mutableStateOf(initialExam == null) }
    var showBankPicker by remember { mutableStateOf(false) }

    val questionsList = remember(initialExam?.id) {
        mutableStateListOf<ExamQuestion>().apply {
            if (initialExam != null) {
                addAll(initialExam.parseQuestions())
            }
        }
    }

    // Draft Question Editor
    var draftQuestionType by remember { mutableStateOf(ExamQuestion.TYPE_MCQ) }
    var draftDifficulty by remember { mutableStateOf(ExamQuestion.DIFFICULTY_MEDIUM) }
    var draftTopic by remember { mutableStateOf("") }
    var draftQuestionText by remember { mutableStateOf("") }
    var opt1 by remember { mutableStateOf("") }
    var opt2 by remember { mutableStateOf("") }
    var opt3 by remember { mutableStateOf("") }
    var opt4 by remember { mutableStateOf("") }
    var correctIndex by remember { mutableIntStateOf(0) }
    var draftCorrectTextAnswer by remember { mutableStateOf("") }
    var pointsStr by remember { mutableStateOf("5") }
    var explanation by remember { mutableStateOf("") }
    var imageUri by remember { mutableStateOf("") }

    val nextWeekDate = remember {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, 7)
        SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(cal.time)
    }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val copied = QrCodeHelper.copyPickedImageToInternal(context, uri)
            if (copied != null) {
                imageUri = copied
                Toast.makeText(context, "تم إرفاق الصورة بالسؤال", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun appendDraftQuestion(): Boolean {
        if (draftQuestionText.isBlank()) return false
        val pts = pointsStr.toIntOrNull()?.coerceAtLeast(1) ?: 5
        val newId = (questionsList.maxOfOrNull { it.id } ?: 0) + 1
        val cleanTopic = draftTopic.trim()
        val question = when (draftQuestionType) {
            ExamQuestion.TYPE_TRUE_FALSE -> {
                val tfOpts = listOf("صح", "خطأ")
                val idx = correctIndex.coerceIn(0, 1)
                ExamQuestion(
                    id = newId,
                    questionText = draftQuestionText.trim(),
                    options = tfOpts,
                    correctOptionIndex = idx,
                    points = pts,
                    explanation = explanation.ifBlank { "الإجابة الصحيحة هي: ${tfOpts[idx]}" },
                    imageUri = imageUri,
                    questionType = ExamQuestion.TYPE_TRUE_FALSE,
                    difficulty = draftDifficulty,
                    topic = cleanTopic
                )
            }
            ExamQuestion.TYPE_SHORT_ANSWER -> {
                val modelAns = draftCorrectTextAnswer.trim()
                if (modelAns.isBlank()) return false
                ExamQuestion(
                    id = newId,
                    questionText = draftQuestionText.trim(),
                    options = emptyList(),
                    correctOptionIndex = 0,
                    points = pts,
                    explanation = explanation.ifBlank { "الإجابة النموذجية: $modelAns" },
                    imageUri = imageUri,
                    questionType = ExamQuestion.TYPE_SHORT_ANSWER,
                    correctTextAnswer = modelAns,
                    difficulty = draftDifficulty,
                    topic = cleanTopic
                )
            }
            else -> {
                val opts = listOf(opt1, opt2, opt3, opt4).mapIndexed { idx, s ->
                    s.ifBlank { "خيار ${idx + 1}" }
                }
                ExamQuestion(
                    id = newId,
                    questionText = draftQuestionText.trim(),
                    options = opts,
                    correctOptionIndex = correctIndex.coerceIn(0, 3),
                    points = pts,
                    explanation = explanation.ifBlank { "الإجابة الصحيحة هي: ${opts[correctIndex.coerceIn(0, 3)]}" },
                    imageUri = imageUri,
                    questionType = ExamQuestion.TYPE_MCQ,
                    difficulty = draftDifficulty,
                    topic = cleanTopic
                )
            }
        }
        questionsList.add(question)
        draftQuestionText = ""
        opt1 = ""
        opt2 = ""
        opt3 = ""
        opt4 = ""
        correctIndex = 0
        draftCorrectTextAnswer = ""
        explanation = ""
        imageUri = ""
        draftTopic = ""
        return true
    }

    val totalCalculatedMarks = remember(questionsList.size, questionsList.toList(), pointsStr, draftQuestionText) {
        val listTotal = questionsList.sumOf { it.points }
        val draftPts = if (draftQuestionText.isNotBlank()) (pointsStr.toIntOrNull() ?: 5) else 0
        (listTotal + draftPts).coerceAtLeast(1)
    }

    SafeAlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(if (initialExam != null) "تعديل الامتحان" else "إنشاء امتحان أونلاين متكامل", fontWeight = FontWeight.Bold)
                Text(
                    text = "الأسئلة المضافة: ${questionsList.size} • الدرجة الكلية: $totalCalculatedMarks",
                    style = MaterialTheme.typography.bodySmall,
                    color = AcademicBluePrimary
                )
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 440.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("عنوان الامتحان") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_exam_title")
                    )
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = subject,
                            onValueChange = { subject = it },
                            label = { Text("المادة") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = passingStr,
                            onValueChange = { passingStr = it.filter { ch -> ch.isDigit() } },
                            label = { Text("نسبة النجاح %") },
                            singleLine = true,
                            modifier = Modifier.weight(0.9f)
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("تعليمات الامتحان (اختياري)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = group,
                            onValueChange = { group = it },
                            label = { Text("المجموعة") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = durationStr,
                            onValueChange = { durationStr = it.filter { ch -> ch.isDigit() } },
                            label = { Text("المدة (دقيقة)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (existingGroups.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            item {
                                FilterChip(selected = group == "الكل", onClick = { group = "الكل" }, label = { Text("الكل", fontSize = 10.sp) })
                            }
                            items(existingGroups) { grp ->
                                FilterChip(selected = group == grp, onClick = { group = grp }, label = { Text(grp, fontSize = 10.sp) })
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = deadlineDate,
                        onValueChange = { deadlineDate = it },
                        label = { Text("آخر موعد للتسليم (yyyy-MM-dd اختياري)") },
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Event, contentDescription = null) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_exam_deadline")
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = deadlineDate.isBlank(),
                            onClick = { deadlineDate = "" },
                            label = { Text("مفتوح دائماً", fontSize = 10.sp) }
                        )
                        FilterChip(
                            selected = deadlineDate == nextWeekDate,
                            onClick = { deadlineDate = nextWeekDate },
                            label = { Text("لمدة أسبوع ($nextWeekDate)", fontSize = 10.sp) }
                        )
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("السماح بإعادة المحاولة للطالب", style = MaterialTheme.typography.bodySmall)
                        Switch(
                            checked = allowRetake,
                            onCheckedChange = { allowRetake = it },
                            modifier = Modifier.testTag("switch_allow_retake")
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("ترتيب عشوائي للأسئلة لكل طالب", style = MaterialTheme.typography.bodySmall)
                        Switch(checked = shuffleQuestions, onCheckedChange = { shuffleQuestions = it })
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("خلط ترتيب الاختيارات (أ/ب/ج/د)", style = MaterialTheme.typography.bodySmall)
                        Switch(checked = shuffleOptions, onCheckedChange = { shuffleOptions = it })
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("إظهار الدرجة والتصحيح فور التسليم", style = MaterialTheme.typography.bodySmall)
                        Switch(checked = showResultImmediately, onCheckedChange = { showResultImmediately = it })
                    }
                    if (initialExam == null) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("حفظ الأسئلة في بنك الأسئلة", style = MaterialTheme.typography.bodySmall)
                            Switch(checked = saveToBank, onCheckedChange = { saveToBank = it })
                        }
                    }
                }

                // Already added questions preview
                if (questionsList.isNotEmpty()) {
                    item {
                        Text(
                            text = "الأسئلة المضافة (${questionsList.size}):",
                            fontWeight = FontWeight.Bold,
                            color = StatusSuccess
                        )
                    }
                    items(questionsList.size) { index ->
                        val q = questionsList[index]
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = AcademicBlueContainer.copy(alpha = 0.4f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${index + 1}. ${q.questionText}",
                                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "${questionTypeLabel(q.questionType)} • ${ExamQuestion.difficultyLabel(q.difficulty)} • ${q.points} درجات${if (q.imageUri.isNotBlank()) " • صورة" else ""}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(onClick = { questionsList.removeAt(index) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف السؤال", tint = StatusDanger)
                                }
                            }
                        }
                    }
                }

                // Import from Question Bank
                if (bankQuestions.isNotEmpty()) {
                    item {
                        OutlinedButton(
                            onClick = { showBankPicker = true },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_import_from_bank")
                        ) {
                            Icon(Icons.Default.LibraryBooks, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("استيراد سؤال من بنك الأسئلة (${bankQuestions.size})", fontSize = 12.sp)
                        }
                    }
                }

                // Add New Question Form
                item {
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("إضافة سؤال جديد للامتحان:", fontWeight = FontWeight.Bold, color = AcademicBluePrimary)
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        item {
                            FilterChip(
                                selected = draftQuestionType == ExamQuestion.TYPE_MCQ,
                                onClick = {
                                    draftQuestionType = ExamQuestion.TYPE_MCQ
                                    correctIndex = 0
                                },
                                label = { Text("اختيار من متعدد", fontSize = 11.sp) },
                                modifier = Modifier.testTag("chip_qtype_mcq")
                            )
                        }
                        item {
                            FilterChip(
                                selected = draftQuestionType == ExamQuestion.TYPE_TRUE_FALSE,
                                onClick = {
                                    draftQuestionType = ExamQuestion.TYPE_TRUE_FALSE
                                    correctIndex = 0
                                },
                                label = { Text("صح وخطأ", fontSize = 11.sp) },
                                modifier = Modifier.testTag("chip_qtype_tf")
                            )
                        }
                        item {
                            FilterChip(
                                selected = draftQuestionType == ExamQuestion.TYPE_SHORT_ANSWER,
                                onClick = { draftQuestionType = ExamQuestion.TYPE_SHORT_ANSWER },
                                label = { Text("إجابة قصيرة", fontSize = 11.sp) },
                                modifier = Modifier.testTag("chip_qtype_short")
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(
                            ExamQuestion.DIFFICULTY_EASY,
                            ExamQuestion.DIFFICULTY_MEDIUM,
                            ExamQuestion.DIFFICULTY_HARD
                        ).forEach { diff ->
                            item {
                                FilterChip(
                                    selected = draftDifficulty == diff,
                                    onClick = { draftDifficulty = diff },
                                    label = { Text("صعوبة: ${ExamQuestion.difficultyLabel(diff)}", fontSize = 10.sp) }
                                )
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = draftTopic,
                        onValueChange = { draftTopic = it },
                        label = { Text("الدرس / الموضوع (اختياري لبنك الأخطاء)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = draftQuestionText,
                        onValueChange = { draftQuestionText = it },
                        label = { Text("نص السؤال") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_draft_question")
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = pointsStr,
                            onValueChange = { pointsStr = it.filter { ch -> ch.isDigit() } },
                            label = { Text("درجة السؤال") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedButton(
                            onClick = {
                                imagePicker.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1.3f)
                        ) {
                            Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (imageUri.isNotBlank()) "تغيير الصورة" else "إرفاق صورة", fontSize = 11.sp)
                        }
                    }

                    if (imageUri.isNotBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(110.dp)
                                .clip(RoundedCornerShape(10.dp))
                        ) {
                            AsyncImage(
                                model = File(imageUri),
                                contentDescription = "صورة السؤال",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }

                item {
                    when (draftQuestionType) {
                        ExamQuestion.TYPE_TRUE_FALSE -> {
                            Text("حدد الإجابة الصحيحة:", style = MaterialTheme.typography.bodySmall)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                listOf("صح", "خطأ").forEachIndexed { idx, label ->
                                    FilterChip(
                                        selected = correctIndex == idx,
                                        onClick = { correctIndex = idx },
                                        label = { Text(label, fontWeight = FontWeight.Bold) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                        ExamQuestion.TYPE_SHORT_ANSWER -> {
                            OutlinedTextField(
                                value = draftCorrectTextAnswer,
                                onValueChange = { draftCorrectTextAnswer = it },
                                label = { Text("الإجابة النموذجية المختصرة") },
                                supportingText = { Text("التصحيح التلقائي يتجاهل الهمزات والمسافات الزائدة") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_short_model_answer")
                            )
                        }
                        else -> {
                            Text("الخيارات (حدد الدائرة للإجابة الصحيحة):", style = MaterialTheme.typography.bodySmall)
                            val labels = listOf("أ", "ب", "ج", "د")
                            val values = listOf(opt1, opt2, opt3, opt4)
                            val setters = listOf<(String) -> Unit>(
                                { opt1 = it },
                                { opt2 = it },
                                { opt3 = it },
                                { opt4 = it }
                            )
                            values.forEachIndexed { idx, value ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    RadioButton(selected = correctIndex == idx, onClick = { correctIndex = idx })
                                    OutlinedTextField(
                                        value = value,
                                        onValueChange = setters[idx],
                                        label = { Text("الخيار ${labels[idx]}") },
                                        singleLine = true,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = explanation,
                        onValueChange = { explanation = it },
                        label = { Text("توضيح الإجابة الصحيحة للطلاب (اختياري)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedButton(
                        onClick = {
                            if (appendDraftQuestion()) {
                                Toast.makeText(context, "تمت إضافة السؤال (${questionsList.size})", Toast.LENGTH_SHORT).show()
                            } else {
                                val msg = if (draftQuestionType == ExamQuestion.TYPE_SHORT_ANSWER && draftQuestionText.isNotBlank()) {
                                    "اكتب الإجابة النموذجية للسؤال"
                                } else {
                                    "اكتب نص السؤال أولاً"
                                }
                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_add_question_to_exam")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("إضافة هذا السؤال وإعداد سؤال آخر")
                    }
                }
            }
        },
        confirmButton = {
            val dismissInput = rememberActiveInputDismisser()
            Button(
                onClick = {
                    if (draftQuestionText.isNotBlank()) {
                        appendDraftQuestion()
                    }
                    if (title.isNotBlank() && questionsList.isNotEmpty()) {
                        dismissInput()
                        val duration = durationStr.toIntOrNull()?.coerceAtLeast(1) ?: 25
                        val totalMarks = questionsList.sumOf { it.points }.coerceAtLeast(1)
                        val passingPct = (passingStr.toIntOrNull() ?: 50).coerceIn(1, 100)
                        onSave(
                            title,
                            description,
                            subject,
                            group,
                            duration,
                            totalMarks,
                            passingPct,
                            questionsList.toList(),
                            shuffleQuestions,
                            shuffleOptions,
                            showResultImmediately,
                            saveToBank,
                            deadlineDate.trim(),
                            allowRetake
                        )
                    } else {
                        Toast.makeText(context, "أدخل عنوان الامتحان وسؤالاً واحداً على الأقل", Toast.LENGTH_SHORT).show()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary),
                modifier = Modifier.testTag("btn_publish_exam")
            ) {
                Text(if (initialExam != null) "حفظ التعديلات (${questionsList.size})" else "نشر الامتحان (${questionsList.size})")
            }
        },
        dismissButton = {
            val dismissInput = rememberActiveInputDismisser()
            OutlinedButton(onClick = {
                dismissInput()
                onDismiss()
            }) {
                Text("إلغاء")
            }
        }
    )

    if (showBankPicker) {
        SafeAlertDialog(
            onDismissRequest = { showBankPicker = false },
            title = { Text("اختر سؤالاً من بنك الأسئلة") },
            text = {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 300.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(bankQuestions, key = { it.id }) { bankItem ->
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = AcademicBlueContainer.copy(alpha = 0.35f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val nextId = (questionsList.maxOfOrNull { it.id } ?: 0) + 1
                                    questionsList.add(bankItem.toExamQuestion(nextId))
                                    showBankPicker = false
                                    Toast.makeText(context, "تم استيراد السؤال للامتحان", Toast.LENGTH_SHORT).show()
                                }
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(bankItem.questionText, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                                Text(
                                    text = "${bankItem.subject} • ${questionTypeLabel(bankItem.questionType)} • ${bankItem.points} درجات",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AcademicBluePrimary
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                OutlinedButton(onClick = { showBankPicker = false }) {
                    Text("إغلاق")
                }
            }
        )
    }
}

@Composable
private fun QuestionBankDialog(
    bankQuestions: List<QuestionBankItem>,
    onAddQuestion: (
        subject: String,
        questionText: String,
        options: List<String>,
        correctIdx: Int,
        points: Int,
        explanation: String,
        imageUri: String,
        questionType: String,
        correctTextAnswer: String,
        difficulty: String
    ) -> Unit,
    onDeleteQuestion: (QuestionBankItem) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var showAddForm by remember { mutableStateOf(false) }
    var difficultyFilter by remember { mutableStateOf("الكل") }
    var subject by remember { mutableStateOf("عام") }
    var qType by remember { mutableStateOf(ExamQuestion.TYPE_MCQ) }
    var difficulty by remember { mutableStateOf(ExamQuestion.DIFFICULTY_MEDIUM) }
    var qText by remember { mutableStateOf("") }
    var o1 by remember { mutableStateOf("") }
    var o2 by remember { mutableStateOf("") }
    var o3 by remember { mutableStateOf("") }
    var o4 by remember { mutableStateOf("") }
    var correctIdx by remember { mutableIntStateOf(0) }
    var correctTextAnswer by remember { mutableStateOf("") }
    var ptsStr by remember { mutableStateOf("5") }
    var explanation by remember { mutableStateOf("") }
    var imageUri by remember { mutableStateOf("") }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            imageUri = QrCodeHelper.copyPickedImageToInternal(context, uri) ?: ""
        }
    }

    SafeAlertDialog(
        onDismissRequest = onDismiss,
        title = {
            val dismissInput = rememberActiveInputDismisser()
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("بنك الأسئلة (${bankQuestions.size})", fontWeight = FontWeight.Bold)
                OutlinedButton(onClick = {
                    dismissInput()
                    showAddForm = !showAddForm
                }) {
                    Text(if (showAddForm) "عرض البنك" else "+ سؤال", fontSize = 11.sp)
                }
            }
        },
        text = {
            if (showAddForm) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 350.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            item {
                                FilterChip(
                                    selected = qType == ExamQuestion.TYPE_MCQ,
                                    onClick = { qType = ExamQuestion.TYPE_MCQ; correctIdx = 0 },
                                    label = { Text("اختيار من متعدد", fontSize = 10.sp) }
                                )
                            }
                            item {
                                FilterChip(
                                    selected = qType == ExamQuestion.TYPE_TRUE_FALSE,
                                    onClick = { qType = ExamQuestion.TYPE_TRUE_FALSE; correctIdx = 0 },
                                    label = { Text("صح وخطأ", fontSize = 10.sp) }
                                )
                            }
                            item {
                                FilterChip(
                                    selected = qType == ExamQuestion.TYPE_SHORT_ANSWER,
                                    onClick = { qType = ExamQuestion.TYPE_SHORT_ANSWER },
                                    label = { Text("إجابة قصيرة", fontSize = 10.sp) }
                                )
                            }
                        }
                    }
                    item {
                        OutlinedTextField(value = subject, onValueChange = { subject = it }, label = { Text("المادة / الصف") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                    item {
                        OutlinedTextField(value = qText, onValueChange = { qText = it }, label = { Text("نص السؤال") }, modifier = Modifier.fillMaxWidth())
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(value = ptsStr, onValueChange = { ptsStr = it.filter { ch -> ch.isDigit() } }, label = { Text("الدرجة") }, singleLine = true, modifier = Modifier.weight(1f))
                            OutlinedButton(
                                onClick = { imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                                modifier = Modifier.weight(1.2f)
                            ) {
                                Text(if (imageUri.isNotBlank()) "تم اختيار صورة" else "إرفاق صورة", fontSize = 11.sp)
                            }
                        }
                    }
                    item {
                        when (qType) {
                            ExamQuestion.TYPE_TRUE_FALSE -> {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("صح", "خطأ").forEachIndexed { idx, label ->
                                        FilterChip(
                                            selected = correctIdx == idx,
                                            onClick = { correctIdx = idx },
                                            label = { Text(label) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }
                            ExamQuestion.TYPE_SHORT_ANSWER -> {
                                OutlinedTextField(
                                    value = correctTextAnswer,
                                    onValueChange = { correctTextAnswer = it },
                                    label = { Text("الإجابة النموذجية") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            else -> {
                                val labels = listOf("أ", "ب", "ج", "د")
                                val vals = listOf(o1, o2, o3, o4)
                                val sets = listOf<(String) -> Unit>({ o1 = it }, { o2 = it }, { o3 = it }, { o4 = it })
                                vals.forEachIndexed { idx, v ->
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        RadioButton(selected = correctIdx == idx, onClick = { correctIdx = idx })
                                        OutlinedTextField(value = v, onValueChange = sets[idx], label = { Text(labels[idx]) }, singleLine = true, modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(
                                ExamQuestion.DIFFICULTY_EASY,
                                ExamQuestion.DIFFICULTY_MEDIUM,
                                ExamQuestion.DIFFICULTY_HARD
                            ).forEach { diff ->
                                item {
                                    FilterChip(
                                        selected = difficulty == diff,
                                        onClick = { difficulty = diff },
                                        label = { Text(ExamQuestion.difficultyLabel(diff), fontSize = 10.sp) }
                                    )
                                }
                            }
                        }
                    }
                    item {
                        OutlinedTextField(value = explanation, onValueChange = { explanation = it }, label = { Text("التوضيح (اختياري)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                    item {
                        Button(
                            onClick = {
                                val validShort = qType != ExamQuestion.TYPE_SHORT_ANSWER || correctTextAnswer.isNotBlank()
                                if (qText.isNotBlank() && validShort) {
                                    val opts = when (qType) {
                                        ExamQuestion.TYPE_TRUE_FALSE -> listOf("صح", "خطأ")
                                        ExamQuestion.TYPE_SHORT_ANSWER -> emptyList()
                                        else -> listOf(o1, o2, o3, o4).mapIndexed { i, s -> s.ifBlank { "خيار ${i + 1}" } }
                                    }
                                    onAddQuestion(
                                        subject,
                                        qText,
                                        opts,
                                        correctIdx,
                                        ptsStr.toIntOrNull() ?: 5,
                                        explanation,
                                        imageUri,
                                        qType,
                                        correctTextAnswer,
                                        difficulty
                                    )
                                    qText = ""; o1 = ""; o2 = ""; o3 = ""; o4 = ""; correctTextAnswer = ""; explanation = ""; imageUri = ""
                                    showAddForm = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("حفظ في بنك الأسئلة")
                        }
                    }
                }
            } else if (bankQuestions.isEmpty()) {
                Text(
                    text = "بنك الأسئلة فارغ حالياً. يمكنك إضافة أسئلة هنا أو سيتم حفظها تلقائياً عند إنشاء امتحان جديد.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                val filteredBank = remember(bankQuestions, difficultyFilter) {
                    if (difficultyFilter == "الكل") bankQuestions else bankQuestions.filter { it.difficulty == difficultyFilter }
                }
                Column {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        item {
                            FilterChip(selected = difficultyFilter == "الكل", onClick = { difficultyFilter = "الكل" }, label = { Text("الكل", fontSize = 10.sp) })
                        }
                        listOf(
                            ExamQuestion.DIFFICULTY_EASY,
                            ExamQuestion.DIFFICULTY_MEDIUM,
                            ExamQuestion.DIFFICULTY_HARD
                        ).forEach { diff ->
                            item {
                                FilterChip(
                                    selected = difficultyFilter == diff,
                                    onClick = { difficultyFilter = diff },
                                    label = { Text(ExamQuestion.difficultyLabel(diff), fontSize = 10.sp) }
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 290.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filteredBank, key = { it.id }) { item ->
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(item.questionText, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                                        Text(
                                            text = "${item.subject} • ${questionTypeLabel(item.questionType)} • ${ExamQuestion.difficultyLabel(item.difficulty)} • ${item.points} درجات",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = AcademicBluePrimary
                                        )
                                    }
                                    IconButton(onClick = { onDeleteQuestion(item) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "حذف من البنك", tint = StatusDanger)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            val dismissInput = rememberActiveInputDismisser()
            Button(
                onClick = {
                    dismissInput()
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary)
            ) {
                Text("إغلاق")
            }
        }
    )
}
