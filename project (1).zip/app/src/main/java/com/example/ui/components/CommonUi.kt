package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.View
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AlertDialogDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusManager
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalTextToolbar
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.SoftwareKeyboardController
import androidx.compose.ui.platform.TextToolbar
import androidx.compose.ui.platform.TextToolbarStatus
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import com.example.BuildConfig
import com.example.R
import com.example.data.AttendanceRecord
import com.example.data.HomeworkRecord
import com.example.data.Student
import com.example.ui.theme.AcademicBlueContainer
import com.example.ui.theme.AcademicBluePrimary
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusDangerContainer
import com.example.ui.theme.StatusInfo
import com.example.ui.theme.StatusInfoContainer
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessContainer
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningContainer

import java.util.WeakHashMap

/**
 * Guards Compose [TextToolbar] against re-entrant hide/show calls and detached-window
 * FloatingActionMode / Magnifier surface races.
 */
class SafeTextToolbar(
    private val delegate: TextToolbar,
    private val view: View
) : TextToolbar {
    private var isHiding = false
    private var isShowing = false

    fun matchesView(candidateView: View): Boolean = view === candidateView

    fun matches(candidateView: View, candidateDelegate: TextToolbar): Boolean {
        return view === candidateView && (delegate === candidateDelegate || this === candidateDelegate)
    }

    override val status: TextToolbarStatus
        get() = delegate.status

    override fun showMenu(
        rect: Rect,
        onCopyRequested: (() -> Unit)?,
        onPasteRequested: (() -> Unit)?,
        onCutRequested: (() -> Unit)?,
        onSelectAllRequested: (() -> Unit)?
    ) {
        if (isHiding || isShowing) return
        if (!view.isAttachedToWindow ||
            view.windowToken == null ||
            !view.isLaidOut ||
            view.width <= 0 ||
            view.height <= 0 ||
            rect.isEmpty
        ) {
            return
        }
        isShowing = true
        try {
            delegate.showMenu(
                rect = rect,
                onCopyRequested = onCopyRequested,
                onPasteRequested = onPasteRequested,
                onCutRequested = onCutRequested,
                onSelectAllRequested = onSelectAllRequested
            )
        } catch (_: Throwable) {
        } finally {
            isShowing = false
        }
    }

    override fun hide() {
        if (isHiding || delegate.status != TextToolbarStatus.Shown) return
        isHiding = true
        try {
            if (view.isAttachedToWindow) {
                delegate.hide()
            }
        } catch (_: Throwable) {
        } finally {
            isHiding = false
        }
    }
}

private val windowSafeToolbarCache = WeakHashMap<View, SafeTextToolbar>()

@Composable
fun ProvideWindowSafeTextToolbar(content: @Composable () -> Unit) {
    val delegate = LocalTextToolbar.current
    val view = LocalView.current

    if (delegate is SafeTextToolbar && delegate.matchesView(view)) {
        content()
        return
    }

    val safeToolbar = remember(delegate, view) {
        if (delegate is SafeTextToolbar) {
            delegate
        } else {
            val existing = windowSafeToolbarCache[view]
            if (existing != null && existing.matches(view, delegate)) {
                existing
            } else {
                SafeTextToolbar(delegate = delegate, view = view).also {
                    windowSafeToolbarCache[view] = it
                }
            }
        }
    }

    DisposableEffect(safeToolbar) {
        onDispose {
            safeToolbar.hide()
        }
    }

    CompositionLocalProvider(LocalTextToolbar provides safeToolbar) {
        content()
    }
}

fun dismissActiveInput(
    focusManager: FocusManager,
    textToolbar: TextToolbar,
    keyboardController: SoftwareKeyboardController?
) {
    try {
        if (textToolbar.status == TextToolbarStatus.Shown) {
            textToolbar.hide()
        }
    } catch (_: Throwable) {
    }
    try {
        focusManager.clearFocus(force = true)
    } catch (_: Throwable) {
    }
    try {
        keyboardController?.hide()
    } catch (_: Throwable) {
    }
}

@Composable
fun rememberActiveInputDismisser(): () -> Unit {
    val focusManager = LocalFocusManager.current
    val textToolbar = LocalTextToolbar.current
    val keyboardController = LocalSoftwareKeyboardController.current
    return remember(focusManager, textToolbar, keyboardController) {
        {
            dismissActiveInput(
                focusManager = focusManager,
                textToolbar = textToolbar,
                keyboardController = keyboardController
            )
        }
    }
}

@Composable
fun ClearInputFocusEffect(key: Any?) {
    val dismissInput = rememberActiveInputDismisser()
    LaunchedEffect(key) {
        dismissInput()
    }
}

@Composable
fun SafeAlertDialog(
    onDismissRequest: () -> Unit,
    confirmButton: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    dismissButton: (@Composable () -> Unit)? = null,
    icon: (@Composable () -> Unit)? = null,
    title: (@Composable () -> Unit)? = null,
    text: (@Composable () -> Unit)? = null,
    shape: Shape = AlertDialogDefaults.shape,
    containerColor: Color = AlertDialogDefaults.containerColor,
    iconContentColor: Color = AlertDialogDefaults.iconContentColor,
    titleContentColor: Color = AlertDialogDefaults.titleContentColor,
    textContentColor: Color = AlertDialogDefaults.textContentColor,
    tonalElevation: Dp = AlertDialogDefaults.TonalElevation,
    properties: DialogProperties = DialogProperties()
) {
    var dialogInputCleanup by remember { mutableStateOf<(() -> Unit)?>(null) }

    AlertDialog(
        onDismissRequest = {
            dialogInputCleanup?.invoke()
            onDismissRequest()
        },
        confirmButton = {
            ProvideWindowSafeTextToolbar {
                val cleanup = rememberActiveInputDismisser()
                DisposableEffect(cleanup) {
                    dialogInputCleanup = cleanup
                    onDispose {
                        if (dialogInputCleanup === cleanup) {
                            dialogInputCleanup = null
                        }
                    }
                }
                confirmButton()
            }
        },
        modifier = modifier,
        dismissButton = dismissButton?.let { btn ->
            {
                ProvideWindowSafeTextToolbar {
                    btn()
                }
            }
        },
        icon = icon,
        title = title?.let { t ->
            {
                ProvideWindowSafeTextToolbar {
                    t()
                }
            }
        },
        text = text?.let { body ->
            {
                ProvideWindowSafeTextToolbar {
                    body()
                }
            }
        },
        shape = shape,
        containerColor = containerColor,
        iconContentColor = iconContentColor,
        titleContentColor = titleContentColor,
        textContentColor = textContentColor,
        tonalElevation = tonalElevation,
        properties = properties
    )
}

@Composable
fun AppHeader(
    title: String,
    subtitle: String? = null,
    onBack: (() -> Unit)? = null,
    actions: @Composable (() -> Unit)? = null
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 2.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                if (onBack != null) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("btn_back")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع",
                            tint = AcademicBluePrimary
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        ),
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (!subtitle.isNullOrBlank()) {
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            if (actions != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    actions()
                }
            }
        }
    }
}

@Composable
fun StatMetricCard(
    title: String,
    value: String,
    icon: ImageVector,
    tintColor: Color,
    containerColor: Color,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    Card(
        modifier = modifier
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                    color = tintColor
                )
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.8f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = tintColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 22.sp
                ),
                color = tintColor
            )
        }
    }
}

@Composable
fun StatusBadge(
    text: String,
    color: Color,
    bgColor: Color,
    icon: ImageVector? = null,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = bgColor,
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
            }
            Text(
                text = text,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                ),
                color = color
            )
        }
    }
}

@Composable
fun AttendanceBadge(status: String) {
    when (status) {
        AttendanceRecord.STATUS_PRESENT -> {
            StatusBadge(
                text = "حاضر اليوم",
                color = StatusSuccess,
                bgColor = StatusSuccessContainer,
                icon = Icons.Default.CheckCircle
            )
        }
        AttendanceRecord.STATUS_ABSENT -> {
            StatusBadge(
                text = "غائب",
                color = StatusDanger,
                bgColor = StatusDangerContainer,
                icon = Icons.Default.Close
            )
        }
        AttendanceRecord.STATUS_LATE -> {
            StatusBadge(
                text = "متأخر",
                color = StatusWarning,
                bgColor = StatusWarningContainer,
                icon = Icons.Default.Warning
            )
        }
        AttendanceRecord.STATUS_EXCUSED -> {
            StatusBadge(
                text = "معذور",
                color = StatusInfo,
                bgColor = StatusInfoContainer,
                icon = Icons.Default.Info
            )
        }
        else -> {
            StatusBadge(
                text = "لم تسجل بعد",
                color = Color.Gray,
                bgColor = Color(0xFFF1F5F9)
            )
        }
    }
}

@Composable
fun HomeworkBadge(status: String) {
    when (status) {
        HomeworkRecord.STATUS_COMPLETED -> {
            StatusBadge(
                text = "تم حل الواجب",
                color = StatusSuccess,
                bgColor = StatusSuccessContainer,
                icon = Icons.Default.CheckCircle
            )
        }
        HomeworkRecord.STATUS_PARTIAL -> {
            StatusBadge(
                text = "حل جزئي",
                color = StatusWarning,
                bgColor = StatusWarningContainer,
                icon = Icons.Default.Warning
            )
        }
        HomeworkRecord.STATUS_NOT_COMPLETED -> {
            StatusBadge(
                text = "لم يحل الواجب",
                color = StatusDanger,
                bgColor = StatusDangerContainer,
                icon = Icons.Default.Close
            )
        }
        else -> {
            StatusBadge(
                text = "قيد المتابعة",
                color = Color.Gray,
                bgColor = Color(0xFFF1F5F9)
            )
        }
    }
}

@Composable
fun PaymentBadge(isPaid: Boolean) {
    if (isPaid) {
        StatusBadge(
            text = "تم السداد (مدفوع)",
            color = StatusSuccess,
            bgColor = StatusSuccessContainer,
            icon = Icons.Default.CheckCircle
        )
    } else {
        StatusBadge(
            text = "مستحق السداد (لم يدفع)",
            color = StatusDanger,
            bgColor = StatusDangerContainer,
            icon = Icons.Default.Warning
        )
    }
}

@Composable
fun EmptyStateView(
    title: String,
    description: String,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(AcademicBlueContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = AcademicBluePrimary,
                modifier = Modifier.size(36.dp)
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = description,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

fun shareGuardianReport(
    context: Context,
    student: Student,
    attendanceStatus: String,
    homeworkStatus: String,
    paymentStatus: String,
    examGrade: String,
    teacherNote: String
) {
    val message = """
        *تقرير متابعة الطالب من تطبيق حصتي* 🎓
        ━━━━━━━━━━━━━━━━━━
        👤 *اسم الطالب:* ${student.name}
        🏷️ *كود الطالب:* ${student.code}
        📚 *المجموعة:* ${student.groupName}
        ⏰ *الموعد:* ${student.scheduleTime}
        
        📊 *حالة الحضور اليوم:* $attendanceStatus
        📝 *حالة الواجب:* $homeworkStatus
        💰 *المصروفات الشهرية:* $paymentStatus
        🎯 *درجة آخر اختبار:* $examGrade
        
        💬 *ملاحظة الأستاذ لولي الأمر:*
        $teacherNote
        ━━━━━━━━━━━━━━━━━━
        نتمنى له دوام التوفيق والنجاح.
    """.trimIndent()

    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, message)
    }

    try {
        context.startActivity(Intent.createChooser(intent, "إرسال تقرير المتابعة لولي الأمر"))
    } catch (_: Exception) {
        Toast.makeText(context, "تعذر فتح تطبيق المشاركة", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun AboutAppDialog(
    onDismiss: () -> Unit
) {
    val versionName = BuildConfig.VERSION_NAME
    SafeAlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("dialog_about_app"),
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(AcademicBluePrimary),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_app_foreground),
                        contentDescription = "شعار تطبيق حصتي",
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                    )
                }
                Column {
                    Text(
                        text = "حول تطبيق حصتي",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = AcademicBlueContainer,
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        Text(
                            text = "الإصدار $versionName",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = AcademicBluePrimary,
                            modifier = Modifier
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                                .testTag("txt_app_version")
                        )
                    }
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "برنامج حصتي — الإصدار $versionName",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = AcademicBluePrimary
                        )
                        Text(
                            text = "نظام متكامل لإدارة المجموعات والدروس الخصوصية: تسجيل الحضور بالـ QR، الواجبات والمصروفات، الامتحانات الأونلاين وبنك الأسئلة، الملاحظات الصوتية والكتابية، ركن اسأل المعلم، وتصدير تقارير PDF.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "اسم البرنامج:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "حصتي",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "رقم الإصدار:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = versionName,
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                        color = AcademicBluePrimary
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = AcademicBluePrimary),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("btn_close_about_app")
            ) {
                Text("إغلاق")
            }
        }
    )
}
