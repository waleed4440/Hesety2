package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.Student
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

object QrCodeHelper {

    private const val QR_PREFIX = "HESSATY_STU:"

    fun generateStudentQrContent(student: Student): String {
        return "$QR_PREFIX${student.code.trim().uppercase(Locale.ENGLISH)}"
    }

    fun parseStudentCodeFromQr(rawValue: String): String? {
        val trimmed = rawValue.trim()
        if (trimmed.isBlank()) return null
        return if (trimmed.startsWith(QR_PREFIX, ignoreCase = true)) {
            trimmed.substring(QR_PREFIX.length).trim().uppercase(Locale.ENGLISH).takeIf { it.isNotBlank() }
        } else {
            trimmed.uppercase(Locale.ENGLISH)
        }
    }

    fun generateQrBitmap(content: String, sizePx: Int = 512): Bitmap? {
        if (content.isBlank()) return null
        return try {
            val hints = mapOf(
                EncodeHintType.CHARACTER_SET to "UTF-8",
                EncodeHintType.MARGIN to 2
            )
            val bitMatrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, sizePx, sizePx, hints)
            val width = bitMatrix.width
            val height = bitMatrix.height
            val pixels = IntArray(width * height)
            for (y in 0 until height) {
                val offset = y * width
                for (x in 0 until width) {
                    pixels[offset + x] = if (bitMatrix[x, y]) Color.BLACK else Color.WHITE
                }
            }
            Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).apply {
                setPixels(pixels, 0, width, 0, 0, width, height)
            }
        } catch (_: Exception) {
            null
        }
    }

    fun shareStudentQrCard(context: Context, student: Student) {
        try {
            val qrContent = generateStudentQrContent(student)
            val qrBitmap = generateQrBitmap(qrContent, 420) ?: return

            val cardWidth = 600
            val cardHeight = 760
            val cardBitmap = Bitmap.createBitmap(cardWidth, cardHeight, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(cardBitmap)
            canvas.drawColor(Color.WHITE)

            val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1E40AF") }
            canvas.drawRoundRect(RectF(24f, 24f, cardWidth - 24f, 150f), 20f, 20f, headerPaint)

            val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = 34f
                isFakeBoldText = true
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("بطاقة حضور الطالب - حصتي", cardWidth / 2f, 84f, titlePaint)

            val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#DBEAFE")
                textSize = 22f
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText(student.groupName, cardWidth / 2f, 124f, subPaint)

            val qrLeft = (cardWidth - qrBitmap.width) / 2f
            canvas.drawBitmap(qrBitmap, qrLeft, 180f, null)

            val namePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#111827")
                textSize = 30f
                isFakeBoldText = true
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText(student.name, cardWidth / 2f, 645f, namePaint)

            val codePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#1E40AF")
                textSize = 26f
                isFakeBoldText = true
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("الكود: ${student.code}", cardWidth / 2f, 695f, codePaint)

            val reportsDir = File(context.cacheDir, "reports").apply { mkdirs() }
            val safeCode = student.code.replace(Regex("[^A-Za-z0-9_-]"), "_")
            val file = File(reportsDir, "qr_card_$safeCode.png")
            FileOutputStream(file).use { out ->
                cardBitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }

            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "بطاقة الـ QR الخاصة بالطالب ${student.name} (${student.code}) لتسجيل الحضور السريع في تطبيق حصتي")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "مشاركة بطاقة QR للطالب"))
        } catch (e: Exception) {
            Toast.makeText(context, "تعذر مشاركة بطاقة QR: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    fun copyPickedImageToInternal(context: Context, sourceUri: Uri): String? {
        return try {
            val imagesDir = File(context.filesDir, "exam_images").apply { mkdirs() }
            val destFile = File(imagesDir, "q_img_${System.currentTimeMillis()}.jpg")
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return null
            destFile.absolutePath
        } catch (_: Exception) {
            null
        }
    }

    fun copyPickedResourceFileToInternal(context: Context, sourceUri: Uri): String? {
        return try {
            val resDir = File(context.filesDir, "resources").apply { mkdirs() }
            var displayName: String? = null
            context.contentResolver.query(sourceUri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) displayName = cursor.getString(idx)
                }
            }
            val mimeType = context.contentResolver.getType(sourceUri)
            val extFromMime = if (mimeType != null) MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeType) else null
            val rawName = (displayName ?: "resource_${System.currentTimeMillis()}").replace(Regex("[^A-Za-z0-9._\\-\\u0600-\\u06FF]"), "_")
            val finalName = if (rawName.contains(".") || extFromMime.isNullOrBlank()) {
                "${System.currentTimeMillis()}_$rawName"
            } else {
                "${System.currentTimeMillis()}_${rawName}.$extFromMime"
            }
            val destFile = File(resDir, finalName)
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return null
            destFile.absolutePath
        } catch (_: Exception) {
            null
        }
    }

    private fun resolveMimeType(file: File): String {
        val ext = file.extension.lowercase(Locale.ENGLISH)
        return when (ext) {
            "pdf" -> "application/pdf"
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "txt" -> "text/plain"
            "doc" -> "application/msword"
            "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            "ppt", "pptx" -> "application/vnd.ms-powerpoint"
            else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
        }
    }

    fun openLocalResourceFile(context: Context, filePath: String) {
        try {
            val file = File(filePath)
            if (!file.exists()) {
                Toast.makeText(context, "الملف غير موجود على الجهاز", Toast.LENGTH_SHORT).show()
                return
            }
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val mime = resolveMimeType(file)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            try {
                context.startActivity(intent)
            } catch (_: Exception) {
                val chooser = Intent.createChooser(intent, "فتح الملف عبر")
                context.startActivity(chooser)
            }
        } catch (_: Exception) {
            Toast.makeText(context, "لا يوجد تطبيق متاح لفتح هذا النوع من الملفات", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareResourceFile(context: Context, filePath: String, title: String) {
        try {
            val file = File(filePath)
            if (!file.exists()) {
                Toast.makeText(context, "الملف غير موجود للمشاركة", Toast.LENGTH_SHORT).show()
                return
            }
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val mime = resolveMimeType(file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mime
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "مذكرة تعليمية: $title — من تطبيق حصتي")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "مشاركة الملف التعليمي"))
        } catch (_: Exception) {
            Toast.makeText(context, "تعذر مشاركة الملف", Toast.LENGTH_SHORT).show()
        }
    }

    fun openExternalUrl(context: Context, url: String) {
        val trimmed = url.trim()
        if (trimmed.isBlank()) {
            Toast.makeText(context, "الرابط غير متاح", Toast.LENGTH_SHORT).show()
            return
        }
        val normalized = if (trimmed.startsWith("http://", ignoreCase = true) || trimmed.startsWith("https://", ignoreCase = true)) {
            trimmed
        } else {
            "https://$trimmed"
        }
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(normalized))
            context.startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(context, "تعذر فتح الرابط الخارجي", Toast.LENGTH_SHORT).show()
        }
    }

    fun sendAbsenteeWhatsAppMessage(
        context: Context,
        student: Student,
        date: String,
        latestExamSummary: String?
    ) {
        val message = buildString {
            append("السلام عليكم ورحمة الله وبركاته،\n")
            append("ولي أمر الطالب/ة: *${student.name}* (${student.groupName})\n")
            append("نود إبلاغكم بتغيّب الطالب عن حصة يوم $date.\n")
            if (!latestExamSummary.isNullOrBlank()) {
                append("درجة آخر امتحان: $latestExamSummary.\n")
            }
            append("نرجو المتابعة والتواصل معنا للاطمئنان عليه.\n")
            append("— تطبيق حصتي")
        }
        ParentCommunicationHelper.openWhatsApp(context, student.parentPhone, message)
    }
}
