package com.example.util

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.widget.Toast
import androidx.core.content.FileProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale

object AudioNoteHelper {

    fun formatDuration(seconds: Int): String {
        val safe = seconds.coerceAtLeast(0)
        val mins = safe / 60
        val secs = safe % 60
        return String.format(Locale.ENGLISH, "%02d:%02d", mins, secs)
    }

    fun getVoiceNotesDir(context: Context): File {
        return File(context.filesDir, "voice_notes").apply { mkdirs() }
    }

    fun deleteAudioFileIfExists(path: String) {
        if (path.isBlank()) return
        runCatching {
            val file = File(path)
            if (file.exists()) file.delete()
        }
    }

    fun shareVoiceNote(
        context: Context,
        audioPath: String,
        studentName: String,
        writtenText: String = ""
    ) {
        val file = File(audioPath)
        if (!file.exists()) {
            Toast.makeText(context, "الملف الصوتي غير موجود على هذا الجهاز", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val textBody = buildString {
                append("🎙️ ملاحظة صوتية من المعلم لولي أمر الطالب: $studentName\n")
                append("تطبيق حصتي 🎓")
                if (writtenText.isNotBlank()) {
                    append("\n\n📝 ملاحظة كتابية:\n$writtenText")
                }
            }
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "audio/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, textBody)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "مشاركة الملاحظة الصوتية"))
        } catch (_: Exception) {
            Toast.makeText(context, "تعذر مشاركة الملف الصوتي", Toast.LENGTH_SHORT).show()
        }
    }
}

class VoiceRecorderManager(private val context: Context) {
    private var recorder: MediaRecorder? = null
    private var currentFile: File? = null
    private var startedAtMs: Long = 0L

    fun startRecording(
        prefix: String = "voice",
        onStarted: () -> Unit,
        onError: (String) -> Unit
    ) {
        stopAndReleaseInternal()
        try {
            val dir = AudioNoteHelper.getVoiceNotesDir(context)
            val outFile = File(dir, "${prefix}_${System.currentTimeMillis()}.m4a")
            val mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }
            mediaRecorder.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(96000)
                setAudioSamplingRate(44100)
                setOutputFile(outFile.absolutePath)
                prepare()
                start()
            }
            recorder = mediaRecorder
            currentFile = outFile
            startedAtMs = System.currentTimeMillis()
            onStarted()
        } catch (e: Exception) {
            stopAndReleaseInternal()
            currentFile?.delete()
            currentFile = null
            onError("تعذر تشغيل الميكروفون للتسجيل: ${e.localizedMessage ?: "خطأ غير متوقع"}")
        }
    }

    fun stopRecording(): Pair<String, Int>? {
        val file = currentFile
        val elapsedSec = (((System.currentTimeMillis() - startedAtMs) + 500L) / 1000L).toInt().coerceAtLeast(1)
        val stoppedCleanly = try {
            recorder?.stop()
            true
        } catch (_: Exception) {
            false
        } finally {
            stopAndReleaseInternal()
        }

        currentFile = null
        return if (stoppedCleanly && file != null && file.exists() && file.length() > 0L) {
            file.absolutePath to elapsedSec
        } else {
            file?.delete()
            null
        }
    }

    fun cancelRecording() {
        try {
            recorder?.stop()
        } catch (_: Exception) {}
        stopAndReleaseInternal()
        currentFile?.delete()
        currentFile = null
    }

    private fun stopAndReleaseInternal() {
        runCatching { recorder?.reset() }
        runCatching { recorder?.release() }
        recorder = null
    }
}

object AudioPlaybackCoordinator {
    private var mediaPlayer: MediaPlayer? = null
    private var progressJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    private val _activePath = MutableStateFlow<String?>(null)
    val activePath: StateFlow<String?> = _activePath.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPositionSec = MutableStateFlow(0)
    val currentPositionSec: StateFlow<Int> = _currentPositionSec.asStateFlow()

    private val _durationSec = MutableStateFlow(0)
    val durationSec: StateFlow<Int> = _durationSec.asStateFlow()

    fun togglePlay(context: Context, filePath: String, fallbackDurationSec: Int = 0) {
        if (filePath.isBlank()) return
        val file = File(filePath)
        if (!file.exists()) {
            Toast.makeText(context, "عذراً، الملف الصوتي غير متوفر على هذا الجهاز", Toast.LENGTH_SHORT).show()
            return
        }

        val player = mediaPlayer
        if (_activePath.value == filePath && player != null) {
            if (_isPlaying.value) {
                runCatching { player.pause() }
                _isPlaying.value = false
                progressJob?.cancel()
            } else {
                runCatching { player.start() }
                _isPlaying.value = true
                startProgressTicker()
            }
            return
        }

        stop()

        try {
            val newPlayer = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                prepare()
                setOnCompletionListener {
                    _isPlaying.value = false
                    _currentPositionSec.value = 0
                    progressJob?.cancel()
                    runCatching { seekTo(0) }
                }
                start()
            }
            mediaPlayer = newPlayer
            _activePath.value = filePath
            val totalSec = ((newPlayer.duration + 500) / 1000).coerceAtLeast(fallbackDurationSec.coerceAtLeast(1))
            _durationSec.value = totalSec
            _currentPositionSec.value = 0
            _isPlaying.value = true
            startProgressTicker()
        } catch (_: Exception) {
            stop()
            Toast.makeText(context, "تعذر تشغيل الملاحظة الصوتية", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startProgressTicker() {
        progressJob?.cancel()
        progressJob = scope.launch {
            while (isActive && _isPlaying.value) {
                val posMs = runCatching { mediaPlayer?.currentPosition ?: 0 }.getOrDefault(0)
                _currentPositionSec.value = (posMs / 1000).coerceAtLeast(0)
                delay(250L)
            }
        }
    }

    fun stop() {
        progressJob?.cancel()
        progressJob = null
        runCatching {
            if (mediaPlayer?.isPlaying == true) {
                mediaPlayer?.stop()
            }
        }
        runCatching { mediaPlayer?.release() }
        mediaPlayer = null
        _activePath.value = null
        _isPlaying.value = false
        _currentPositionSec.value = 0
        _durationSec.value = 0
    }
}
