package com.example.util

import com.example.data.Exam
import com.example.data.ExamQuestion
import com.example.data.ExamSubmission
import com.example.data.MistakeRecord
import com.example.data.QuestionBankItem
import org.json.JSONObject

data class QuestionAnalyticsItem(
    val question: ExamQuestion,
    val totalAttempts: Int,
    val wrongCount: Int
) {
    val errorRatePercent: Int
        get() = if (totalAttempts > 0) (wrongCount * 100) / totalAttempts else 0
}

data class ExamAnalyticsSummary(
    val totalSubmissions: Int,
    val passedCount: Int,
    val passRatePercent: Int,
    val averagePercentage: Int,
    val hardestQuestions: List<QuestionAnalyticsItem>
)

object ExamMistakeAnalyzer {

    fun isQuestionAnsweredCorrectly(question: ExamQuestion, answersObj: JSONObject): Boolean {
        return if (question.questionType == ExamQuestion.TYPE_SHORT_ANSWER) {
            val typed = answersObj.optString("text_${question.id}", "").trim()
            typed.isNotBlank() &&
                question.correctTextAnswer.isNotBlank() &&
                ExamQuestion.normalizeShortAnswer(typed) == ExamQuestion.normalizeShortAnswer(question.correctTextAnswer)
        } else {
            val selectedOpt = if (answersObj.has(question.id.toString())) {
                answersObj.optInt(question.id.toString(), -1)
            } else {
                -1
            }
            selectedOpt == question.correctOptionIndex
        }
    }

    fun extractMistakesFromSubmission(
        exam: Exam,
        studentId: Long,
        studentCode: String,
        studentName: String,
        answersJson: String,
        date: String
    ): List<MistakeRecord> {
        val obj = try {
            JSONObject(answersJson)
        } catch (_: Exception) {
            return emptyList()
        }
        // Manual teacher grade without question breakdown should not create fake question mistakes
        if (obj.optBoolean("manualGraded", false)) return emptyList()

        val questions = exam.parseQuestions()
        if (questions.isEmpty()) return emptyList()

        val mistakes = mutableListOf<MistakeRecord>()
        for (q in questions) {
            if (!isQuestionAnsweredCorrectly(q, obj)) {
                val studentAnsText: String
                val correctAnsText: String
                if (q.questionType == ExamQuestion.TYPE_SHORT_ANSWER) {
                    studentAnsText = obj.optString("text_${q.id}", "").trim().ifBlank { "لم يتم الحل" }
                    correctAnsText = q.correctTextAnswer
                } else {
                    val opts = when {
                        q.questionType == ExamQuestion.TYPE_TRUE_FALSE && q.options.isEmpty() -> listOf("صح", "خطأ")
                        else -> q.options
                    }
                    val selectedIdx = obj.optInt(q.id.toString(), -1)
                    studentAnsText = opts.getOrNull(selectedIdx) ?: "لم يتم الحل"
                    correctAnsText = opts.getOrNull(q.correctOptionIndex) ?: ""
                }

                mistakes.add(
                    MistakeRecord(
                        studentId = studentId,
                        studentCode = studentCode,
                        studentName = studentName,
                        examId = exam.id,
                        examTitle = exam.title,
                        subject = q.topic.ifBlank { exam.subject.ifBlank { exam.groupName } },
                        questionId = q.id,
                        questionText = q.questionText,
                        questionType = q.questionType,
                        optionsJson = QuestionBankItem.encodeOptions(q.options),
                        studentAnswer = studentAnsText,
                        correctAnswer = correctAnsText,
                        correctOptionIndex = q.correctOptionIndex,
                        explanation = q.explanation,
                        difficulty = q.difficulty,
                        lastMistakeDate = date
                    )
                )
            }
        }
        return mistakes
    }

    fun computeExamAnalytics(
        exam: Exam,
        submissions: List<ExamSubmission>
    ): ExamAnalyticsSummary {
        if (submissions.isEmpty()) {
            return ExamAnalyticsSummary(
                totalSubmissions = 0,
                passedCount = 0,
                passRatePercent = 0,
                averagePercentage = 0,
                hardestQuestions = emptyList()
            )
        }
        val passedCount = submissions.count { exam.isPassing(it.score, it.maxScore) }
        val passRatePercent = (passedCount * 100) / submissions.size
        val averagePercentage = submissions.map { sub ->
            if (sub.maxScore > 0) (sub.score * 100) / sub.maxScore else 0
        }.average().toInt()

        val questions = exam.parseQuestions()
        val parsedAnswers = submissions.mapNotNull { sub ->
            try {
                val obj = JSONObject(sub.answersJson)
                if (obj.optBoolean("manualGraded", false)) null else obj
            } catch (_: Exception) {
                null
            }
        }

        val hardestQuestions = if (questions.isEmpty() || parsedAnswers.isEmpty()) {
            emptyList()
        } else {
            questions.map { q ->
                val wrongCount = parsedAnswers.count { obj -> !isQuestionAnsweredCorrectly(q, obj) }
                QuestionAnalyticsItem(
                    question = q,
                    totalAttempts = parsedAnswers.size,
                    wrongCount = wrongCount
                )
            }.sortedByDescending { it.wrongCount }
        }

        return ExamAnalyticsSummary(
            totalSubmissions = submissions.size,
            passedCount = passedCount,
            passRatePercent = passRatePercent,
            averagePercentage = averagePercentage,
            hardestQuestions = hardestQuestions
        )
    }
}
