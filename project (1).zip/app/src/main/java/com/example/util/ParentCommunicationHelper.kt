package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.example.data.AttendanceRecord
import com.example.data.Exam
import com.example.data.ExamSubmission
import com.example.data.HomeworkRecord
import com.example.data.ParentNote
import com.example.data.PaymentRecord
import com.example.data.Student

enum class ParentMessageTemplate(val label: String) {
    FULL_REPORT("تقرير شامل"),
    ABSENCE_ALERT("تنبيه غياب"),
    HOMEWORK_REMINDER("الواجب"),
    EXAM_RESULT("درجة امتحان"),
    PAYMENT_REMINDER("المصروفات"),
    CUSTOM("رسالة حرة")
}

data class StudentGuardianSnapshot(
    val student: Student,
    val attendanceStatus: String,
    val attendanceRatePercent: String,
    val homeworkStatus: String,
    val homeworkRatePercent: String,
    val isPaid: Boolean,
    val latestExamScore: String?,
    val latestExamTitle: String?,
    val teacherNote: String?,
    val sessionDate: String
)

object ParentCommunicationHelper {

    fun buildSnapshot(
        student: Student,
        allAttendances: List<AttendanceRecord>,
        allHomework: List<HomeworkRecord>,
        allPayments: List<PaymentRecord>,
        allSubmissions: List<ExamSubmission>,
        allExams: List<Exam>,
        allNotes: List<ParentNote>,
        sessionDate: String
    ): StudentGuardianSnapshot {
        val studentAttendances = allAttendances.filter { it.studentId == student.id }
        val todayAtt = studentAttendances.firstOrNull { it.date == sessionDate }
        val attendanceStatus = when (todayAtt?.status) {
            AttendanceRecord.STATUS_PRESENT -> "حاضر"
            AttendanceRecord.STATUS_ABSENT -> "غائب"
            AttendanceRecord.STATUS_LATE -> "متأخر"
            AttendanceRecord.STATUS_EXCUSED -> "غائب بعذر"
            else -> "غير مسجل اليوم"
        }
        val attendanceRate = if (studentAttendances.isNotEmpty()) {
            val attended = studentAttendances.count {
                it.status == AttendanceRecord.STATUS_PRESENT || it.status == AttendanceRecord.STATUS_LATE
            }
            "${(attended * 100) / studentAttendances.size}%"
        } else {
            "100%"
        }

        val studentHomework = allHomework.filter { it.studentId == student.id }
        val todayHw = studentHomework.firstOrNull { it.date == sessionDate }
        val homeworkStatus = when (todayHw?.status) {
            HomeworkRecord.STATUS_COMPLETED -> "تم تسليم الواجب"
            HomeworkRecord.STATUS_PARTIAL -> "حل جزئي للواجب"
            HomeworkRecord.STATUS_NOT_COMPLETED -> "لم يسلّم الواجب"
            else -> "غير مسجل اليوم"
        }
        val homeworkRate = if (studentHomework.isNotEmpty()) {
            val done = studentHomework.count {
                it.status == HomeworkRecord.STATUS_COMPLETED || it.status == HomeworkRecord.STATUS_PARTIAL
            }
            "${(done * 100) / studentHomework.size}%"
        } else {
            "100%"
        }

        val isPaid = allPayments.firstOrNull { it.studentId == student.id }?.isPaid ?: false
        val latestSub = allSubmissions
            .filter { it.studentId == student.id }
            .maxByOrNull { it.submittedAt }
        val latestExamTitle = latestSub?.let { sub ->
            allExams.firstOrNull { it.id == sub.examId }?.title
        }
        val latestExamScore = latestSub?.let { "${it.score}/${it.maxScore}" }

        val latestNote = allNotes
            .filter { it.studentId == student.id }
            .maxByOrNull { it.id }
            ?.displaySummary()
            ?.takeIf { it.isNotBlank() }

        return StudentGuardianSnapshot(
            student = student,
            attendanceStatus = attendanceStatus,
            attendanceRatePercent = attendanceRate,
            homeworkStatus = homeworkStatus,
            homeworkRatePercent = homeworkRate,
            isPaid = isPaid,
            latestExamScore = latestExamScore,
            latestExamTitle = latestExamTitle,
            teacherNote = latestNote,
            sessionDate = sessionDate
        )
    }

    fun normalizeWhatsAppPhone(rawPhone: String): String? {
        val digits = rawPhone.filter { it.isDigit() }
        if (digits.length < 8) return null
        return when {
            digits.startsWith("00") && digits.length > 10 -> digits.drop(2)
            digits.startsWith("01") && digits.length == 11 -> "2$digits"
            digits.startsWith("1") && digits.length == 10 -> "20$digits"
            else -> digits
        }
    }

    fun normalizeDialPhone(rawPhone: String): String? {
        val trimmed = rawPhone.trim()
        val hasPlus = trimmed.startsWith("+")
        val digits = trimmed.filter { it.isDigit() }
        if (digits.length < 6) return null
        return if (hasPlus) "+$digits" else digits
    }

    fun buildWhatsAppUri(rawPhone: String, message: String): Uri? {
        val formatted = normalizeWhatsAppPhone(rawPhone) ?: return null
        return Uri.parse("https://wa.me/$formatted?text=${Uri.encode(message)}")
    }

    fun buildTemplateMessage(
        template: ParentMessageTemplate,
        snapshot: StudentGuardianSnapshot
    ): String {
        val student = snapshot.student
        val paymentLabel = if (snapshot.isPaid) "تم السداد ✓" else "مستحق السداد (${student.monthlyFee.toInt()} ج.م)"
        val examLabel = when {
            snapshot.latestExamScore != null && !snapshot.latestExamTitle.isNullOrBlank() ->
                "${snapshot.latestExamScore} (${snapshot.latestExamTitle})"
            snapshot.latestExamScore != null -> snapshot.latestExamScore
            else -> "لم تُرصد بعد"
        }

        return when (template) {
            ParentMessageTemplate.FULL_REPORT -> buildString {
                append("السلام عليكم ورحمة الله وبركاته،\n")
                append("*تقرير متابعة الطالب — تطبيق حصتي* 🎓\n")
                append("━━━━━━━━━━━━━━\n")
                append("👤 الطالب: ${student.name}\n")
                append("📚 المجموعة: ${student.groupName}\n")
                append("📅 نسبة الحضور: ${snapshot.attendanceRatePercent} (حصة ${snapshot.sessionDate}: ${snapshot.attendanceStatus})\n")
                append("📝 الواجبات: ${snapshot.homeworkRatePercent} (${snapshot.homeworkStatus})\n")
                append("🎯 آخر امتحان: $examLabel\n")
                append("💰 المصروفات: $paymentLabel\n")
                if (!snapshot.teacherNote.isNullOrBlank()) {
                    append("💬 ملاحظة المعلم: ${snapshot.teacherNote}\n")
                }
                append("━━━━━━━━━━━━━━\n")
                append("مع أطيب التمنيات بالتوفيق والتفوق.")
            }

            ParentMessageTemplate.ABSENCE_ALERT -> buildString {
                append("السلام عليكم ورحمة الله وبركاته،\n")
                append("ولي أمر الطالب/ة: *${student.name}* (${student.groupName})\n")
                append("نود إبلاغكم بتغيّب الطالب عن حصة يوم ${snapshot.sessionDate}.\n")
                if (!snapshot.latestExamScore.isNullOrBlank()) {
                    append("درجة آخر امتحان: $examLabel.\n")
                }
                append("نرجو المتابعة والتواصل معنا للاطمئنان عليه.\n")
                append("— تطبيق حصتي")
            }

            ParentMessageTemplate.HOMEWORK_REMINDER -> buildString {
                append("السلام عليكم ورحمة الله وبركاته،\n")
                append("ولي أمر الطالب/ة: *${student.name}* (${student.groupName})\n")
                append("نحيطكم علماً بأن حالة الواجب بتاريخ ${snapshot.sessionDate} هي: (${snapshot.homeworkStatus}).\n")
                append("نرجو متابعة الطالب في إتمام واجباته أولاً بأول للحفاظ على مستواه.\n")
                append("— تطبيق حصتي")
            }

            ParentMessageTemplate.EXAM_RESULT -> buildString {
                append("السلام عليكم ورحمة الله وبركاته،\n")
                append("ولي أمر الطالب/ة: *${student.name}* (${student.groupName})\n")
                if (snapshot.latestExamScore != null) {
                    append("🎯 نتيجة الطالب في آخر امتحان")
                    if (!snapshot.latestExamTitle.isNullOrBlank()) {
                        append(" (${snapshot.latestExamTitle})")
                    }
                    append(": *${snapshot.latestExamScore}*.\n")
                } else {
                    append("نود اطلاعكم على متابعة مستوى الطالب الأكاديمي في الامتحانات.\n")
                }
                if (!snapshot.teacherNote.isNullOrBlank()) {
                    append("ملاحظة المعلم: ${snapshot.teacherNote}\n")
                }
                append("نتمنى له دوام التفوق والنجاح.\n")
                append("— تطبيق حصتي")
            }

            ParentMessageTemplate.PAYMENT_REMINDER -> buildString {
                append("السلام عليكم ورحمة الله وبركاته،\n")
                append("ولي أمر الطالب/ة: *${student.name}* (${student.groupName})\n")
                if (snapshot.isPaid) {
                    append("نؤكد لحضرتكم استلام مصروفات الشهر بقيمة ${student.monthlyFee.toInt()} ج.م بنجاح ✓\n")
                    append("شكراً لتعاونكم المستمر.\n")
                } else {
                    append("تذكير لطيف بسداد المصروفات الشهرية المستحقة بقيمة ${student.monthlyFee.toInt()} ج.م.\n")
                    append("شاكرين لكم حسن تعاونكم.\n")
                }
                append("— تطبيق حصتي")
            }

            ParentMessageTemplate.CUSTOM -> buildString {
                append("السلام عليكم ورحمة الله وبركاته،\n")
                append("ولي أمر الطالب/ة: ${student.name} (${student.groupName})\n\n")
                append("— تطبيق حصتي")
            }
        }
    }

    fun openWhatsApp(context: Context, rawPhone: String, message: String) {
        val uri = buildWhatsAppUri(rawPhone, message)
        if (uri != null) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, uri)
                context.startActivity(intent)
                return
            } catch (_: Exception) {
                // Fall back to system share sheet below
            }
        } else {
            Toast.makeText(
                context,
                "رقم ولي الأمر غير مكتمل، سيتم فتح قائمة المشاركة",
                Toast.LENGTH_SHORT
            ).show()
        }
        shareViaOtherApps(context, message)
    }

    fun dialParent(context: Context, rawPhone: String) {
        val dialPhone = normalizeDialPhone(rawPhone)
        if (dialPhone == null) {
            Toast.makeText(context, "يرجى تسجيل رقم هاتف صحيح لولي الأمر أولاً", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$dialPhone"))
            context.startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(context, "تعذر فتح تطبيق الاتصال", Toast.LENGTH_SHORT).show()
        }
    }

    fun sendSms(context: Context, rawPhone: String, message: String) {
        val dialPhone = normalizeDialPhone(rawPhone)
        if (dialPhone == null) {
            Toast.makeText(context, "يرجى تسجيل رقم هاتف صحيح لولي الأمر أولاً", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$dialPhone")).apply {
                putExtra("sms_body", message)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(context, "تعذر فتح تطبيق الرسائل النصية", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareViaOtherApps(context: Context, message: String) {
        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, message)
            }
            context.startActivity(Intent.createChooser(intent, "إرسال رسالة لولي الأمر"))
        } catch (_: Exception) {
            Toast.makeText(context, "تعذر فتح تطبيق المشاركة", Toast.LENGTH_SHORT).show()
        }
    }
}
