package com.example.util

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.R

object AppNotificationManager {

    const val CHANNEL_ID_ACADEMIC = "academic_alerts_channel"
    private const val CHANNEL_NAME = "تنبيهات الحصص والواجبات والامتحانات"
    private const val CHANNEL_DESCRIPTION = "إشعارات فورية بالدرجات وتكليفات الواجبات الجديدة والتنبيهات المدرسية"

    fun initNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID_ACADEMIC, CHANNEL_NAME, importance).apply {
                description = CHANNEL_DESCRIPTION
                enableLights(true)
                enableVibration(true)
                setShowBadge(true)
            }
            val notificationManager: NotificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun sendNotification(
        context: Context,
        notificationId: Int,
        title: String,
        message: String,
        subText: String = "تطبيق حصتي"
    ) {
        initNotificationChannel(context)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ActivityCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                Log.w("AppNotification", "POST_NOTIFICATIONS permission not granted. Notification skipped.")
                return
            }
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ID_ACADEMIC)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setSubText(subText)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        try {
            with(NotificationManagerCompat.from(context)) {
                notify(notificationId, builder.build())
            }
        } catch (e: SecurityException) {
            Log.w("AppNotification", "SecurityException posting notification: ${e.message}")
        } catch (e: Exception) {
            Log.e("AppNotification", "Error posting notification: ${e.message}", e)
        }
    }

    fun notifyExamGrade(
        context: Context,
        examTitle: String,
        studentName: String,
        score: Int,
        maxScore: Int,
        notes: String = ""
    ) {
        val title = "🎯 تم رصد درجة امتحان: $examTitle"
        val message = buildString {
            append("أهلاً $studentName، قام المعلم برصد درجتك: ")
            append("$score من $maxScore في $examTitle.")
            if (notes.isNotBlank()) {
                append("\nملاحظة المعلم: $notes")
            }
        }
        val id = (System.currentTimeMillis() % 100000).toInt() + 1000
        sendNotification(context, id, title, message, subText = "نتائج الامتحانات")
    }

    fun notifyNewHomework(
        context: Context,
        groupName: String,
        date: String,
        homeworkDetails: String = ""
    ) {
        val title = "📝 واجب مدرسي جديد لمجموعة $groupName"
        val message = buildString {
            append("تم تسجيل تكليف واجب مدرسي جديد لتاريخ $date.")
            if (homeworkDetails.isNotBlank()) {
                append("\nالتفاصيل: $homeworkDetails")
            } else {
                append("\nيرجى مراجعة صفحة الحصة وإتمام حل الواجب قبل الموعد القادم.")
            }
        }
        val id = (System.currentTimeMillis() % 100000).toInt() + 2000
        sendNotification(context, id, title, message, subText = "الواجبات والتكليفات")
    }

    fun notifyGeneralAlert(
        context: Context,
        title: String,
        content: String,
        isUrgent: Boolean = false
    ) {
        val alertTitle = if (isUrgent) "🚨 تنبيه عاجل: $title" else "📢 إشعار جديد: $title"
        val id = (System.currentTimeMillis() % 100000).toInt() + 3000
        sendNotification(context, id, alertTitle, content, subText = "تنبيهات المستر")
    }

    fun notifyClassReminder(
        context: Context,
        dayName: String,
        groupName: String,
        startTime: String,
        location: String = ""
    ) {
        val title = "🗓️ تذكير بموعد الحصة: $groupName"
        val message = buildString {
            append("نذكركم بموعد حصة يوم $dayName الساعة $startTime.")
            if (location.isNotBlank()) {
                append("\nالمكان / القاعة: $location")
            }
            append("\nنرجو الحضور قبل الموعد بـ 10 دقائق وإحضار كارت الـ QR.")
        }
        val id = (System.currentTimeMillis() % 100000).toInt() + 4000
        sendNotification(context, id, title, message, subText = "جدول الحصص الأسبوعي")
    }

    fun notifyNewStudentQuestion(
        context: Context,
        studentName: String,
        groupName: String,
        questionPreview: String
    ) {
        val title = "💬 سؤال جديد في ركن اسأل المعلم"
        val message = "طرح الطالب $studentName ($groupName) سؤالاً:\n${questionPreview.take(120)}"
        val id = (System.currentTimeMillis() % 100000).toInt() + 5000
        sendNotification(context, id, title, message, subText = "ركن اسأل المعلم")
    }

    fun notifyQuestionAnswered(
        context: Context,
        studentName: String,
        subject: String,
        hasVoiceAnswer: Boolean
    ) {
        val title = "✅ تم الرد على سؤالك في ($subject)"
        val message = buildString {
            append("أهلاً $studentName، أجاب الأستاذ على سؤالك")
            if (hasVoiceAnswer) append(" (مرفق شرح صوتي 🎙️)")
            append(". افتح ركن اسأل المعلم للاطلاع على الإجابة.")
        }
        val id = (System.currentTimeMillis() % 100000).toInt() + 6000
        sendNotification(context, id, title, message, subText = "ركن اسأل المعلم")
    }
}
