package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.AttendanceRecord
import com.example.data.Exam
import com.example.data.ExamSubmission
import com.example.data.HomeworkRecord
import com.example.data.ParentNote
import com.example.data.PaymentRecord
import com.example.data.Student
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfReportExporter {

    private const val PAGE_WIDTH = 595 // A4 width in points (72 dpi)
    private const val PAGE_HEIGHT = 842 // A4 height in points (72 dpi)
    private const val MARGIN_X = 36f
    private const val CONTENT_WIDTH = (PAGE_WIDTH - MARGIN_X * 2).toInt()
    private const val TOP_MARGIN = 36f
    private const val BOTTOM_LIMIT = PAGE_HEIGHT - 44f

    private val COLOR_PRIMARY = Color.parseColor("#1E40AF")
    private val COLOR_PRIMARY_LIGHT = Color.parseColor("#DBEAFE")
    private val COLOR_SUCCESS = Color.parseColor("#15803D")
    private val COLOR_SUCCESS_BG = Color.parseColor("#DCFCE7")
    private val COLOR_DANGER = Color.parseColor("#B91C1C")
    private val COLOR_DANGER_BG = Color.parseColor("#FEE2E2")
    private val COLOR_WARNING = Color.parseColor("#B45309")
    private val COLOR_WARNING_BG = Color.parseColor("#FEF3C7")
    private val COLOR_TEXT_DARK = Color.parseColor("#111827")
    private val COLOR_TEXT_MUTED = Color.parseColor("#4B5563")
    private val COLOR_BORDER = Color.parseColor("#E5E7EB")
    private val COLOR_ROW_ALT = Color.parseColor("#F8FAFC")

    fun exportStudentReportPdf(
        outputStream: OutputStream,
        student: Student,
        attendances: List<AttendanceRecord>,
        homework: List<HomeworkRecord>,
        submissions: List<ExamSubmission>,
        exams: List<Exam>,
        payments: List<PaymentRecord>,
        notes: List<ParentNote>
    ) {
        val document = PdfDocument()
        try {
            val nowStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.ENGLISH).format(Date())

            val sortedAttendances = attendances.sortedByDescending { it.date }
            val sortedHomework = homework.sortedByDescending { it.date }
            val homeworkByDate = sortedHomework.associateBy { it.date }
            val allDates = (sortedAttendances.map { it.date } + sortedHomework.map { it.date })
                .distinct()
                .sortedDescending()
            val attendanceByDate = sortedAttendances.associateBy { it.date }

            val examsById = exams.associateBy { it.id }
            val sortedSubmissions = submissions.sortedByDescending { it.submittedAt }
            val latestPayment = payments.firstOrNull()
            val isPaid = latestPayment?.isPaid ?: false
            val sortedNotes = notes.sortedByDescending { it.id }

            val totalAtt = sortedAttendances.size
            val presentCount = sortedAttendances.count {
                it.status == AttendanceRecord.STATUS_PRESENT || it.status == AttendanceRecord.STATUS_LATE
            }
            val absentCount = sortedAttendances.count { it.status == AttendanceRecord.STATUS_ABSENT }
            val lateCount = sortedAttendances.count { it.status == AttendanceRecord.STATUS_LATE }
            val attendanceRate = if (totalAtt > 0) (presentCount * 100) / totalAtt else 100

            val totalHw = sortedHomework.size
            val hwDoneCount = sortedHomework.count {
                it.status == HomeworkRecord.STATUS_COMPLETED || it.status == HomeworkRecord.STATUS_PARTIAL
            }
            val homeworkRate = if (totalHw > 0) (hwDoneCount * 100) / totalHw else 100

            val latestSub = sortedSubmissions.firstOrNull()
            val latestExamStr = if (latestSub != null) "${latestSub.score}/${latestSub.maxScore}" else "لم ترصد"

            var pageNum = 1
            var page = document.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNum).create())
            var canvas = page.canvas
            var y = TOP_MARGIN

        fun finishAndStartNewPage(sectionHeaderTitle: String? = null) {
            drawFooter(canvas, pageNum, nowStr)
            document.finishPage(page)
            pageNum += 1
            page = document.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNum).create())
            canvas = page.canvas
            y = TOP_MARGIN
            if (sectionHeaderTitle != null) {
                y = drawSectionHeader(canvas, "$sectionHeaderTitle (تابع)", y)
            }
        }

        // 1. Header Banner
        y = drawBanner(
            canvas = canvas,
            title = "تقرير الأداء وسجل الحضور للطالب",
            subtitle = "تطبيق حصتي • تاريخ الإصدار: $nowStr",
            startY = y
        )

        // 2. Student Info Card
        y = drawInfoCard(
            canvas = canvas,
            lines = listOf(
                "اسم الطالب: ${student.name}   |   الكود: ${student.code}",
                "المجموعة: ${student.groupName}   |   الموعد: ${student.scheduleTime}",
                "هاتف ولي الأمر: ${student.parentPhone.ifBlank { "غير مسجل" }}   |   حالة المصروفات: ${if (isPaid) "تم السداد" else "مستحق السداد"} (${student.monthlyFee} ج.م)"
            ),
            startY = y
        )

        // 3. Summary KPI Boxes (4 cards across)
        y = drawMetricRow(
            canvas = canvas,
            metrics = listOf(
                MetricBox("نسبة الحضور", "$attendanceRate%", "$presentCount من $totalAtt حصة", COLOR_SUCCESS, COLOR_SUCCESS_BG),
                MetricBox("حل الواجبات", "$homeworkRate%", "$hwDoneCount من $totalHw واجب", COLOR_PRIMARY, COLOR_PRIMARY_LIGHT),
                MetricBox("آخر امتحان", latestExamStr, "${sortedSubmissions.size} اختبارات مرصودة", COLOR_WARNING, COLOR_WARNING_BG),
                MetricBox("الغياب / التأخير", "$absentCount / $lateCount", "غياب: $absentCount | تأخير: $lateCount", if (absentCount > 0) COLOR_DANGER else COLOR_TEXT_MUTED, if (absentCount > 0) COLOR_DANGER_BG else COLOR_ROW_ALT)
            ),
            startY = y
        )

        // 4. Exam Grades Section
        if (y + 90f > BOTTOM_LIMIT) finishAndStartNewPage()
        y = drawSectionHeader(canvas, "سجل درجات الامتحانات (${sortedSubmissions.size})", y)
        if (sortedSubmissions.isEmpty()) {
            y = drawEmptyNoteBox(canvas, "لا توجد درجات امتحانات مرصودة لهذا الطالب حتى الآن.", y)
        } else {
            for ((index, sub) in sortedSubmissions.take(10).withIndex()) {
                if (y + 30f > BOTTOM_LIMIT) finishAndStartNewPage("سجل درجات الامتحانات")
                val examTitle = examsById[sub.examId]?.title ?: "اختبار رقم #${sub.examId}"
                val subDate = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date(sub.submittedAt))
                val pct = if (sub.maxScore > 0) (sub.score * 100) / sub.maxScore else 0
                y = drawTableRow(
                    canvas = canvas,
                    text = "$examTitle   —   الدرجة: ${sub.score} / ${sub.maxScore} ($pct%)   —   التاريخ: $subDate",
                    startY = y,
                    isAlt = index % 2 == 1,
                    accentColor = if (pct >= 50) COLOR_SUCCESS else COLOR_DANGER
                )
            }
        }
        y += 8f

        // 5. Teacher Notes Section
        if (y + 80f > BOTTOM_LIMIT) finishAndStartNewPage()
        y = drawSectionHeader(canvas, "ملاحظات المعلم لولي الأمر (${sortedNotes.size})", y)
        if (sortedNotes.isEmpty()) {
            y = drawEmptyNoteBox(canvas, "لا توجد ملاحظات مسجلة، أداء الطالب مستقر وجيد.", y)
        } else {
            for ((index, note) in sortedNotes.take(6).withIndex()) {
                val noteBody = note.displaySummary().ifBlank { "ملاحظة مسجلة" }
                val noteText = "• [${note.date}] ${note.title}: $noteBody"
                val estHeight = measureRtlTextHeight(noteText, CONTENT_WIDTH - 24, 10.5f) + 14f
                if (y + estHeight > BOTTOM_LIMIT) finishAndStartNewPage("ملاحظات المعلم لولي الأمر")
                y = drawTableRow(
                    canvas = canvas,
                    text = noteText,
                    startY = y,
                    isAlt = index % 2 == 1,
                    accentColor = COLOR_TEXT_DARK
                )
            }
        }
        y += 8f

        // 6. Full Attendance & Homework History Section
        if (y + 90f > BOTTOM_LIMIT) finishAndStartNewPage()
        y = drawSectionHeader(canvas, "السجل الكامل للحضور والواجبات (${allDates.size} حصة)", y)

        if (allDates.isEmpty()) {
            y = drawEmptyNoteBox(canvas, "لا توجد سجلات حضور أو واجبات مسجلة حتى الآن.", y)
        } else {
            // Table Header
            y = drawHistoryTableHeader(canvas, y)
            for ((index, date) in allDates.withIndex()) {
                val att = attendanceByDate[date]
                val hw = homeworkByDate[date]
                val attLabel = translateAttendance(att?.status)
                val hwLabel = translateHomework(hw?.status)
                val notePart = listOfNotNull(
                    att?.notes?.takeIf { it.isNotBlank() },
                    hw?.notes?.takeIf { it.isNotBlank() }
                ).distinct().joinToString(" | ").ifBlank { "-" }

                val rowHeight = maxOf(
                    26f,
                    measureRtlTextHeight(notePart, 160, 9.5f) + 10f
                )
                if (y + rowHeight > BOTTOM_LIMIT) {
                    finishAndStartNewPage("السجل الكامل للحضور والواجبات")
                    y = drawHistoryTableHeader(canvas, y)
                }

                y = drawHistoryRow(
                    canvas = canvas,
                    date = date,
                    attLabel = attLabel,
                    attStatus = att?.status,
                    hwLabel = hwLabel,
                    hwStatus = hw?.status,
                    notes = notePart,
                    startY = y,
                    rowHeight = rowHeight,
                    isAlt = index % 2 == 1
                )
            }
        }

            drawFooter(canvas, pageNum, nowStr)
            document.finishPage(page)

            document.writeTo(outputStream)
        } finally {
            runCatching { document.close() }
        }
    }

    fun exportGroupReportPdf(
        outputStream: OutputStream,
        groupName: String,
        students: List<Student>,
        allAttendances: List<AttendanceRecord>,
        allHomework: List<HomeworkRecord>,
        allSubmissions: List<ExamSubmission>,
        allExams: List<Exam>,
        allPayments: List<PaymentRecord>,
        allNotes: List<ParentNote>
    ) {
        val document = PdfDocument()
        try {
            val nowStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.ENGLISH).format(Date())
            val examsById = allExams.associateBy { it.id }

            var pageNum = 1
            var page = document.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNum).create())
            var canvas = page.canvas
            var y = TOP_MARGIN

        fun finishAndStartNewPage(continuationTitle: String) {
            drawFooter(canvas, pageNum, nowStr)
            document.finishPage(page)
            pageNum += 1
            page = document.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNum).create())
            canvas = page.canvas
            y = TOP_MARGIN
            y = drawSectionHeader(canvas, continuationTitle, y)
        }

        y = drawBanner(
            canvas = canvas,
            title = "التقرير الشامل لأداء وحضور الطلاب ($groupName)",
            subtitle = "تطبيق حصتي • عدد الطلاب: ${students.size} • تاريخ الإصدار: $nowStr",
            startY = y
        )

        val totalSessionsRecorded = allAttendances.map { it.date }.distinct().size
        val overallPresent = allAttendances.count { it.status == AttendanceRecord.STATUS_PRESENT || it.status == AttendanceRecord.STATUS_LATE }
        val overallAttPct = if (allAttendances.isNotEmpty()) (overallPresent * 100) / allAttendances.size else 100
        val paidCount = students.count { st -> allPayments.firstOrNull { it.studentId == st.id }?.isPaid == true }

        y = drawMetricRow(
            canvas = canvas,
            metrics = listOf(
                MetricBox("إجمالي الطلاب", "${students.size}", groupName, COLOR_PRIMARY, COLOR_PRIMARY_LIGHT),
                MetricBox("متوسط الحضور", "$overallAttPct%", "$totalSessionsRecorded تواريخ مسجلة", COLOR_SUCCESS, COLOR_SUCCESS_BG),
                MetricBox("المسددون", "$paidCount / ${students.size}", "حالة المصروفات", COLOR_WARNING, COLOR_WARNING_BG)
            ),
            startY = y
        )

        y = drawSectionHeader(canvas, "ملخص تقارير الطلاب (${students.size})", y)

        if (students.isEmpty()) {
            y = drawEmptyNoteBox(canvas, "لا يوجد طلاب مطابقون للتصفية الحالية.", y)
        } else {
            for ((index, student) in students.withIndex()) {
                val stAtt = allAttendances.filter { it.studentId == student.id }
                val attPct = if (stAtt.isNotEmpty()) {
                    val p = stAtt.count { it.status == AttendanceRecord.STATUS_PRESENT || it.status == AttendanceRecord.STATUS_LATE }
                    "${(p * 100) / stAtt.size}%"
                } else "100%"

                val stHw = allHomework.filter { it.studentId == student.id }
                val hwPct = if (stHw.isNotEmpty()) {
                    val done = stHw.count { it.status == HomeworkRecord.STATUS_COMPLETED || it.status == HomeworkRecord.STATUS_PARTIAL }
                    "${(done * 100) / stHw.size}%"
                } else "100%"

                val latestSub = allSubmissions.filter { it.studentId == student.id }.maxByOrNull { it.submittedAt }
                val examText = if (latestSub != null) {
                    val title = examsById[latestSub.examId]?.title ?: "اختبار"
                    "$title: ${latestSub.score}/${latestSub.maxScore}"
                } else {
                    "لم ترصد درجة"
                }

                val isPaid = allPayments.firstOrNull { it.studentId == student.id }?.isPaid ?: false
                val latestNote = allNotes.firstOrNull { it.studentId == student.id }?.displaySummary()?.ifBlank { "لا توجد ملاحظات" } ?: "لا توجد ملاحظات"

                val summaryText = "${index + 1}. ${student.name} (${student.code}) — ${student.groupName}\n" +
                    "الحضور: $attPct (${stAtt.size} حصة)  |  الواجب: $hwPct  |  آخر امتحان: $examText  |  المصروفات: ${if (isPaid) "مدفوعة" else "غير مدفوعة"}\n" +
                    "ملاحظة: $latestNote"

                val blockH = measureRtlTextHeight(summaryText, CONTENT_WIDTH - 24, 10f) + 18f
                if (y + blockH > BOTTOM_LIMIT) {
                    finishAndStartNewPage("ملخص تقارير الطلاب (تابع)")
                }

                y = drawTableRow(
                    canvas = canvas,
                    text = summaryText,
                    startY = y,
                    isAlt = index % 2 == 1,
                    accentColor = COLOR_TEXT_DARK
                )
            }
        }

            drawFooter(canvas, pageNum, nowStr)
            document.finishPage(page)

            document.writeTo(outputStream)
        } finally {
            runCatching { document.close() }
        }
    }

    fun createStudentReportPdfFile(
        context: Context,
        student: Student,
        attendances: List<AttendanceRecord>,
        homework: List<HomeworkRecord>,
        submissions: List<ExamSubmission>,
        exams: List<Exam>,
        payments: List<PaymentRecord>,
        notes: List<ParentNote>
    ): File {
        val reportsDir = File(context.cacheDir, "reports").apply { mkdirs() }
        val safeCode = student.code.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val file = File(reportsDir, "student_report_${safeCode}.pdf")
        FileOutputStream(file).use { out ->
            exportStudentReportPdf(out, student, attendances, homework, submissions, exams, payments, notes)
        }
        return file
    }

    fun createGroupReportPdfFile(
        context: Context,
        groupName: String,
        students: List<Student>,
        allAttendances: List<AttendanceRecord>,
        allHomework: List<HomeworkRecord>,
        allSubmissions: List<ExamSubmission>,
        allExams: List<Exam>,
        allPayments: List<PaymentRecord>,
        allNotes: List<ParentNote>
    ): File {
        val reportsDir = File(context.cacheDir, "reports").apply { mkdirs() }
        val file = File(reportsDir, "group_report_${System.currentTimeMillis()}.pdf")
        FileOutputStream(file).use { out ->
            exportGroupReportPdf(
                out, groupName, students, allAttendances, allHomework,
                allSubmissions, allExams, allPayments, allNotes
            )
        }
        return file
    }

    fun sharePdfFile(context: Context, file: File, chooserTitle: String) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, chooserTitle))
        } catch (e: Exception) {
            Toast.makeText(context, "تعذر مشاركة ملف PDF: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    fun openPdfFile(context: Context, file: File) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "فتح تقرير PDF"))
        } catch (_: Exception) {
            Toast.makeText(context, "لا يوجد تطبيق لعرض PDF، يمكنك حفظه أو مشاركته.", Toast.LENGTH_LONG).show()
        }
    }

    private data class MetricBox(
        val label: String,
        val value: String,
        val sublabel: String,
        val accentColor: Int,
        val bgColor: Int
    )

    private fun drawBanner(canvas: Canvas, title: String, subtitle: String, startY: Float): Float {
        val bannerHeight = 68f
        val rect = RectF(MARGIN_X, startY, PAGE_WIDTH - MARGIN_X, startY + bannerHeight)
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = COLOR_PRIMARY }
        canvas.drawRoundRect(rect, 12f, 12f, bgPaint)

        drawRtlText(
            canvas = canvas,
            text = title,
            x = MARGIN_X + 14f,
            y = startY + 12f,
            width = CONTENT_WIDTH - 28,
            textSize = 16f,
            color = Color.WHITE,
            bold = true
        )
        drawRtlText(
            canvas = canvas,
            text = subtitle,
            x = MARGIN_X + 14f,
            y = startY + 38f,
            width = CONTENT_WIDTH - 28,
            textSize = 10f,
            color = COLOR_PRIMARY_LIGHT,
            bold = false
        )
        return startY + bannerHeight + 12f
    }

    private fun drawInfoCard(canvas: Canvas, lines: List<String>, startY: Float): Float {
        val combined = lines.joinToString("\n")
        val textH = measureRtlTextHeight(combined, CONTENT_WIDTH - 24, 10.5f)
        val cardH = textH + 20f
        val rect = RectF(MARGIN_X, startY, PAGE_WIDTH - MARGIN_X, startY + cardH)
        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = COLOR_ROW_ALT }
        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_BORDER
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }
        canvas.drawRoundRect(rect, 10f, 10f, fillPaint)
        canvas.drawRoundRect(rect, 10f, 10f, strokePaint)

        drawRtlText(
            canvas = canvas,
            text = combined,
            x = MARGIN_X + 12f,
            y = startY + 10f,
            width = CONTENT_WIDTH - 24,
            textSize = 10.5f,
            color = COLOR_TEXT_DARK,
            bold = false
        )
        return startY + cardH + 12f
    }

    private fun drawMetricRow(canvas: Canvas, metrics: List<MetricBox>, startY: Float): Float {
        val gap = 8f
        val count = metrics.size.coerceAtLeast(1)
        val boxWidth = (CONTENT_WIDTH - gap * (count - 1)) / count
        val boxHeight = 62f

        metrics.forEachIndexed { index, box ->
            // Place right-to-left so first metric appears on the right
            val rtlIndex = count - 1 - index
            val left = MARGIN_X + rtlIndex * (boxWidth + gap)
            val rect = RectF(left, startY, left + boxWidth, startY + boxHeight)

            val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = box.bgColor }
            canvas.drawRoundRect(rect, 10f, 10f, bgPaint)

            drawCenteredText(canvas, box.label, left + 4f, startY + 8f, (boxWidth - 8f).toInt(), 9.5f, box.accentColor, bold = false)
            drawCenteredText(canvas, box.value, left + 4f, startY + 24f, (boxWidth - 8f).toInt(), 13f, box.accentColor, bold = true)
            drawCenteredText(canvas, box.sublabel, left + 4f, startY + 44f, (boxWidth - 8f).toInt(), 8f, COLOR_TEXT_MUTED, bold = false)
        }

        return startY + boxHeight + 14f
    }

    private fun drawSectionHeader(canvas: Canvas, title: String, startY: Float): Float {
        val headerH = 26f
        val rect = RectF(MARGIN_X, startY, PAGE_WIDTH - MARGIN_X, startY + headerH)
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = COLOR_PRIMARY_LIGHT }
        canvas.drawRoundRect(rect, 6f, 6f, bgPaint)

        drawRtlText(
            canvas = canvas,
            text = title,
            x = MARGIN_X + 10f,
            y = startY + 5f,
            width = CONTENT_WIDTH - 20,
            textSize = 11.5f,
            color = COLOR_PRIMARY,
            bold = true
        )
        return startY + headerH + 6f
    }

    private fun drawEmptyNoteBox(canvas: Canvas, message: String, startY: Float): Float {
        val boxH = 30f
        val rect = RectF(MARGIN_X, startY, PAGE_WIDTH - MARGIN_X, startY + boxH)
        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_BORDER
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }
        canvas.drawRoundRect(rect, 6f, 6f, strokePaint)
        drawRtlText(
            canvas = canvas,
            text = message,
            x = MARGIN_X + 10f,
            y = startY + 8f,
            width = CONTENT_WIDTH - 20,
            textSize = 10f,
            color = COLOR_TEXT_MUTED,
            bold = false
        )
        return startY + boxH + 8f
    }

    private fun drawTableRow(
        canvas: Canvas,
        text: String,
        startY: Float,
        isAlt: Boolean,
        accentColor: Int
    ): Float {
        val textH = measureRtlTextHeight(text, CONTENT_WIDTH - 20, 10f)
        val rowH = textH + 12f
        val rect = RectF(MARGIN_X, startY, PAGE_WIDTH - MARGIN_X, startY + rowH)
        if (isAlt) {
            val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = COLOR_ROW_ALT }
            canvas.drawRect(rect, bgPaint)
        }
        val linePaint = Paint().apply {
            color = COLOR_BORDER
            strokeWidth = 0.8f
        }
        canvas.drawLine(MARGIN_X, startY + rowH, PAGE_WIDTH - MARGIN_X, startY + rowH, linePaint)

        drawRtlText(
            canvas = canvas,
            text = text,
            x = MARGIN_X + 10f,
            y = startY + 6f,
            width = CONTENT_WIDTH - 20,
            textSize = 10f,
            color = accentColor,
            bold = false
        )
        return startY + rowH
    }

    private fun drawHistoryTableHeader(canvas: Canvas, startY: Float): Float {
        val rowH = 24f
        val rect = RectF(MARGIN_X, startY, PAGE_WIDTH - MARGIN_X, startY + rowH)
        val bgPaint = Paint().apply { color = COLOR_PRIMARY }
        canvas.drawRect(rect, bgPaint)

        // Columns from Right to Left: Date (90), Attendance (110), Homework (115), Notes (remaining ~208)
        val colNotesX = MARGIN_X + 6f
        val colHwX = colNotesX + 195f
        val colAttX = colHwX + 115f
        val colDateX = colAttX + 110f

        drawCenteredText(canvas, "ملاحظات", colNotesX, startY + 6f, 188, 9.5f, Color.WHITE, true)
        drawCenteredText(canvas, "الواجب", colHwX, startY + 6f, 110, 9.5f, Color.WHITE, true)
        drawCenteredText(canvas, "الحضور", colAttX, startY + 6f, 105, 9.5f, Color.WHITE, true)
        drawCenteredText(canvas, "التاريخ", colDateX, startY + 6f, 88, 9.5f, Color.WHITE, true)

        return startY + rowH
    }

    private fun drawHistoryRow(
        canvas: Canvas,
        date: String,
        attLabel: String,
        attStatus: String?,
        hwLabel: String,
        hwStatus: String?,
        notes: String,
        startY: Float,
        rowHeight: Float,
        isAlt: Boolean
    ): Float {
        val rect = RectF(MARGIN_X, startY, PAGE_WIDTH - MARGIN_X, startY + rowHeight)
        if (isAlt) {
            val bgPaint = Paint().apply { color = COLOR_ROW_ALT }
            canvas.drawRect(rect, bgPaint)
        }
        val linePaint = Paint().apply {
            color = COLOR_BORDER
            strokeWidth = 0.8f
        }
        canvas.drawLine(MARGIN_X, startY + rowHeight, PAGE_WIDTH - MARGIN_X, startY + rowHeight, linePaint)

        val colNotesX = MARGIN_X + 6f
        val colHwX = colNotesX + 195f
        val colAttX = colHwX + 115f
        val colDateX = colAttX + 110f

        val attColor = when (attStatus) {
            AttendanceRecord.STATUS_PRESENT -> COLOR_SUCCESS
            AttendanceRecord.STATUS_ABSENT -> COLOR_DANGER
            AttendanceRecord.STATUS_LATE, AttendanceRecord.STATUS_EXCUSED -> COLOR_WARNING
            else -> COLOR_TEXT_MUTED
        }

        val hwColor = when (hwStatus) {
            HomeworkRecord.STATUS_COMPLETED -> COLOR_SUCCESS
            HomeworkRecord.STATUS_NOT_COMPLETED -> COLOR_DANGER
            HomeworkRecord.STATUS_PARTIAL -> COLOR_WARNING
            else -> COLOR_TEXT_MUTED
        }

        drawRtlText(canvas, notes, colNotesX, startY + 6f, 188, 9f, COLOR_TEXT_DARK, false)
        drawCenteredText(canvas, hwLabel, colHwX, startY + 6f, 110, 9.5f, hwColor, true)
        drawCenteredText(canvas, attLabel, colAttX, startY + 6f, 105, 9.5f, attColor, true)
        drawCenteredText(canvas, date, colDateX, startY + 6f, 88, 9.5f, COLOR_TEXT_DARK, false)

        return startY + rowHeight
    }

    private fun drawFooter(canvas: Canvas, pageNum: Int, timestamp: String) {
        val linePaint = Paint().apply {
            color = COLOR_BORDER
            strokeWidth = 0.8f
        }
        canvas.drawLine(MARGIN_X, PAGE_HEIGHT - 32f, PAGE_WIDTH - MARGIN_X, PAGE_HEIGHT - 32f, linePaint)
        drawCenteredText(
            canvas = canvas,
            text = "تطبيق حصتي — صفحة $pageNum — تم الإنشاء بتاريخ $timestamp",
            x = MARGIN_X,
            y = PAGE_HEIGHT - 24f,
            width = CONTENT_WIDTH,
            textSize = 8.5f,
            color = COLOR_TEXT_MUTED,
            bold = false
        )
    }

    private fun buildRtlStaticLayout(
        text: String,
        width: Int,
        textSize: Float,
        color: Int,
        bold: Boolean,
        alignment: Layout.Alignment
    ): StaticLayout {
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            this.textSize = textSize
            this.typeface = Typeface.create(Typeface.DEFAULT, if (bold) Typeface.BOLD else Typeface.NORMAL)
        }
        return StaticLayout.Builder.obtain(text, 0, text.length, paint, width.coerceAtLeast(10))
            .setAlignment(alignment)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .setLineSpacing(2f, 1.05f)
            .setIncludePad(false)
            .build()
    }

    private fun measureRtlTextHeight(text: String, width: Int, textSize: Float): Float {
        return buildRtlStaticLayout(text, width, textSize, COLOR_TEXT_DARK, false, Layout.Alignment.ALIGN_NORMAL).height.toFloat()
    }

    private fun drawRtlText(
        canvas: Canvas,
        text: String,
        x: Float,
        y: Float,
        width: Int,
        textSize: Float,
        color: Int,
        bold: Boolean
    ) {
        val layout = buildRtlStaticLayout(text, width, textSize, color, bold, Layout.Alignment.ALIGN_NORMAL)
        canvas.save()
        canvas.translate(x, y)
        layout.draw(canvas)
        canvas.restore()
    }

    private fun drawCenteredText(
        canvas: Canvas,
        text: String,
        x: Float,
        y: Float,
        width: Int,
        textSize: Float,
        color: Int,
        bold: Boolean
    ) {
        val layout = buildRtlStaticLayout(text, width, textSize, color, bold, Layout.Alignment.ALIGN_CENTER)
        canvas.save()
        canvas.translate(x, y)
        layout.draw(canvas)
        canvas.restore()
    }

    private fun translateAttendance(status: String?): String = when (status) {
        AttendanceRecord.STATUS_PRESENT -> "حاضر"
        AttendanceRecord.STATUS_ABSENT -> "غائب"
        AttendanceRecord.STATUS_LATE -> "متأخر"
        AttendanceRecord.STATUS_EXCUSED -> "بعذر"
        else -> "غير مسجل"
    }

    private fun translateHomework(status: String?): String = when (status) {
        HomeworkRecord.STATUS_COMPLETED -> "تم الحل"
        HomeworkRecord.STATUS_NOT_COMPLETED -> "لم يُحل"
        HomeworkRecord.STATUS_PARTIAL -> "جزئي"
        else -> "غير مسجل"
    }
}
